// unused compatibility placeholder; runtime is pingus.js
