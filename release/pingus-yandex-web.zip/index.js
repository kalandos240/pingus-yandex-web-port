// include: shell.js
// The Module object: Our interface to the outside world. We import
// and export values on it. There are various ways Module can be used:
// 1. Not defined. We create it here
// 2. A function parameter, function(moduleArg) => Promise<Module>
// 3. pre-run appended it, var Module = {}; ..generated code..
// 4. External script tag defines var Module.
// We need to check if Module already exists (e.g. case 3 above).
// Substitution will be replaced with actual code on later stage of the build,
// this way Closure Compiler will not mangle it (e.g. case 4. above).
// Note that if you want to run closure, and also to use Module
// after the generated code, you will need to define   var Module = {};
// before the code. Then that object will be used in the code, and you
// can continue to use Module afterwards as well.
var Module = typeof Module != 'undefined' ? Module : {};

// Determine the runtime environment we are in. You can customize this by
// setting the ENVIRONMENT setting at compile time (see settings.js).

var ENVIRONMENT_IS_WEB = true;
var ENVIRONMENT_IS_WORKER = false;
var ENVIRONMENT_IS_NODE = false;
var ENVIRONMENT_IS_SHELL = false;

if (Module['ENVIRONMENT']) {
  throw new Error('Module.ENVIRONMENT has been deprecated. To force the environment, use the ENVIRONMENT compile-time option (for example, -sENVIRONMENT=web or -sENVIRONMENT=node)');
}

// --pre-jses are emitted after the Module integration code, so that they can
// refer to Module (if they choose; they can also define Module)
// include: /tmp/tmpam84_755.js

  if (!Module.expectedDataFileDownloads) {
    Module.expectedDataFileDownloads = 0;
  }

  Module.expectedDataFileDownloads++;
  (() => {
    // Do not attempt to redownload the virtual filesystem data when in a pthread or a Wasm Worker context.
    var isPthread = typeof ENVIRONMENT_IS_PTHREAD != 'undefined' && ENVIRONMENT_IS_PTHREAD;
    var isWasmWorker = typeof ENVIRONMENT_IS_WASM_WORKER != 'undefined' && ENVIRONMENT_IS_WASM_WORKER;
    if (isPthread || isWasmWorker) return;
    function loadPackage(metadata) {

      var PACKAGE_PATH = '';
      if (typeof window === 'object') {
        PACKAGE_PATH = window['encodeURIComponent'](window.location.pathname.toString().substring(0, window.location.pathname.toString().lastIndexOf('/')) + '/');
      } else if (typeof process === 'undefined' && typeof location !== 'undefined') {
        // web worker
        PACKAGE_PATH = encodeURIComponent(location.pathname.toString().substring(0, location.pathname.toString().lastIndexOf('/')) + '/');
      }
      var PACKAGE_NAME = '../dist/index.data';
      var REMOTE_PACKAGE_BASE = 'index.data';
      if (typeof Module['locateFilePackage'] === 'function' && !Module['locateFile']) {
        Module['locateFile'] = Module['locateFilePackage'];
        err('warning: you defined Module.locateFilePackage, that has been renamed to Module.locateFile (using your locateFilePackage for now)');
      }
      var REMOTE_PACKAGE_NAME = Module['locateFile'] ? Module['locateFile'](REMOTE_PACKAGE_BASE, '') : REMOTE_PACKAGE_BASE;
var REMOTE_PACKAGE_SIZE = metadata['remote_package_size'];

      function fetchRemotePackage(packageName, packageSize, callback, errback) {
        
        var xhr = new XMLHttpRequest();
        xhr.open('GET', packageName, true);
        xhr.responseType = 'arraybuffer';
        xhr.onprogress = function(event) {
          var url = packageName;
          var size = packageSize;
          if (event.total) size = event.total;
          if (event.loaded) {
            if (!xhr.addedTotal) {
              xhr.addedTotal = true;
              if (!Module.dataFileDownloads) Module.dataFileDownloads = {};
              Module.dataFileDownloads[url] = {
                loaded: event.loaded,
                total: size
              };
            } else {
              Module.dataFileDownloads[url].loaded = event.loaded;
            }
            var total = 0;
            var loaded = 0;
            var num = 0;
            for (var download in Module.dataFileDownloads) {
            var data = Module.dataFileDownloads[download];
              total += data.total;
              loaded += data.loaded;
              num++;
            }
            total = Math.ceil(total * Module.expectedDataFileDownloads/num);
            Module['setStatus']?.(`Downloading data... (${loaded}/${total})`);
          } else if (!Module.dataFileDownloads) {
            Module['setStatus']?.('Downloading data...');
          }
        };
        xhr.onerror = function(event) {
          throw new Error("NetworkError for: " + packageName);
        }
        xhr.onload = function(event) {
          if (xhr.status == 200 || xhr.status == 304 || xhr.status == 206 || (xhr.status == 0 && xhr.response)) { // file URLs can return 0
            var packageData = xhr.response;
            callback(packageData);
          } else {
            throw new Error(xhr.statusText + " : " + xhr.responseURL);
          }
        };
        xhr.send(null);
      };

      function handleError(error) {
        console.error('package error:', error);
      };

      var fetchedCallback = null;
      var fetched = Module['getPreloadedPackage'] ? Module['getPreloadedPackage'](REMOTE_PACKAGE_NAME, REMOTE_PACKAGE_SIZE) : null;

      if (!fetched) fetchRemotePackage(REMOTE_PACKAGE_NAME, REMOTE_PACKAGE_SIZE, function(data) {
        if (fetchedCallback) {
          fetchedCallback(data);
          fetchedCallback = null;
        } else {
          fetched = data;
        }
      }, handleError);

    function runWithFS(Module) {

      function assert(check, msg) {
        if (!check) throw msg + new Error().stack;
      }
Module['FS_createPath']("/", "data", true, true);
Module['FS_createPath']("/data", "controller", true, true);
Module['FS_createPath']("/data", "credits", true, true);
Module['FS_createPath']("/data", "images", true, true);
Module['FS_createPath']("/data/images", "XMas", true, true);
Module['FS_createPath']("/data/images", "backgrounds", true, true);
Module['FS_createPath']("/data/images", "core", true, true);
Module['FS_createPath']("/data/images/core", "buttons", true, true);
Module['FS_createPath']("/data/images/core", "cursors", true, true);
Module['FS_createPath']("/data/images/core", "demo", true, true);
Module['FS_createPath']("/data/images/core", "editor", true, true);
Module['FS_createPath']("/data/images/core", "menu", true, true);
Module['FS_createPath']("/data/images/core", "misc", true, true);
Module['FS_createPath']("/data/images/core", "start", true, true);
Module['FS_createPath']("/data/images/core", "worldmap", true, true);
Module['FS_createPath']("/data/images/core/worldmap", "pingus", true, true);
Module['FS_createPath']("/data/images", "entrances", true, true);
Module['FS_createPath']("/data/images", "exits", true, true);
Module['FS_createPath']("/data/images", "fonts", true, true);
Module['FS_createPath']("/data/images", "game", true, true);
Module['FS_createPath']("/data/images/game", "cursors", true, true);
Module['FS_createPath']("/data/images/game", "smallmap", true, true);
Module['FS_createPath']("/data/images/game", "stars", true, true);
Module['FS_createPath']("/data/images", "groundpieces", true, true);
Module['FS_createPath']("/data/images/groundpieces", "bridge", true, true);
Module['FS_createPath']("/data/images/groundpieces/bridge", "misc", true, true);
Module['FS_createPath']("/data/images/groundpieces/bridge", "space", true, true);
Module['FS_createPath']("/data/images/groundpieces", "ground", true, true);
Module['FS_createPath']("/data/images/groundpieces/ground", "crystal", true, true);
Module['FS_createPath']("/data/images/groundpieces/ground", "desert", true, true);
Module['FS_createPath']("/data/images/groundpieces/ground", "easter", true, true);
Module['FS_createPath']("/data/images/groundpieces/ground", "foliage", true, true);
Module['FS_createPath']("/data/images/groundpieces/ground", "forest", true, true);
Module['FS_createPath']("/data/images/groundpieces/ground", "green", true, true);
Module['FS_createPath']("/data/images/groundpieces/ground", "halloween", true, true);
Module['FS_createPath']("/data/images/groundpieces/ground", "industrial", true, true);
Module['FS_createPath']("/data/images/groundpieces/ground", "jungle", true, true);
Module['FS_createPath']("/data/images/groundpieces/ground", "misc", true, true);
Module['FS_createPath']("/data/images/groundpieces/ground", "mud", true, true);
Module['FS_createPath']("/data/images/groundpieces/ground", "mushroom", true, true);
Module['FS_createPath']("/data/images/groundpieces/ground", "ordina", true, true);
Module['FS_createPath']("/data/images/groundpieces/ground", "penguinworld", true, true);
Module['FS_createPath']("/data/images/groundpieces/ground", "real", true, true);
Module['FS_createPath']("/data/images/groundpieces/ground", "rock", true, true);
Module['FS_createPath']("/data/images/groundpieces/ground", "signposts", true, true);
Module['FS_createPath']("/data/images/groundpieces/ground", "snow", true, true);
Module['FS_createPath']("/data/images/groundpieces/ground", "sortie", true, true);
Module['FS_createPath']("/data/images/groundpieces/ground", "space", true, true);
Module['FS_createPath']("/data/images/groundpieces/ground", "sweets", true, true);
Module['FS_createPath']("/data/images/groundpieces/ground", "test", true, true);
Module['FS_createPath']("/data/images/groundpieces/ground", "xmas", true, true);
Module['FS_createPath']("/data/images/groundpieces", "remove", true, true);
Module['FS_createPath']("/data/images/groundpieces/remove", "misc", true, true);
Module['FS_createPath']("/data/images/groundpieces", "solid", true, true);
Module['FS_createPath']("/data/images/groundpieces/solid", "crystal", true, true);
Module['FS_createPath']("/data/images/groundpieces/solid", "desert", true, true);
Module['FS_createPath']("/data/images/groundpieces/solid", "industrial", true, true);
Module['FS_createPath']("/data/images/groundpieces/solid", "misc", true, true);
Module['FS_createPath']("/data/images/groundpieces/solid", "rock", true, true);
Module['FS_createPath']("/data/images/groundpieces", "transparent", true, true);
Module['FS_createPath']("/data/images/groundpieces/transparent", "easter", true, true);
Module['FS_createPath']("/data/images/groundpieces/transparent", "foliage", true, true);
Module['FS_createPath']("/data/images/groundpieces/transparent", "forest", true, true);
Module['FS_createPath']("/data/images/groundpieces/transparent", "halloween", true, true);
Module['FS_createPath']("/data/images/groundpieces/transparent", "industrial", true, true);
Module['FS_createPath']("/data/images/groundpieces/transparent", "misc", true, true);
Module['FS_createPath']("/data/images/groundpieces/transparent", "snow", true, true);
Module['FS_createPath']("/data/images/groundpieces/transparent", "xmas", true, true);
Module['FS_createPath']("/data/images", "gui", true, true);
Module['FS_createPath']("/data/images/gui", "checkbox", true, true);
Module['FS_createPath']("/data/images/gui", "fonts", true, true);
Module['FS_createPath']("/data/images/gui", "radiobutton", true, true);
Module['FS_createPath']("/data/images", "hotspots", true, true);
Module['FS_createPath']("/data/images/hotspots", "desert", true, true);
Module['FS_createPath']("/data/images/hotspots", "halloween", true, true);
Module['FS_createPath']("/data/images/hotspots", "misc", true, true);
Module['FS_createPath']("/data/images/hotspots", "signposts", true, true);
Module['FS_createPath']("/data/images/hotspots", "space", true, true);
Module['FS_createPath']("/data/images", "icons", true, true);
Module['FS_createPath']("/data/images", "levelsets", true, true);
Module['FS_createPath']("/data/images", "liquids", true, true);
Module['FS_createPath']("/data/images", "other", true, true);
Module['FS_createPath']("/data/images/other", "floaterlayer", true, true);
Module['FS_createPath']("/data/images/other", "laser_kill", true, true);
Module['FS_createPath']("/data/images", "particles", true, true);
Module['FS_createPath']("/data/images", "pingus", true, true);
Module['FS_createPath']("/data/images/pingus", "common", true, true);
Module['FS_createPath']("/data/images/pingus", "player0", true, true);
Module['FS_createPath']("/data/images/pingus/player0", "basher", true, true);
Module['FS_createPath']("/data/images/pingus/player0", "blocker", true, true);
Module['FS_createPath']("/data/images/pingus/player0", "boarder", true, true);
Module['FS_createPath']("/data/images/pingus/player0", "bomber", true, true);
Module['FS_createPath']("/data/images/pingus/player0", "bridger", true, true);
Module['FS_createPath']("/data/images/pingus/player0", "bridger_walk", true, true);
Module['FS_createPath']("/data/images/pingus/player0", "climber", true, true);
Module['FS_createPath']("/data/images/pingus/player0", "digger", true, true);
Module['FS_createPath']("/data/images/pingus/player0", "drownfall", true, true);
Module['FS_createPath']("/data/images/pingus/player0", "drownwalk", true, true);
Module['FS_createPath']("/data/images/pingus/player0", "exit", true, true);
Module['FS_createPath']("/data/images/pingus/player0", "faller", true, true);
Module['FS_createPath']("/data/images/pingus/player0", "floater", true, true);
Module['FS_createPath']("/data/images/pingus/player0", "jumper", true, true);
Module['FS_createPath']("/data/images/pingus/player0", "miner", true, true);
Module['FS_createPath']("/data/images/pingus/player0", "rocketlauncher", true, true);
Module['FS_createPath']("/data/images/pingus/player0", "slider", true, true);
Module['FS_createPath']("/data/images/pingus/player0", "tumbler", true, true);
Module['FS_createPath']("/data/images/pingus/player0", "waiter", true, true);
Module['FS_createPath']("/data/images/pingus/player0", "walker", true, true);
Module['FS_createPath']("/data/images/pingus", "player1", true, true);
Module['FS_createPath']("/data/images/pingus/player1", "basher", true, true);
Module['FS_createPath']("/data/images/pingus/player1", "blocker", true, true);
Module['FS_createPath']("/data/images/pingus/player1", "boarder", true, true);
Module['FS_createPath']("/data/images/pingus/player1", "bomber", true, true);
Module['FS_createPath']("/data/images/pingus/player1", "bridger", true, true);
Module['FS_createPath']("/data/images/pingus/player1", "bridger_walk", true, true);
Module['FS_createPath']("/data/images/pingus/player1", "climber", true, true);
Module['FS_createPath']("/data/images/pingus/player1", "digger", true, true);
Module['FS_createPath']("/data/images/pingus/player1", "drownfall", true, true);
Module['FS_createPath']("/data/images/pingus/player1", "drownwalk", true, true);
Module['FS_createPath']("/data/images/pingus/player1", "exit", true, true);
Module['FS_createPath']("/data/images/pingus/player1", "faller", true, true);
Module['FS_createPath']("/data/images/pingus/player1", "floater", true, true);
Module['FS_createPath']("/data/images/pingus/player1", "jumper", true, true);
Module['FS_createPath']("/data/images/pingus/player1", "miner", true, true);
Module['FS_createPath']("/data/images/pingus/player1", "rocketlauncher", true, true);
Module['FS_createPath']("/data/images/pingus/player1", "slider", true, true);
Module['FS_createPath']("/data/images/pingus/player1", "tumbler", true, true);
Module['FS_createPath']("/data/images/pingus/player1", "waiter", true, true);
Module['FS_createPath']("/data/images/pingus/player1", "walker", true, true);
Module['FS_createPath']("/data/images/pingus", "player2", true, true);
Module['FS_createPath']("/data/images/pingus/player2", "basher", true, true);
Module['FS_createPath']("/data/images/pingus/player2", "blocker", true, true);
Module['FS_createPath']("/data/images/pingus/player2", "boarder", true, true);
Module['FS_createPath']("/data/images/pingus/player2", "bomber", true, true);
Module['FS_createPath']("/data/images/pingus/player2", "bridger", true, true);
Module['FS_createPath']("/data/images/pingus/player2", "bridger_walk", true, true);
Module['FS_createPath']("/data/images/pingus/player2", "climber", true, true);
Module['FS_createPath']("/data/images/pingus/player2", "digger", true, true);
Module['FS_createPath']("/data/images/pingus/player2", "drownfall", true, true);
Module['FS_createPath']("/data/images/pingus/player2", "drownwalk", true, true);
Module['FS_createPath']("/data/images/pingus/player2", "exit", true, true);
Module['FS_createPath']("/data/images/pingus/player2", "faller", true, true);
Module['FS_createPath']("/data/images/pingus/player2", "floater", true, true);
Module['FS_createPath']("/data/images/pingus/player2", "jumper", true, true);
Module['FS_createPath']("/data/images/pingus/player2", "miner", true, true);
Module['FS_createPath']("/data/images/pingus/player2", "rocketlauncher", true, true);
Module['FS_createPath']("/data/images/pingus/player2", "slider", true, true);
Module['FS_createPath']("/data/images/pingus/player2", "tumbler", true, true);
Module['FS_createPath']("/data/images/pingus/player2", "waiter", true, true);
Module['FS_createPath']("/data/images/pingus/player2", "walker", true, true);
Module['FS_createPath']("/data/images/pingus", "player3", true, true);
Module['FS_createPath']("/data/images/pingus/player3", "basher", true, true);
Module['FS_createPath']("/data/images/pingus/player3", "blocker", true, true);
Module['FS_createPath']("/data/images/pingus/player3", "boarder", true, true);
Module['FS_createPath']("/data/images/pingus/player3", "bomber", true, true);
Module['FS_createPath']("/data/images/pingus/player3", "bridger", true, true);
Module['FS_createPath']("/data/images/pingus/player3", "bridger_walk", true, true);
Module['FS_createPath']("/data/images/pingus/player3", "climber", true, true);
Module['FS_createPath']("/data/images/pingus/player3", "digger", true, true);
Module['FS_createPath']("/data/images/pingus/player3", "drownfall", true, true);
Module['FS_createPath']("/data/images/pingus/player3", "drownwalk", true, true);
Module['FS_createPath']("/data/images/pingus/player3", "exit", true, true);
Module['FS_createPath']("/data/images/pingus/player3", "faller", true, true);
Module['FS_createPath']("/data/images/pingus/player3", "floater", true, true);
Module['FS_createPath']("/data/images/pingus/player3", "jumper", true, true);
Module['FS_createPath']("/data/images/pingus/player3", "miner", true, true);
Module['FS_createPath']("/data/images/pingus/player3", "rocketlauncher", true, true);
Module['FS_createPath']("/data/images/pingus/player3", "slider", true, true);
Module['FS_createPath']("/data/images/pingus/player3", "tumbler", true, true);
Module['FS_createPath']("/data/images/pingus/player3", "waiter", true, true);
Module['FS_createPath']("/data/images/pingus/player3", "walker", true, true);
Module['FS_createPath']("/data/images", "prefabs", true, true);
Module['FS_createPath']("/data/images/prefabs", "entrances", true, true);
Module['FS_createPath']("/data/images/prefabs", "liquids", true, true);
Module['FS_createPath']("/data/images/prefabs", "misc", true, true);
Module['FS_createPath']("/data/images", "special", true, true);
Module['FS_createPath']("/data/images/special", "pacman", true, true);
Module['FS_createPath']("/data/images", "story", true, true);
Module['FS_createPath']("/data/images", "textures", true, true);
Module['FS_createPath']("/data/images", "traps", true, true);
Module['FS_createPath']("/data/images/traps", "guillotinekill", true, true);
Module['FS_createPath']("/data/images", "worldmaps", true, true);
Module['FS_createPath']("/data/images/worldmaps", "misc", true, true);
Module['FS_createPath']("/data/images/worldmaps", "tutorial", true, true);
Module['FS_createPath']("/data/images/worldmaps", "volcano", true, true);
Module['FS_createPath']("/data/images", "worldobjs", true, true);
Module['FS_createPath']("/data", "levels", true, true);
Module['FS_createPath']("/data/levels", "alien", true, true);
Module['FS_createPath']("/data/levels", "candy", true, true);
Module['FS_createPath']("/data/levels", "crystal", true, true);
Module['FS_createPath']("/data/levels", "desert", true, true);
Module['FS_createPath']("/data/levels", "easter", true, true);
Module['FS_createPath']("/data/levels", "factorycampaign", true, true);
Module['FS_createPath']("/data/levels", "forest", true, true);
Module['FS_createPath']("/data/levels", "halloween", true, true);
Module['FS_createPath']("/data/levels", "halloween2011", true, true);
Module['FS_createPath']("/data/levels", "hellmouth", true, true);
Module['FS_createPath']("/data/levels", "incoming", true, true);
Module['FS_createPath']("/data/levels", "jungle", true, true);
Module['FS_createPath']("/data/levels", "multiplayer", true, true);
Module['FS_createPath']("/data/levels", "mysteryisland", true, true);
Module['FS_createPath']("/data/levels", "pacman", true, true);
Module['FS_createPath']("/data/levels", "playable", true, true);
Module['FS_createPath']("/data/levels", "snow", true, true);
Module['FS_createPath']("/data/levels", "test", true, true);
Module['FS_createPath']("/data/levels", "tutorial", true, true);
Module['FS_createPath']("/data/levels", "volcano", true, true);
Module['FS_createPath']("/data/levels", "wip", true, true);
Module['FS_createPath']("/data/levels", "xmas2011", true, true);
Module['FS_createPath']("/data/levels", "xskat", true, true);
Module['FS_createPath']("/data/levels/xskat", "new", true, true);
Module['FS_createPath']("/data/levels/xskat/new", "demo", true, true);
Module['FS_createPath']("/data/levels/xskat", "ok", true, true);
Module['FS_createPath']("/data/levels/xskat/ok", "demo", true, true);
Module['FS_createPath']("/data", "levelsets", true, true);
Module['FS_createPath']("/data", "music", true, true);
Module['FS_createPath']("/data", "po", true, true);
Module['FS_createPath']("/data", "prefabs", true, true);
Module['FS_createPath']("/data/prefabs", "entrances", true, true);
Module['FS_createPath']("/data/prefabs", "liquids", true, true);
Module['FS_createPath']("/data/prefabs", "misc", true, true);
Module['FS_createPath']("/data", "sounds", true, true);
Module['FS_createPath']("/data", "stories", true, true);
Module['FS_createPath']("/data", "themes", true, true);
Module['FS_createPath']("/data", "worldmaps", true, true);

      /** @constructor */
      function DataRequest(start, end, audio) {
        this.start = start;
        this.end = end;
        this.audio = audio;
      }
      DataRequest.prototype = {
        requests: {},
        open: function(mode, name) {
          this.name = name;
          this.requests[name] = this;
          Module['addRunDependency'](`fp ${this.name}`);
        },
        send: function() {},
        onload: function() {
          var byteArray = this.byteArray.subarray(this.start, this.end);
          this.finish(byteArray);
        },
        finish: function(byteArray) {
          var that = this;
          // canOwn this data in the filesystem, it is a slide into the heap that will never change
          Module['FS_createDataFile'](this.name, null, byteArray, true, true, true);
          Module['removeRunDependency'](`fp ${that.name}`);
          this.requests[this.name] = null;
        }
      };

      var files = metadata['files'];
      for (var i = 0; i < files.length; ++i) {
        new DataRequest(files[i]['start'], files[i]['end'], files[i]['audio'] || 0).open('GET', files[i]['filename']);
      }

      function processPackageData(arrayBuffer) {
        assert(arrayBuffer, 'Loading data file failed.');
        assert(arrayBuffer.constructor.name === ArrayBuffer.name, 'bad input to processPackageData');
        var byteArray = new Uint8Array(arrayBuffer);
        var curr;
        // Reuse the bytearray from the XHR as the source for file reads.
          DataRequest.prototype.byteArray = byteArray;
          var files = metadata['files'];
          for (var i = 0; i < files.length; ++i) {
            DataRequest.prototype.requests[files[i].filename].onload();
          }          Module['removeRunDependency']('datafile_../dist/index.data');

      };
      Module['addRunDependency']('datafile_../dist/index.data');

      if (!Module.preloadResults) Module.preloadResults = {};

      Module.preloadResults[PACKAGE_NAME] = {fromCache: false};
      if (fetched) {
        processPackageData(fetched);
        fetched = null;
      } else {
        fetchedCallback = processPackageData;
      }

    }
    if (Module['calledRun']) {
      runWithFS(Module);
    } else {
      if (!Module['preRun']) Module['preRun'] = [];
      Module["preRun"].push(runWithFS); // FS is not initialized yet, wait for it
    }

    }
    loadPackage({"files": [{"filename": "/data/README", "start": 0, "end": 385}, {"filename": "/data/controller/default.scm", "start": 385, "end": 1893}, {"filename": "/data/controller/usbmouse.scm", "start": 1893, "end": 2695}, {"filename": "/data/controller/wiimote.scm", "start": 2695, "end": 3495}, {"filename": "/data/controller/xbox360.scm", "start": 3495, "end": 4500}, {"filename": "/data/controller/xinput.scm", "start": 4500, "end": 4835}, {"filename": "/data/credits/pingus.credits", "start": 4835, "end": 6406}, {"filename": "/data/images/XMas/walker.sprite", "start": 6406, "end": 6528}, {"filename": "/data/images/backgrounds/large_star.png", "start": 6528, "end": 6821}, {"filename": "/data/images/backgrounds/middle_star.png", "start": 6821, "end": 6955}, {"filename": "/data/images/backgrounds/small_star.png", "start": 6955, "end": 7094}, {"filename": "/data/images/backgrounds/starfield_icon.png", "start": 7094, "end": 7759}, {"filename": "/data/images/core/buttons/armageddon_anim.png", "start": 7759, "end": 41034}, {"filename": "/data/images/core/buttons/armageddon_anim.sprite", "start": 41034, "end": 41139}, {"filename": "/data/images/core/buttons/buttonbackground.png", "start": 41139, "end": 41966}, {"filename": "/data/images/core/buttons/buttonbackgroundhl.png", "start": 41966, "end": 43452}, {"filename": "/data/images/core/buttons/fast_forward.png", "start": 43452, "end": 48758}, {"filename": "/data/images/core/buttons/hbuttonbg.png", "start": 48758, "end": 50308}, {"filename": "/data/images/core/buttons/hbuttonbgb.png", "start": 50308, "end": 51166}, {"filename": "/data/images/core/buttons/info.png", "start": 51166, "end": 54169}, {"filename": "/data/images/core/buttons/info.sprite", "start": 54169, "end": 54231}, {"filename": "/data/images/core/buttons/pause.png", "start": 54231, "end": 57221}, {"filename": "/data/images/core/cursors/animcross.png", "start": 57221, "end": 59710}, {"filename": "/data/images/core/cursors/animcross.sprite", "start": 59710, "end": 59769}, {"filename": "/data/images/core/cursors/animcross2.sprite", "start": 59769, "end": 59872}, {"filename": "/data/images/core/cursors/arrow_left.png", "start": 59872, "end": 60259}, {"filename": "/data/images/core/cursors/arrow_right.png", "start": 60259, "end": 60647}, {"filename": "/data/images/core/cursors/cap.png", "start": 60647, "end": 61744}, {"filename": "/data/images/core/cursors/capbad.sprite", "start": 61744, "end": 61786}, {"filename": "/data/images/core/cursors/capgood.sprite", "start": 61786, "end": 61823}, {"filename": "/data/images/core/cursors/capture.png", "start": 61823, "end": 66632}, {"filename": "/data/images/core/cursors/capwrong.png", "start": 66632, "end": 67730}, {"filename": "/data/images/core/cursors/cross.png", "start": 67730, "end": 68476}, {"filename": "/data/images/core/cursors/cross.sprite", "start": 68476, "end": 68535}, {"filename": "/data/images/core/cursors/cursor.png", "start": 68535, "end": 68687}, {"filename": "/data/images/core/cursors/editor.png", "start": 68687, "end": 68834}, {"filename": "/data/images/core/cursors/scroll.png", "start": 68834, "end": 69203}, {"filename": "/data/images/core/cursors/scroll_cur.sprite", "start": 69203, "end": 69263}, {"filename": "/data/images/core/demo/fastforward-hover.png", "start": 69263, "end": 70191}, {"filename": "/data/images/core/demo/fastforward-pressed.png", "start": 70191, "end": 71147}, {"filename": "/data/images/core/demo/fastforward.png", "start": 71147, "end": 72133}, {"filename": "/data/images/core/demo/highlight.png", "start": 72133, "end": 72556}, {"filename": "/data/images/core/demo/pause-hover.png", "start": 72556, "end": 73061}, {"filename": "/data/images/core/demo/pause-pressed.png", "start": 73061, "end": 73515}, {"filename": "/data/images/core/demo/pause.png", "start": 73515, "end": 73983}, {"filename": "/data/images/core/demo/reload-hover.png", "start": 73983, "end": 74660}, {"filename": "/data/images/core/demo/reload-pressed.png", "start": 74660, "end": 75312}, {"filename": "/data/images/core/demo/reload.png", "start": 75312, "end": 75955}, {"filename": "/data/images/core/editor/actions.png", "start": 75955, "end": 76708}, {"filename": "/data/images/core/editor/button-pressed.png", "start": 76708, "end": 77164}, {"filename": "/data/images/core/editor/button-raised.png", "start": 77164, "end": 77725}, {"filename": "/data/images/core/editor/button.png", "start": 77725, "end": 77925}, {"filename": "/data/images/core/editor/button_pressed.png", "start": 77925, "end": 78045}, {"filename": "/data/images/core/editor/clock_run.sprite", "start": 78045, "end": 78091}, {"filename": "/data/images/core/editor/combobox.png", "start": 78091, "end": 78338}, {"filename": "/data/images/core/editor/copy.sprite", "start": 78338, "end": 78381}, {"filename": "/data/images/core/editor/delete.sprite", "start": 78381, "end": 78426}, {"filename": "/data/images/core/editor/document-new.png", "start": 78426, "end": 79426}, {"filename": "/data/images/core/editor/document-open.png", "start": 79426, "end": 80309}, {"filename": "/data/images/core/editor/document-properties.png", "start": 80309, "end": 81346}, {"filename": "/data/images/core/editor/document-save-as.png", "start": 81346, "end": 82363}, {"filename": "/data/images/core/editor/document-save.png", "start": 82363, "end": 83208}, {"filename": "/data/images/core/editor/edit-copy.png", "start": 83208, "end": 83712}, {"filename": "/data/images/core/editor/edit-delete.png", "start": 83712, "end": 84936}, {"filename": "/data/images/core/editor/edit.sprite", "start": 84936, "end": 84977}, {"filename": "/data/images/core/editor/exit.png", "start": 84977, "end": 85912}, {"filename": "/data/images/core/editor/exit.sprite", "start": 85912, "end": 85953}, {"filename": "/data/images/core/editor/help.png", "start": 85953, "end": 87130}, {"filename": "/data/images/core/editor/home.png", "start": 87130, "end": 87395}, {"filename": "/data/images/core/editor/index.sprite", "start": 87395, "end": 87437}, {"filename": "/data/images/core/editor/list-add.png", "start": 87437, "end": 87926}, {"filename": "/data/images/core/editor/list-remove.png", "start": 87926, "end": 88233}, {"filename": "/data/images/core/editor/logo.png", "start": 88233, "end": 90310}, {"filename": "/data/images/core/editor/minimap.png", "start": 90310, "end": 90849}, {"filename": "/data/images/core/editor/new.sprite", "start": 90849, "end": 90889}, {"filename": "/data/images/core/editor/obj_background.png", "start": 90889, "end": 92457}, {"filename": "/data/images/core/editor/obj_button-pressed.png", "start": 92457, "end": 92965}, {"filename": "/data/images/core/editor/obj_button-raised.png", "start": 92965, "end": 93517}, {"filename": "/data/images/core/editor/obj_button.png", "start": 93517, "end": 93711}, {"filename": "/data/images/core/editor/obj_entrance.png", "start": 93711, "end": 94768}, {"filename": "/data/images/core/editor/obj_exit.png", "start": 94768, "end": 96184}, {"filename": "/data/images/core/editor/obj_gp_bridge.png", "start": 96184, "end": 96469}, {"filename": "/data/images/core/editor/obj_gp_ground.png", "start": 96469, "end": 98161}, {"filename": "/data/images/core/editor/obj_gp_remove.png", "start": 98161, "end": 98710}, {"filename": "/data/images/core/editor/obj_gp_solid.png", "start": 98710, "end": 99916}, {"filename": "/data/images/core/editor/obj_gp_transparent.png", "start": 99916, "end": 101045}, {"filename": "/data/images/core/editor/obj_hotspot.png", "start": 101045, "end": 102386}, {"filename": "/data/images/core/editor/obj_liquid.png", "start": 102386, "end": 103494}, {"filename": "/data/images/core/editor/obj_prefab.png", "start": 103494, "end": 104980}, {"filename": "/data/images/core/editor/obj_trap.png", "start": 104980, "end": 106133}, {"filename": "/data/images/core/editor/obj_weather.png", "start": 106133, "end": 107559}, {"filename": "/data/images/core/editor/obj_worldobj.png", "start": 107559, "end": 109172}, {"filename": "/data/images/core/editor/object-bottom.png", "start": 109172, "end": 110016}, {"filename": "/data/images/core/editor/object-down.png", "start": 110016, "end": 110895}, {"filename": "/data/images/core/editor/object-flip-horizontal.sprite", "start": 110895, "end": 110951}, {"filename": "/data/images/core/editor/object-flip-vertical.sprite", "start": 110951, "end": 111005}, {"filename": "/data/images/core/editor/object-flip_horizontal.png", "start": 111005, "end": 111961}, {"filename": "/data/images/core/editor/object-flip_vertical.png", "start": 111961, "end": 112935}, {"filename": "/data/images/core/editor/object-properties.png", "start": 112935, "end": 114599}, {"filename": "/data/images/core/editor/object-rotate-left.sprite", "start": 114599, "end": 114651}, {"filename": "/data/images/core/editor/object-rotate-right.sprite", "start": 114651, "end": 114704}, {"filename": "/data/images/core/editor/object-rotate_left.png", "start": 114704, "end": 115644}, {"filename": "/data/images/core/editor/object-rotate_right.png", "start": 115644, "end": 116650}, {"filename": "/data/images/core/editor/object-top.png", "start": 116650, "end": 117463}, {"filename": "/data/images/core/editor/object-up.png", "start": 117463, "end": 118333}, {"filename": "/data/images/core/editor/objects.png", "start": 118333, "end": 119817}, {"filename": "/data/images/core/editor/open.sprite", "start": 119817, "end": 119858}, {"filename": "/data/images/core/editor/play.png", "start": 119858, "end": 120225}, {"filename": "/data/images/core/editor/preferences.sprite", "start": 120225, "end": 120273}, {"filename": "/data/images/core/editor/save.sprite", "start": 120273, "end": 120314}, {"filename": "/data/images/core/editor/separator.png", "start": 120314, "end": 120641}, {"filename": "/data/images/core/editor/snap-grid.png", "start": 120641, "end": 121268}, {"filename": "/data/images/core/editor/solidcolorbackground.png", "start": 121268, "end": 124856}, {"filename": "/data/images/core/editor/solidcolorbackground_thumb.png", "start": 124856, "end": 125917}, {"filename": "/data/images/core/editor/starfield.png", "start": 125917, "end": 132355}, {"filename": "/data/images/core/editor/starfield_thumb.png", "start": 132355, "end": 133542}, {"filename": "/data/images/core/editor/start_pos.png", "start": 133542, "end": 133939}, {"filename": "/data/images/core/editor/tb_exit.png", "start": 133939, "end": 134134}, {"filename": "/data/images/core/editor/weather_rain.png", "start": 134134, "end": 136839}, {"filename": "/data/images/core/editor/weather_snow.png", "start": 136839, "end": 137338}, {"filename": "/data/images/core/editor/zoom-best-fit.png", "start": 137338, "end": 138694}, {"filename": "/data/images/core/editor/zoom-in.png", "start": 138694, "end": 139975}, {"filename": "/data/images/core/editor/zoom-original.png", "start": 139975, "end": 141239}, {"filename": "/data/images/core/editor/zoom-out.png", "start": 141239, "end": 142472}, {"filename": "/data/images/core/menu/arrow_down.png", "start": 142472, "end": 144829}, {"filename": "/data/images/core/menu/arrow_down_hover.png", "start": 144829, "end": 146901}, {"filename": "/data/images/core/menu/arrow_down_pressed.png", "start": 146901, "end": 149036}, {"filename": "/data/images/core/menu/arrow_left.png", "start": 149036, "end": 151202}, {"filename": "/data/images/core/menu/arrow_left_hover.png", "start": 151202, "end": 153116}, {"filename": "/data/images/core/menu/arrow_left_pressed.png", "start": 153116, "end": 155245}, {"filename": "/data/images/core/menu/arrow_right.png", "start": 155245, "end": 157482}, {"filename": "/data/images/core/menu/arrow_right_hover.png", "start": 157482, "end": 159483}, {"filename": "/data/images/core/menu/arrow_right_pressed.png", "start": 159483, "end": 161610}, {"filename": "/data/images/core/menu/arrow_up.png", "start": 161610, "end": 163887}, {"filename": "/data/images/core/menu/arrow_up_hover.png", "start": 163887, "end": 165897}, {"filename": "/data/images/core/menu/arrow_up_pressed.png", "start": 165897, "end": 168014}, {"filename": "/data/images/core/menu/blackboard.png", "start": 168014, "end": 531337}, {"filename": "/data/images/core/menu/blackboard.sprite", "start": 531337, "end": 531401}, {"filename": "/data/images/core/menu/checkbox_marked_small.png", "start": 531401, "end": 532673}, {"filename": "/data/images/core/menu/checkbox_small.png", "start": 532673, "end": 533526}, {"filename": "/data/images/core/menu/exit_button_hover.png", "start": 533526, "end": 535483}, {"filename": "/data/images/core/menu/exit_button_normal.png", "start": 535483, "end": 536732}, {"filename": "/data/images/core/menu/exit_button_pressed.png", "start": 536732, "end": 538715}, {"filename": "/data/images/core/menu/layer1.png", "start": 538715, "end": 684312}, {"filename": "/data/images/core/menu/layer2.png", "start": 684312, "end": 808108}, {"filename": "/data/images/core/menu/layer3.png", "start": 808108, "end": 908247}, {"filename": "/data/images/core/menu/layer4.png", "start": 908247, "end": 981481}, {"filename": "/data/images/core/menu/layer5.png", "start": 981481, "end": 998525}, {"filename": "/data/images/core/menu/locked_small.png", "start": 998525, "end": 999600}, {"filename": "/data/images/core/menu/marker.png", "start": 999600, "end": 1029419}, {"filename": "/data/images/core/menu/marker2.png", "start": 1029419, "end": 1038741}, {"filename": "/data/images/core/menu/marker_locked.png", "start": 1038741, "end": 1040267}, {"filename": "/data/images/core/menu/menuitem.png", "start": 1040267, "end": 1046268}, {"filename": "/data/images/core/menu/menuitem.sprite", "start": 1046268, "end": 1046330}, {"filename": "/data/images/core/menu/menuitem_highlight.png", "start": 1046330, "end": 1055996}, {"filename": "/data/images/core/menu/menuitem_highlight.sprite", "start": 1055996, "end": 1056068}, {"filename": "/data/images/core/menu/startscreenbg.sprite", "start": 1056068, "end": 1056135}, {"filename": "/data/images/core/menu/wood.png", "start": 1056135, "end": 1150201}, {"filename": "/data/images/core/misc/404.png", "start": 1150201, "end": 1150907}, {"filename": "/data/images/core/misc/404sprite.sprite", "start": 1150907, "end": 1150944}, {"filename": "/data/images/core/misc/chalk_pingu1.png", "start": 1150944, "end": 1151931}, {"filename": "/data/images/core/misc/chalk_pingu2.png", "start": 1151931, "end": 1152835}, {"filename": "/data/images/core/misc/chalk_pingu3.png", "start": 1152835, "end": 1153927}, {"filename": "/data/images/core/misc/chalk_pingu4.png", "start": 1153927, "end": 1154839}, {"filename": "/data/images/core/misc/checkbox_clicked.png", "start": 1154839, "end": 1155306}, {"filename": "/data/images/core/misc/creditpingu.png", "start": 1155306, "end": 1165402}, {"filename": "/data/images/core/misc/creditpingu.sprite", "start": 1165402, "end": 1165467}, {"filename": "/data/images/core/misc/flag0.png", "start": 1165467, "end": 1166466}, {"filename": "/data/images/core/misc/flag0.sprite", "start": 1166466, "end": 1166532}, {"filename": "/data/images/core/misc/flag1.png", "start": 1166532, "end": 1167596}, {"filename": "/data/images/core/misc/flag1.sprite", "start": 1167596, "end": 1167662}, {"filename": "/data/images/core/misc/flag2.png", "start": 1167662, "end": 1167980}, {"filename": "/data/images/core/misc/flag2.sprite", "start": 1167980, "end": 1168046}, {"filename": "/data/images/core/misc/flag3.png", "start": 1168046, "end": 1168464}, {"filename": "/data/images/core/misc/flag3.sprite", "start": 1168464, "end": 1168530}, {"filename": "/data/images/core/misc/infinity.png", "start": 1168530, "end": 1169091}, {"filename": "/data/images/core/misc/loading.png", "start": 1169091, "end": 1170387}, {"filename": "/data/images/core/misc/logo.png", "start": 1170387, "end": 1301943}, {"filename": "/data/images/core/misc/next.png", "start": 1301943, "end": 1303334}, {"filename": "/data/images/core/misc/next_hover.png", "start": 1303334, "end": 1303855}, {"filename": "/data/images/core/misc/pingubw.png", "start": 1303855, "end": 1306698}, {"filename": "/data/images/core/misc/smallmap_entrance.png", "start": 1306698, "end": 1306813}, {"filename": "/data/images/core/misc/smallmap_entrance.sprite", "start": 1306813, "end": 1306891}, {"filename": "/data/images/core/misc/smallmap_exit.png", "start": 1306891, "end": 1307007}, {"filename": "/data/images/core/misc/smallmap_exit.sprite", "start": 1307007, "end": 1307081}, {"filename": "/data/images/core/misc/start_back.png", "start": 1307081, "end": 1315624}, {"filename": "/data/images/core/misc/start_back_clicked.png", "start": 1315624, "end": 1318219}, {"filename": "/data/images/core/misc/start_back_hover.png", "start": 1318219, "end": 1328170}, {"filename": "/data/images/core/misc/start_ok.png", "start": 1328170, "end": 1329689}, {"filename": "/data/images/core/misc/start_ok_clicked.png", "start": 1329689, "end": 1332223}, {"filename": "/data/images/core/misc/start_ok_hover.png", "start": 1332223, "end": 1334936}, {"filename": "/data/images/core/misc/unplayable.png", "start": 1334936, "end": 1342727}, {"filename": "/data/images/core/misc/unplayable.sprite", "start": 1342727, "end": 1342798}, {"filename": "/data/images/core/misc/unplayable2.png", "start": 1342798, "end": 1345866}, {"filename": "/data/images/core/start/back.sprite", "start": 1345866, "end": 1345928}, {"filename": "/data/images/core/start/back_clicked.sprite", "start": 1345928, "end": 1345998}, {"filename": "/data/images/core/start/back_hover.sprite", "start": 1345998, "end": 1346066}, {"filename": "/data/images/core/start/ok.sprite", "start": 1346066, "end": 1346126}, {"filename": "/data/images/core/start/ok_clicked.sprite", "start": 1346126, "end": 1346194}, {"filename": "/data/images/core/start/ok_hover.sprite", "start": 1346194, "end": 1346260}, {"filename": "/data/images/core/worldmap/arrow.png", "start": 1346260, "end": 1346870}, {"filename": "/data/images/core/worldmap/arrow.sprite", "start": 1346870, "end": 1346936}, {"filename": "/data/images/core/worldmap/credits_button_hover.png", "start": 1346936, "end": 1352725}, {"filename": "/data/images/core/worldmap/credits_button_normal.png", "start": 1352725, "end": 1358104}, {"filename": "/data/images/core/worldmap/credits_button_pressed.png", "start": 1358104, "end": 1363967}, {"filename": "/data/images/core/worldmap/dot_green.png", "start": 1363967, "end": 1364954}, {"filename": "/data/images/core/worldmap/dot_green.sprite", "start": 1364954, "end": 1365017}, {"filename": "/data/images/core/worldmap/dot_green_hl.png", "start": 1365017, "end": 1366000}, {"filename": "/data/images/core/worldmap/dot_green_hl.sprite", "start": 1366000, "end": 1366066}, {"filename": "/data/images/core/worldmap/dot_invalid.png", "start": 1366066, "end": 1366458}, {"filename": "/data/images/core/worldmap/dot_invalid.sprite", "start": 1366458, "end": 1366523}, {"filename": "/data/images/core/worldmap/dot_red.png", "start": 1366523, "end": 1367501}, {"filename": "/data/images/core/worldmap/dot_red.sprite", "start": 1367501, "end": 1367562}, {"filename": "/data/images/core/worldmap/dot_red_hl.png", "start": 1367562, "end": 1368548}, {"filename": "/data/images/core/worldmap/dot_red_hl.sprite", "start": 1368548, "end": 1368612}, {"filename": "/data/images/core/worldmap/enter_button_hover.png", "start": 1368612, "end": 1373906}, {"filename": "/data/images/core/worldmap/enter_button_normal.png", "start": 1373906, "end": 1378846}, {"filename": "/data/images/core/worldmap/enter_button_pressed.png", "start": 1378846, "end": 1384146}, {"filename": "/data/images/core/worldmap/flaggreen.png", "start": 1384146, "end": 1385219}, {"filename": "/data/images/core/worldmap/flaggreen.sprite", "start": 1385219, "end": 1385282}, {"filename": "/data/images/core/worldmap/leave_button_hover.png", "start": 1385282, "end": 1390702}, {"filename": "/data/images/core/worldmap/leave_button_normal.png", "start": 1390702, "end": 1395755}, {"filename": "/data/images/core/worldmap/leave_button_pressed.png", "start": 1395755, "end": 1401152}, {"filename": "/data/images/core/worldmap/levelname_bg.png", "start": 1401152, "end": 1412958}, {"filename": "/data/images/core/worldmap/pingus.png", "start": 1412958, "end": 1422313}, {"filename": "/data/images/core/worldmap/pingus/left.sprite", "start": 1422313, "end": 1422452}, {"filename": "/data/images/core/worldmap/pingus/right.sprite", "start": 1422452, "end": 1422609}, {"filename": "/data/images/core/worldmap/pingus_standing.png", "start": 1422609, "end": 1423627}, {"filename": "/data/images/core/worldmap/pingus_standing.sprite", "start": 1423627, "end": 1423703}, {"filename": "/data/images/core/worldmap/story_button_hover.png", "start": 1423703, "end": 1429418}, {"filename": "/data/images/core/worldmap/story_button_normal.png", "start": 1429418, "end": 1434764}, {"filename": "/data/images/core/worldmap/story_button_pressed.png", "start": 1434764, "end": 1440576}, {"filename": "/data/images/core/worldmap/story_dot.png", "start": 1440576, "end": 1441592}, {"filename": "/data/images/core/worldmap/story_dot.sprite", "start": 1441592, "end": 1441655}, {"filename": "/data/images/core/worldmap/story_dot_highlight.png", "start": 1441655, "end": 1442666}, {"filename": "/data/images/core/worldmap/story_dot_highlight.sprite", "start": 1442666, "end": 1442739}, {"filename": "/data/images/core/worldmap/tube.png", "start": 1442739, "end": 1444214}, {"filename": "/data/images/entrances/cloud.png", "start": 1444214, "end": 1450146}, {"filename": "/data/images/entrances/cloud.sprite", "start": 1450146, "end": 1450185}, {"filename": "/data/images/entrances/desert_back.png", "start": 1450185, "end": 1467276}, {"filename": "/data/images/entrances/desert_front.png", "start": 1467276, "end": 1481761}, {"filename": "/data/images/entrances/easter.png", "start": 1481761, "end": 1487715}, {"filename": "/data/images/entrances/entrance.png", "start": 1487715, "end": 1487898}, {"filename": "/data/images/entrances/entrance_eyes.sprite", "start": 1487898, "end": 1487945}, {"filename": "/data/images/entrances/entrance_eyes_anim.sprite", "start": 1487945, "end": 1488053}, {"filename": "/data/images/entrances/eyes_entrance.png", "start": 1488053, "end": 1520750}, {"filename": "/data/images/entrances/eyes_entrance_anim.png", "start": 1520750, "end": 1538390}, {"filename": "/data/images/entrances/eyes_underlay.png", "start": 1538390, "end": 1541376}, {"filename": "/data/images/entrances/generic.png", "start": 1541376, "end": 1541700}, {"filename": "/data/images/entrances/generic.sprite", "start": 1541700, "end": 1541768}, {"filename": "/data/images/entrances/halloween.png", "start": 1541768, "end": 1547214}, {"filename": "/data/images/entrances/industrial.png", "start": 1547214, "end": 1560473}, {"filename": "/data/images/entrances/industrial_top.png", "start": 1560473, "end": 1561835}, {"filename": "/data/images/entrances/snow_back.png", "start": 1561835, "end": 1566430}, {"filename": "/data/images/entrances/snow_front.png", "start": 1566430, "end": 1570566}, {"filename": "/data/images/entrances/space.png", "start": 1570566, "end": 1588111}, {"filename": "/data/images/entrances/space.sprite", "start": 1588111, "end": 1588205}, {"filename": "/data/images/entrances/underlay_eyes.sprite", "start": 1588205, "end": 1588252}, {"filename": "/data/images/entrances/wood_bottom.png", "start": 1588252, "end": 1593424}, {"filename": "/data/images/entrances/wood_top.png", "start": 1593424, "end": 1597351}, {"filename": "/data/images/entrances/woodthing_mov.png", "start": 1597351, "end": 1607468}, {"filename": "/data/images/entrances/woodthing_mov.sprite", "start": 1607468, "end": 1607572}, {"filename": "/data/images/entrances/woodthing_nmov.png", "start": 1607572, "end": 1622329}, {"filename": "/data/images/entrances/xmas_back.png", "start": 1622329, "end": 1626435}, {"filename": "/data/images/entrances/xmas_front.png", "start": 1626435, "end": 1629302}, {"filename": "/data/images/exits/crystal.png", "start": 1629302, "end": 1639020}, {"filename": "/data/images/exits/crystal.sprite", "start": 1639020, "end": 1639088}, {"filename": "/data/images/exits/desert.sprite", "start": 1639088, "end": 1639159}, {"filename": "/data/images/exits/desert_tut.png", "start": 1639159, "end": 1661538}, {"filename": "/data/images/exits/desert_tut.sprite", "start": 1661538, "end": 1661609}, {"filename": "/data/images/exits/desertexit.png", "start": 1661609, "end": 1668171}, {"filename": "/data/images/exits/easter.png", "start": 1668171, "end": 1672354}, {"filename": "/data/images/exits/easter.sprite", "start": 1672354, "end": 1672421}, {"filename": "/data/images/exits/forest.png", "start": 1672421, "end": 1678620}, {"filename": "/data/images/exits/forest.sprite", "start": 1678620, "end": 1678687}, {"filename": "/data/images/exits/halloween.png", "start": 1678687, "end": 1686270}, {"filename": "/data/images/exits/halloween.sprite", "start": 1686270, "end": 1686340}, {"filename": "/data/images/exits/ice.png", "start": 1686340, "end": 1689630}, {"filename": "/data/images/exits/ice.sprite", "start": 1689630, "end": 1689694}, {"filename": "/data/images/exits/ice2.png", "start": 1689694, "end": 1695041}, {"filename": "/data/images/exits/ice2.sprite", "start": 1695041, "end": 1695106}, {"filename": "/data/images/exits/industrial.png", "start": 1695106, "end": 1704323}, {"filename": "/data/images/exits/industrial.sprite", "start": 1704323, "end": 1704394}, {"filename": "/data/images/exits/mud.png", "start": 1704394, "end": 1717420}, {"filename": "/data/images/exits/mud.sprite", "start": 1717420, "end": 1717484}, {"filename": "/data/images/exits/ordina.png", "start": 1717484, "end": 1723687}, {"filename": "/data/images/exits/ordina.sprite", "start": 1723687, "end": 1723754}, {"filename": "/data/images/exits/pwexit.png", "start": 1723754, "end": 1726372}, {"filename": "/data/images/exits/sortie.png", "start": 1726372, "end": 1731529}, {"filename": "/data/images/exits/sortie.sprite", "start": 1731529, "end": 1731596}, {"filename": "/data/images/exits/sortie_anim.png", "start": 1731596, "end": 1747099}, {"filename": "/data/images/exits/sortie_anim.sprite", "start": 1747099, "end": 1747227}, {"filename": "/data/images/exits/space.png", "start": 1747227, "end": 1777582}, {"filename": "/data/images/exits/space.sprite", "start": 1777582, "end": 1777705}, {"filename": "/data/images/exits/stone.png", "start": 1777705, "end": 1781275}, {"filename": "/data/images/exits/stone.sprite", "start": 1781275, "end": 1781341}, {"filename": "/data/images/exits/sweetexit.png", "start": 1781341, "end": 1790323}, {"filename": "/data/images/exits/sweetexit.sprite", "start": 1790323, "end": 1790393}, {"filename": "/data/images/exits/xmas.png", "start": 1790393, "end": 1797599}, {"filename": "/data/images/exits/xmas.sprite", "start": 1797599, "end": 1797664}, {"filename": "/data/images/fonts/README", "start": 1797664, "end": 1799262}, {"filename": "/data/images/fonts/buildset.py", "start": 1799262, "end": 1799417}, {"filename": "/data/images/fonts/chalk-16px.font", "start": 1799417, "end": 1901688}, {"filename": "/data/images/fonts/chalk-16px.png", "start": 1901688, "end": 1950535}, {"filename": "/data/images/fonts/chalk-20px.font", "start": 1950535, "end": 2053209}, {"filename": "/data/images/fonts/chalk-20px.png", "start": 2053209, "end": 2115184}, {"filename": "/data/images/fonts/chalk-40px.font", "start": 2115184, "end": 2218738}, {"filename": "/data/images/fonts/chalk-40px.png", "start": 2218738, "end": 2364331}, {"filename": "/data/images/fonts/chalk-cjk-16px.png", "start": 2364331, "end": 2508476}, {"filename": "/data/images/fonts/chalk-cjk-20px.png", "start": 2508476, "end": 2705773}, {"filename": "/data/images/fonts/chalk-cjk-40px.png", "start": 2705773, "end": 3174816}, {"filename": "/data/images/fonts/characters-cjk.txt", "start": 3174816, "end": 3177748}, {"filename": "/data/images/fonts/characters.txt", "start": 3177748, "end": 3179273}, {"filename": "/data/images/fonts/pingus-small-20px.font", "start": 3179273, "end": 3282122}, {"filename": "/data/images/fonts/pingus-small-20px.png", "start": 3282122, "end": 3392013}, {"filename": "/data/images/fonts/pingus-small-cjk-20px.png", "start": 3392013, "end": 3801031}, {"filename": "/data/images/fonts/substractchars.py", "start": 3801031, "end": 3801420}, {"filename": "/data/images/fonts/verdana11-cjk.png", "start": 3801420, "end": 3877119}, {"filename": "/data/images/fonts/verdana11.font", "start": 3877119, "end": 3988766}, {"filename": "/data/images/fonts/verdana11.png", "start": 3988766, "end": 4004749}, {"filename": "/data/images/game/404.sprite", "start": 4004749, "end": 4004804}, {"filename": "/data/images/game/cursors/arrow_left.sprite", "start": 4004804, "end": 4004905}, {"filename": "/data/images/game/cursors/arrow_right.sprite", "start": 4004905, "end": 4005007}, {"filename": "/data/images/game/cursors/capbad.sprite", "start": 4005007, "end": 4005090}, {"filename": "/data/images/game/cursors/capgood.sprite", "start": 4005090, "end": 4005168}, {"filename": "/data/images/game/cursors/cross.sprite", "start": 4005168, "end": 4005248}, {"filename": "/data/images/game/cursors/cursor.sprite", "start": 4005248, "end": 4005309}, {"filename": "/data/images/game/cursors/editor.sprite", "start": 4005309, "end": 4005370}, {"filename": "/data/images/game/cursors/scroll_cur.sprite", "start": 4005370, "end": 4005431}, {"filename": "/data/images/game/dot_green.sprite", "start": 4005431, "end": 4005496}, {"filename": "/data/images/game/dot_red.sprite", "start": 4005496, "end": 4005559}, {"filename": "/data/images/game/loading.sprite", "start": 4005559, "end": 4005618}, {"filename": "/data/images/game/pingubw.sprite", "start": 4005618, "end": 4005677}, {"filename": "/data/images/game/smallmap/entrance.sprite", "start": 4005677, "end": 4005746}, {"filename": "/data/images/game/smallmap/exit.sprite", "start": 4005746, "end": 4005811}, {"filename": "/data/images/game/stars/large_star.sprite", "start": 4005811, "end": 4005875}, {"filename": "/data/images/game/stars/middle_star.sprite", "start": 4005875, "end": 4005940}, {"filename": "/data/images/game/stars/small_star.sprite", "start": 4005940, "end": 4006004}, {"filename": "/data/images/game/stars/starfield_icon.sprite", "start": 4006004, "end": 4006072}, {"filename": "/data/images/groundpieces/bridge/misc/bridge_left.png", "start": 4006072, "end": 4006242}, {"filename": "/data/images/groundpieces/bridge/misc/bridge_right.png", "start": 4006242, "end": 4006411}, {"filename": "/data/images/groundpieces/bridge/space/grid1.png", "start": 4006411, "end": 4006947}, {"filename": "/data/images/groundpieces/bridge/space/grid2.png", "start": 4006947, "end": 4007472}, {"filename": "/data/images/groundpieces/bridge/space/grid3.png", "start": 4007472, "end": 4007900}, {"filename": "/data/images/groundpieces/ground/crystal/block.png", "start": 4007900, "end": 4009265}, {"filename": "/data/images/groundpieces/ground/crystal/column.png", "start": 4009265, "end": 4011720}, {"filename": "/data/images/groundpieces/ground/crystal/diagcrystal.png", "start": 4011720, "end": 4019812}, {"filename": "/data/images/groundpieces/ground/crystal/hexcrystal.png", "start": 4019812, "end": 4030614}, {"filename": "/data/images/groundpieces/ground/crystal/horiz.png", "start": 4030614, "end": 4032777}, {"filename": "/data/images/groundpieces/ground/crystal/horiz2.png", "start": 4032777, "end": 4034971}, {"filename": "/data/images/groundpieces/ground/crystal/pipe.png", "start": 4034971, "end": 4038358}, {"filename": "/data/images/groundpieces/ground/crystal/pipeend.png", "start": 4038358, "end": 4040422}, {"filename": "/data/images/groundpieces/ground/crystal/platform.png", "start": 4040422, "end": 4046585}, {"filename": "/data/images/groundpieces/ground/crystal/platform2.png", "start": 4046585, "end": 4050720}, {"filename": "/data/images/groundpieces/ground/crystal/pointleft.png", "start": 4050720, "end": 4051777}, {"filename": "/data/images/groundpieces/ground/crystal/pointright.png", "start": 4051777, "end": 4052811}, {"filename": "/data/images/groundpieces/ground/crystal/skinnycrystal.png", "start": 4052811, "end": 4059758}, {"filename": "/data/images/groundpieces/ground/crystal/smcrystal.png", "start": 4059758, "end": 4063312}, {"filename": "/data/images/groundpieces/ground/crystal/tesselate.png", "start": 4063312, "end": 4066882}, {"filename": "/data/images/groundpieces/ground/desert/bigblock-broken1.png", "start": 4066882, "end": 4099013}, {"filename": "/data/images/groundpieces/ground/desert/bigblock-broken2.png", "start": 4099013, "end": 4123979}, {"filename": "/data/images/groundpieces/ground/desert/bigblock-broken3.png", "start": 4123979, "end": 4161556}, {"filename": "/data/images/groundpieces/ground/desert/bigdune1.png", "start": 4161556, "end": 4183452}, {"filename": "/data/images/groundpieces/ground/desert/bigprickpiece.png", "start": 4183452, "end": 4215033}, {"filename": "/data/images/groundpieces/ground/desert/bigsand.png", "start": 4215033, "end": 4256604}, {"filename": "/data/images/groundpieces/ground/desert/blobdune.png", "start": 4256604, "end": 4258971}, {"filename": "/data/images/groundpieces/ground/desert/column.png", "start": 4258971, "end": 4261050}, {"filename": "/data/images/groundpieces/ground/desert/column_piece1.png", "start": 4261050, "end": 4266110}, {"filename": "/data/images/groundpieces/ground/desert/column_piece2.png", "start": 4266110, "end": 4271791}, {"filename": "/data/images/groundpieces/ground/desert/column_piece3.png", "start": 4271791, "end": 4281245}, {"filename": "/data/images/groundpieces/ground/desert/domedune.png", "start": 4281245, "end": 4285007}, {"filename": "/data/images/groundpieces/ground/desert/flat.png", "start": 4285007, "end": 4287472}, {"filename": "/data/images/groundpieces/ground/desert/flatdune.png", "start": 4287472, "end": 4290530}, {"filename": "/data/images/groundpieces/ground/desert/leftsmallbrick.png", "start": 4290530, "end": 4292849}, {"filename": "/data/images/groundpieces/ground/desert/leftsmallsand.png", "start": 4292849, "end": 4294521}, {"filename": "/data/images/groundpieces/ground/desert/mediumsand.png", "start": 4294521, "end": 4303067}, {"filename": "/data/images/groundpieces/ground/desert/middleprickpiece.png", "start": 4303067, "end": 4312818}, {"filename": "/data/images/groundpieces/ground/desert/peakdune.png", "start": 4312818, "end": 4317152}, {"filename": "/data/images/groundpieces/ground/desert/pillar1.png", "start": 4317152, "end": 4320717}, {"filename": "/data/images/groundpieces/ground/desert/pillar2.png", "start": 4320717, "end": 4324135}, {"filename": "/data/images/groundpieces/ground/desert/pillar3.png", "start": 4324135, "end": 4327404}, {"filename": "/data/images/groundpieces/ground/desert/platform.png", "start": 4327404, "end": 4331042}, {"filename": "/data/images/groundpieces/ground/desert/platform_left.png", "start": 4331042, "end": 4333701}, {"filename": "/data/images/groundpieces/ground/desert/platform_right.png", "start": 4333701, "end": 4335771}, {"filename": "/data/images/groundpieces/ground/desert/rightsmallbrick.png", "start": 4335771, "end": 4338103}, {"filename": "/data/images/groundpieces/ground/desert/rightsmallsand.png", "start": 4338103, "end": 4339812}, {"filename": "/data/images/groundpieces/ground/desert/sluggydu.png", "start": 4339812, "end": 4344118}, {"filename": "/data/images/groundpieces/ground/desert/smallbrickpiece.png", "start": 4344118, "end": 4347802}, {"filename": "/data/images/groundpieces/ground/desert/smallsand.png", "start": 4347802, "end": 4350470}, {"filename": "/data/images/groundpieces/ground/easter/egg1.png", "start": 4350470, "end": 4355958}, {"filename": "/data/images/groundpieces/ground/easter/egg2.png", "start": 4355958, "end": 4360926}, {"filename": "/data/images/groundpieces/ground/easter/egg3.png", "start": 4360926, "end": 4365762}, {"filename": "/data/images/groundpieces/ground/easter/egg4.png", "start": 4365762, "end": 4370200}, {"filename": "/data/images/groundpieces/ground/easter/ground1.png", "start": 4370200, "end": 4384905}, {"filename": "/data/images/groundpieces/ground/easter/ground2.png", "start": 4384905, "end": 4395668}, {"filename": "/data/images/groundpieces/ground/easter/ground3.png", "start": 4395668, "end": 4406177}, {"filename": "/data/images/groundpieces/ground/easter/hiddenexit.png", "start": 4406177, "end": 4410109}, {"filename": "/data/images/groundpieces/ground/easter/tree1.png", "start": 4410109, "end": 4431934}, {"filename": "/data/images/groundpieces/ground/foliage/flax1.png", "start": 4431934, "end": 4436665}, {"filename": "/data/images/groundpieces/ground/foliage/flax2.png", "start": 4436665, "end": 4440743}, {"filename": "/data/images/groundpieces/ground/foliage/midtree1.png", "start": 4440743, "end": 4446716}, {"filename": "/data/images/groundpieces/ground/foliage/midtree2.png", "start": 4446716, "end": 4458340}, {"filename": "/data/images/groundpieces/ground/foliage/oak1.png", "start": 4458340, "end": 4474681}, {"filename": "/data/images/groundpieces/ground/foliage/rock1.png", "start": 4474681, "end": 4487728}, {"filename": "/data/images/groundpieces/ground/foliage/rock2.png", "start": 4487728, "end": 4506236}, {"filename": "/data/images/groundpieces/ground/foliage/rock3.png", "start": 4506236, "end": 4523767}, {"filename": "/data/images/groundpieces/ground/foliage/rock4.png", "start": 4523767, "end": 4542802}, {"filename": "/data/images/groundpieces/ground/foliage/rock5.png", "start": 4542802, "end": 4548591}, {"filename": "/data/images/groundpieces/ground/foliage/rock6.png", "start": 4548591, "end": 4567212}, {"filename": "/data/images/groundpieces/ground/foliage/smallbush.png", "start": 4567212, "end": 4568679}, {"filename": "/data/images/groundpieces/ground/foliage/smallbush2.png", "start": 4568679, "end": 4572978}, {"filename": "/data/images/groundpieces/ground/foliage/smallbush3.png", "start": 4572978, "end": 4575925}, {"filename": "/data/images/groundpieces/ground/foliage/talltree.png", "start": 4575925, "end": 4582410}, {"filename": "/data/images/groundpieces/ground/forest/green1.png", "start": 4582410, "end": 4589286}, {"filename": "/data/images/groundpieces/ground/forest/green2.png", "start": 4589286, "end": 4600012}, {"filename": "/data/images/groundpieces/ground/forest/ground1.png", "start": 4600012, "end": 4608975}, {"filename": "/data/images/groundpieces/ground/forest/ground2.png", "start": 4608975, "end": 4617818}, {"filename": "/data/images/groundpieces/ground/forest/ground3.png", "start": 4617818, "end": 4651097}, {"filename": "/data/images/groundpieces/ground/forest/treebranch1.png", "start": 4651097, "end": 4653361}, {"filename": "/data/images/groundpieces/ground/forest/treebranch2.png", "start": 4653361, "end": 4655768}, {"filename": "/data/images/groundpieces/ground/forest/treetrunk1.png", "start": 4655768, "end": 4670729}, {"filename": "/data/images/groundpieces/ground/forest/treetrunk2.png", "start": 4670729, "end": 4703076}, {"filename": "/data/images/groundpieces/ground/forest/treetrunk3.png", "start": 4703076, "end": 4706241}, {"filename": "/data/images/groundpieces/ground/green/piece1.png", "start": 4706241, "end": 4712609}, {"filename": "/data/images/groundpieces/ground/green/piece2.png", "start": 4712609, "end": 4720044}, {"filename": "/data/images/groundpieces/ground/green/piece3.png", "start": 4720044, "end": 4736332}, {"filename": "/data/images/groundpieces/ground/halloween/ground1.png", "start": 4736332, "end": 4767109}, {"filename": "/data/images/groundpieces/ground/halloween/ground2.png", "start": 4767109, "end": 4772949}, {"filename": "/data/images/groundpieces/ground/halloween/ground3.png", "start": 4772949, "end": 4778112}, {"filename": "/data/images/groundpieces/ground/halloween/ground4.png", "start": 4778112, "end": 4782930}, {"filename": "/data/images/groundpieces/ground/halloween/ground5.png", "start": 4782930, "end": 4792147}, {"filename": "/data/images/groundpieces/ground/halloween/ground6.png", "start": 4792147, "end": 4802475}, {"filename": "/data/images/groundpieces/ground/halloween/stairs.png", "start": 4802475, "end": 4804276}, {"filename": "/data/images/groundpieces/ground/halloween/stairs_top.png", "start": 4804276, "end": 4805279}, {"filename": "/data/images/groundpieces/ground/halloween/tree1.png", "start": 4805279, "end": 4812146}, {"filename": "/data/images/groundpieces/ground/halloween/tree2.png", "start": 4812146, "end": 4815966}, {"filename": "/data/images/groundpieces/ground/halloween/tree3.png", "start": 4815966, "end": 4819562}, {"filename": "/data/images/groundpieces/ground/industrial/pipe1.png", "start": 4819562, "end": 4819808}, {"filename": "/data/images/groundpieces/ground/industrial/pipe2.png", "start": 4819808, "end": 4820032}, {"filename": "/data/images/groundpieces/ground/industrial/pipe3.png", "start": 4820032, "end": 4823249}, {"filename": "/data/images/groundpieces/ground/industrial/pipe4.png", "start": 4823249, "end": 4823586}, {"filename": "/data/images/groundpieces/ground/industrial/pipe5.png", "start": 4823586, "end": 4823872}, {"filename": "/data/images/groundpieces/ground/industrial/pipe6.png", "start": 4823872, "end": 4825333}, {"filename": "/data/images/groundpieces/ground/industrial/pipe7.png", "start": 4825333, "end": 4825820}, {"filename": "/data/images/groundpieces/ground/industrial/pipe8.png", "start": 4825820, "end": 4826286}, {"filename": "/data/images/groundpieces/ground/industrial/pipe_bl.png", "start": 4826286, "end": 4827724}, {"filename": "/data/images/groundpieces/ground/industrial/pipe_br.png", "start": 4827724, "end": 4829216}, {"filename": "/data/images/groundpieces/ground/industrial/pipe_ul.png", "start": 4829216, "end": 4830660}, {"filename": "/data/images/groundpieces/ground/industrial/pipe_ur.png", "start": 4830660, "end": 4832109}, {"filename": "/data/images/groundpieces/ground/jungle/branch1.png", "start": 4832109, "end": 4840886}, {"filename": "/data/images/groundpieces/ground/jungle/branch2.png", "start": 4840886, "end": 4850110}, {"filename": "/data/images/groundpieces/ground/jungle/branch3.png", "start": 4850110, "end": 4859270}, {"filename": "/data/images/groundpieces/ground/jungle/branch4.png", "start": 4859270, "end": 4868497}, {"filename": "/data/images/groundpieces/ground/jungle/branch5.png", "start": 4868497, "end": 4877626}, {"filename": "/data/images/groundpieces/ground/jungle/branch6.png", "start": 4877626, "end": 4886263}, {"filename": "/data/images/groundpieces/ground/jungle/carabatree.png", "start": 4886263, "end": 4915271}, {"filename": "/data/images/groundpieces/ground/jungle/carabatreemedium.png", "start": 4915271, "end": 4932796}, {"filename": "/data/images/groundpieces/ground/jungle/carabatreesmall.png", "start": 4932796, "end": 4940972}, {"filename": "/data/images/groundpieces/ground/jungle/stick1.png", "start": 4940972, "end": 4949696}, {"filename": "/data/images/groundpieces/ground/jungle/stick2.png", "start": 4949696, "end": 4956202}, {"filename": "/data/images/groundpieces/ground/jungle/stick3.png", "start": 4956202, "end": 4962189}, {"filename": "/data/images/groundpieces/ground/jungle/stick4.png", "start": 4962189, "end": 4967162}, {"filename": "/data/images/groundpieces/ground/jungle/stick5.png", "start": 4967162, "end": 4971294}, {"filename": "/data/images/groundpieces/ground/jungle/stone1.png", "start": 4971294, "end": 4976125}, {"filename": "/data/images/groundpieces/ground/jungle/stone2.png", "start": 4976125, "end": 4980915}, {"filename": "/data/images/groundpieces/ground/jungle/stone3.png", "start": 4980915, "end": 4985746}, {"filename": "/data/images/groundpieces/ground/jungle/stone4.png", "start": 4985746, "end": 4990558}, {"filename": "/data/images/groundpieces/ground/jungle/stone5.png", "start": 4990558, "end": 4995357}, {"filename": "/data/images/groundpieces/ground/jungle/twist.png", "start": 4995357, "end": 5014257}, {"filename": "/data/images/groundpieces/ground/jungle/twistsmooth.png", "start": 5014257, "end": 5034056}, {"filename": "/data/images/groundpieces/ground/misc/bpiece1.png", "start": 5034056, "end": 5053450}, {"filename": "/data/images/groundpieces/ground/misc/bpiece2.png", "start": 5053450, "end": 5076669}, {"filename": "/data/images/groundpieces/ground/misc/bpiece3.png", "start": 5076669, "end": 5096030}, {"filename": "/data/images/groundpieces/ground/misc/bpiece4.png", "start": 5096030, "end": 5113258}, {"filename": "/data/images/groundpieces/ground/misc/bpiece5.png", "start": 5113258, "end": 5128809}, {"filename": "/data/images/groundpieces/ground/misc/bpiece6.png", "start": 5128809, "end": 5147458}, {"filename": "/data/images/groundpieces/ground/misc/bpiece7.png", "start": 5147458, "end": 5160615}, {"filename": "/data/images/groundpieces/ground/misc/bpiece8.png", "start": 5160615, "end": 5172527}, {"filename": "/data/images/groundpieces/ground/misc/bpiece9.png", "start": 5172527, "end": 5179592}, {"filename": "/data/images/groundpieces/ground/misc/brick1.png", "start": 5179592, "end": 5180132}, {"filename": "/data/images/groundpieces/ground/misc/brick2.png", "start": 5180132, "end": 5180792}, {"filename": "/data/images/groundpieces/ground/misc/brick3.png", "start": 5180792, "end": 5181200}, {"filename": "/data/images/groundpieces/ground/misc/brick4.png", "start": 5181200, "end": 5181957}, {"filename": "/data/images/groundpieces/ground/misc/brick5.png", "start": 5181957, "end": 5183177}, {"filename": "/data/images/groundpieces/ground/misc/bridge1.png", "start": 5183177, "end": 5187127}, {"filename": "/data/images/groundpieces/ground/misc/bridge2.png", "start": 5187127, "end": 5187851}, {"filename": "/data/images/groundpieces/ground/misc/column.png", "start": 5187851, "end": 5204494}, {"filename": "/data/images/groundpieces/ground/misc/column_down.png", "start": 5204494, "end": 5214158}, {"filename": "/data/images/groundpieces/ground/misc/column_flat.png", "start": 5214158, "end": 5229095}, {"filename": "/data/images/groundpieces/ground/misc/column_flat_left.png", "start": 5229095, "end": 5238307}, {"filename": "/data/images/groundpieces/ground/misc/column_flat_right.png", "start": 5238307, "end": 5251832}, {"filename": "/data/images/groundpieces/ground/misc/column_horz.png", "start": 5251832, "end": 5270838}, {"filename": "/data/images/groundpieces/ground/misc/column_up.png", "start": 5270838, "end": 5280981}, {"filename": "/data/images/groundpieces/ground/misc/column_vert.png", "start": 5280981, "end": 5299525}, {"filename": "/data/images/groundpieces/ground/misc/dragon.png", "start": 5299525, "end": 5313942}, {"filename": "/data/images/groundpieces/ground/misc/green1.png", "start": 5313942, "end": 5321670}, {"filename": "/data/images/groundpieces/ground/misc/green2.png", "start": 5321670, "end": 5327760}, {"filename": "/data/images/groundpieces/ground/misc/grey_stone1.png", "start": 5327760, "end": 5339524}, {"filename": "/data/images/groundpieces/ground/misc/grey_stone2.png", "start": 5339524, "end": 5351776}, {"filename": "/data/images/groundpieces/ground/misc/grey_stone3.png", "start": 5351776, "end": 5364278}, {"filename": "/data/images/groundpieces/ground/misc/grey_stone4.png", "start": 5364278, "end": 5373374}, {"filename": "/data/images/groundpieces/ground/misc/grey_stone5.png", "start": 5373374, "end": 5384427}, {"filename": "/data/images/groundpieces/ground/misc/grey_stone6.png", "start": 5384427, "end": 5396416}, {"filename": "/data/images/groundpieces/ground/misc/pfosten.png", "start": 5396416, "end": 5414493}, {"filename": "/data/images/groundpieces/ground/misc/piece1.png", "start": 5414493, "end": 5437200}, {"filename": "/data/images/groundpieces/ground/misc/piece2.png", "start": 5437200, "end": 5453084}, {"filename": "/data/images/groundpieces/ground/misc/piece3.png", "start": 5453084, "end": 5474711}, {"filename": "/data/images/groundpieces/ground/misc/piece4.png", "start": 5474711, "end": 5495568}, {"filename": "/data/images/groundpieces/ground/misc/piece5.png", "start": 5495568, "end": 5512330}, {"filename": "/data/images/groundpieces/ground/misc/piece6.png", "start": 5512330, "end": 5520151}, {"filename": "/data/images/groundpieces/ground/misc/spike.png", "start": 5520151, "end": 5524906}, {"filename": "/data/images/groundpieces/ground/misc/stone0.png", "start": 5524906, "end": 5530677}, {"filename": "/data/images/groundpieces/ground/misc/stone1.png", "start": 5530677, "end": 5531568}, {"filename": "/data/images/groundpieces/ground/misc/stone2.png", "start": 5531568, "end": 5534527}, {"filename": "/data/images/groundpieces/ground/misc/stone3.png", "start": 5534527, "end": 5538328}, {"filename": "/data/images/groundpieces/ground/misc/stone4.png", "start": 5538328, "end": 5547059}, {"filename": "/data/images/groundpieces/ground/misc/stone5.png", "start": 5547059, "end": 5554049}, {"filename": "/data/images/groundpieces/ground/misc/stone6.png", "start": 5554049, "end": 5560760}, {"filename": "/data/images/groundpieces/ground/misc/stone7.png", "start": 5560760, "end": 5566449}, {"filename": "/data/images/groundpieces/ground/misc/stoneblock1.png", "start": 5566449, "end": 5570454}, {"filename": "/data/images/groundpieces/ground/misc/stoneblock2.png", "start": 5570454, "end": 5574420}, {"filename": "/data/images/groundpieces/ground/misc/stoneblock3.png", "start": 5574420, "end": 5578835}, {"filename": "/data/images/groundpieces/ground/misc/stoneblock5.png", "start": 5578835, "end": 5581099}, {"filename": "/data/images/groundpieces/ground/misc/stoneblock6.png", "start": 5581099, "end": 5583340}, {"filename": "/data/images/groundpieces/ground/misc/tree.png", "start": 5583340, "end": 5597718}, {"filename": "/data/images/groundpieces/ground/misc/well.png", "start": 5597718, "end": 5599813}, {"filename": "/data/images/groundpieces/ground/misc/wood1.png", "start": 5599813, "end": 5601485}, {"filename": "/data/images/groundpieces/ground/misc/wood2.png", "start": 5601485, "end": 5602962}, {"filename": "/data/images/groundpieces/ground/mud/mudpiece1.png", "start": 5602962, "end": 5609572}, {"filename": "/data/images/groundpieces/ground/mud/mudpiece2.png", "start": 5609572, "end": 5619741}, {"filename": "/data/images/groundpieces/ground/mud/mudpiece3.png", "start": 5619741, "end": 5623147}, {"filename": "/data/images/groundpieces/ground/mushroom/toadstool1.png", "start": 5623147, "end": 5635130}, {"filename": "/data/images/groundpieces/ground/mushroom/toadstool2.png", "start": 5635130, "end": 5637615}, {"filename": "/data/images/groundpieces/ground/mushroom/toadstool3.png", "start": 5637615, "end": 5649579}, {"filename": "/data/images/groundpieces/ground/mushroom/toadstool4.png", "start": 5649579, "end": 5663777}, {"filename": "/data/images/groundpieces/ground/ordina/cable1.png", "start": 5663777, "end": 5665181}, {"filename": "/data/images/groundpieces/ground/ordina/cable2.png", "start": 5665181, "end": 5666315}, {"filename": "/data/images/groundpieces/ground/ordina/cdrom1.png", "start": 5666315, "end": 5673044}, {"filename": "/data/images/groundpieces/ground/ordina/clavier1.png", "start": 5673044, "end": 5684994}, {"filename": "/data/images/groundpieces/ground/ordina/cpu1.png", "start": 5684994, "end": 5687098}, {"filename": "/data/images/groundpieces/ground/ordina/ecran.png", "start": 5687098, "end": 5699810}, {"filename": "/data/images/groundpieces/ground/ordina/sol2.png", "start": 5699810, "end": 5716831}, {"filename": "/data/images/groundpieces/ground/ordina/sol3.png", "start": 5716831, "end": 5742513}, {"filename": "/data/images/groundpieces/ground/ordina/sol4.png", "start": 5742513, "end": 5759527}, {"filename": "/data/images/groundpieces/ground/penguinworld/penguin.png", "start": 5759527, "end": 5782519}, {"filename": "/data/images/groundpieces/ground/penguinworld/penguinworld.png", "start": 5782519, "end": 5800204}, {"filename": "/data/images/groundpieces/ground/real/fish.png", "start": 5800204, "end": 5805244}, {"filename": "/data/images/groundpieces/ground/real/green1.png", "start": 5805244, "end": 5817966}, {"filename": "/data/images/groundpieces/ground/real/green2.png", "start": 5817966, "end": 5844482}, {"filename": "/data/images/groundpieces/ground/real/real1.png", "start": 5844482, "end": 5867175}, {"filename": "/data/images/groundpieces/ground/real/real10.png", "start": 5867175, "end": 5874999}, {"filename": "/data/images/groundpieces/ground/real/real11.png", "start": 5874999, "end": 5886680}, {"filename": "/data/images/groundpieces/ground/real/real12.png", "start": 5886680, "end": 5895184}, {"filename": "/data/images/groundpieces/ground/real/real13.png", "start": 5895184, "end": 5902972}, {"filename": "/data/images/groundpieces/ground/real/real14.png", "start": 5902972, "end": 5910151}, {"filename": "/data/images/groundpieces/ground/real/real15.png", "start": 5910151, "end": 5923358}, {"filename": "/data/images/groundpieces/ground/real/real16.png", "start": 5923358, "end": 5935621}, {"filename": "/data/images/groundpieces/ground/real/real17.png", "start": 5935621, "end": 5946676}, {"filename": "/data/images/groundpieces/ground/real/real18.png", "start": 5946676, "end": 5959203}, {"filename": "/data/images/groundpieces/ground/real/real19.png", "start": 5959203, "end": 5969064}, {"filename": "/data/images/groundpieces/ground/real/real2.png", "start": 5969064, "end": 6007553}, {"filename": "/data/images/groundpieces/ground/real/real20.png", "start": 6007553, "end": 6020342}, {"filename": "/data/images/groundpieces/ground/real/real21.png", "start": 6020342, "end": 6034699}, {"filename": "/data/images/groundpieces/ground/real/real22.png", "start": 6034699, "end": 6052322}, {"filename": "/data/images/groundpieces/ground/real/real23.png", "start": 6052322, "end": 6065539}, {"filename": "/data/images/groundpieces/ground/real/real24.png", "start": 6065539, "end": 6076315}, {"filename": "/data/images/groundpieces/ground/real/real25.png", "start": 6076315, "end": 6091168}, {"filename": "/data/images/groundpieces/ground/real/real26.png", "start": 6091168, "end": 6103359}, {"filename": "/data/images/groundpieces/ground/real/real27.png", "start": 6103359, "end": 6119324}, {"filename": "/data/images/groundpieces/ground/real/real28.png", "start": 6119324, "end": 6136144}, {"filename": "/data/images/groundpieces/ground/real/real29.png", "start": 6136144, "end": 6147639}, {"filename": "/data/images/groundpieces/ground/real/real3.png", "start": 6147639, "end": 6177376}, {"filename": "/data/images/groundpieces/ground/real/real30.png", "start": 6177376, "end": 6191388}, {"filename": "/data/images/groundpieces/ground/real/real34.png", "start": 6191388, "end": 6206263}, {"filename": "/data/images/groundpieces/ground/real/real35.png", "start": 6206263, "end": 6213696}, {"filename": "/data/images/groundpieces/ground/real/real36.png", "start": 6213696, "end": 6223125}, {"filename": "/data/images/groundpieces/ground/real/real37.png", "start": 6223125, "end": 6232994}, {"filename": "/data/images/groundpieces/ground/real/real4.png", "start": 6232994, "end": 6247418}, {"filename": "/data/images/groundpieces/ground/real/real5.png", "start": 6247418, "end": 6255973}, {"filename": "/data/images/groundpieces/ground/real/real6.png", "start": 6255973, "end": 6272789}, {"filename": "/data/images/groundpieces/ground/real/real7.png", "start": 6272789, "end": 6296351}, {"filename": "/data/images/groundpieces/ground/real/real8.png", "start": 6296351, "end": 6319442}, {"filename": "/data/images/groundpieces/ground/real/real9.png", "start": 6319442, "end": 6324887}, {"filename": "/data/images/groundpieces/ground/rock/blackrock1.png", "start": 6324887, "end": 6342460}, {"filename": "/data/images/groundpieces/ground/rock/blackrock2.png", "start": 6342460, "end": 6359796}, {"filename": "/data/images/groundpieces/ground/rock/blackrock3.png", "start": 6359796, "end": 6380129}, {"filename": "/data/images/groundpieces/ground/rock/blackrock4.png", "start": 6380129, "end": 6395084}, {"filename": "/data/images/groundpieces/ground/rock/stone1.png", "start": 6395084, "end": 6398746}, {"filename": "/data/images/groundpieces/ground/signposts/arrow_down.png", "start": 6398746, "end": 6399417}, {"filename": "/data/images/groundpieces/ground/signposts/arrow_left.png", "start": 6399417, "end": 6400061}, {"filename": "/data/images/groundpieces/ground/signposts/arrow_right.png", "start": 6400061, "end": 6400699}, {"filename": "/data/images/groundpieces/ground/signposts/arrow_up.png", "start": 6400699, "end": 6401379}, {"filename": "/data/images/groundpieces/ground/signposts/danger.png", "start": 6401379, "end": 6402938}, {"filename": "/data/images/groundpieces/ground/snow/block1.png", "start": 6402938, "end": 6407726}, {"filename": "/data/images/groundpieces/ground/snow/block2.png", "start": 6407726, "end": 6412561}, {"filename": "/data/images/groundpieces/ground/snow/block3.png", "start": 6412561, "end": 6415399}, {"filename": "/data/images/groundpieces/ground/snow/block4.png", "start": 6415399, "end": 6418283}, {"filename": "/data/images/groundpieces/ground/snow/cabin.png", "start": 6418283, "end": 6422944}, {"filename": "/data/images/groundpieces/ground/snow/cabin_winter.png", "start": 6422944, "end": 6427670}, {"filename": "/data/images/groundpieces/ground/snow/diablock1.png", "start": 6427670, "end": 6432404}, {"filename": "/data/images/groundpieces/ground/snow/diablock2.png", "start": 6432404, "end": 6435261}, {"filename": "/data/images/groundpieces/ground/snow/diablock3.png", "start": 6435261, "end": 6438208}, {"filename": "/data/images/groundpieces/ground/snow/gpiece1.png", "start": 6438208, "end": 6453536}, {"filename": "/data/images/groundpieces/ground/snow/groundice.png", "start": 6453536, "end": 6456248}, {"filename": "/data/images/groundpieces/ground/snow/ice1.png", "start": 6456248, "end": 6457192}, {"filename": "/data/images/groundpieces/ground/snow/ice2.png", "start": 6457192, "end": 6458378}, {"filename": "/data/images/groundpieces/ground/snow/ice3.png", "start": 6458378, "end": 6464113}, {"filename": "/data/images/groundpieces/ground/snow/iceblock1.png", "start": 6464113, "end": 6472389}, {"filename": "/data/images/groundpieces/ground/snow/icepiece1.png", "start": 6472389, "end": 6475604}, {"filename": "/data/images/groundpieces/ground/snow/igloo.png", "start": 6475604, "end": 6479450}, {"filename": "/data/images/groundpieces/ground/snow/piece1.png", "start": 6479450, "end": 6480624}, {"filename": "/data/images/groundpieces/ground/snow/piece10.png", "start": 6480624, "end": 6492226}, {"filename": "/data/images/groundpieces/ground/snow/piece2.png", "start": 6492226, "end": 6492730}, {"filename": "/data/images/groundpieces/ground/snow/piece3.png", "start": 6492730, "end": 6493700}, {"filename": "/data/images/groundpieces/ground/snow/piece7.png", "start": 6493700, "end": 6509725}, {"filename": "/data/images/groundpieces/ground/snow/piece8.png", "start": 6509725, "end": 6537549}, {"filename": "/data/images/groundpieces/ground/snow/piece9.png", "start": 6537549, "end": 6555318}, {"filename": "/data/images/groundpieces/ground/snow/pillar1.png", "start": 6555318, "end": 6558494}, {"filename": "/data/images/groundpieces/ground/snow/pillar2.png", "start": 6558494, "end": 6562927}, {"filename": "/data/images/groundpieces/ground/snow/slopedr.png", "start": 6562927, "end": 6565369}, {"filename": "/data/images/groundpieces/ground/snow/snowball1.png", "start": 6565369, "end": 6572225}, {"filename": "/data/images/groundpieces/ground/snow/snowman.png", "start": 6572225, "end": 6573440}, {"filename": "/data/images/groundpieces/ground/snow/way.png", "start": 6573440, "end": 6575123}, {"filename": "/data/images/groundpieces/ground/snow/xmas-tree.png", "start": 6575123, "end": 6579265}, {"filename": "/data/images/groundpieces/ground/sortie/ball1.png", "start": 6579265, "end": 6581685}, {"filename": "/data/images/groundpieces/ground/sortie/ball2.png", "start": 6581685, "end": 6583546}, {"filename": "/data/images/groundpieces/ground/sortie/ball3.png", "start": 6583546, "end": 6584430}, {"filename": "/data/images/groundpieces/ground/sortie/ball4.png", "start": 6584430, "end": 6585511}, {"filename": "/data/images/groundpieces/ground/sortie/column.png", "start": 6585511, "end": 6610077}, {"filename": "/data/images/groundpieces/ground/sortie/column2.png", "start": 6610077, "end": 6631267}, {"filename": "/data/images/groundpieces/ground/sortie/column3.png", "start": 6631267, "end": 6648704}, {"filename": "/data/images/groundpieces/ground/sortie/plate_forme.png", "start": 6648704, "end": 6662380}, {"filename": "/data/images/groundpieces/ground/sortie/plate_forme_left.png", "start": 6662380, "end": 6675131}, {"filename": "/data/images/groundpieces/ground/sortie/plate_forme_right.png", "start": 6675131, "end": 6682281}, {"filename": "/data/images/groundpieces/ground/sortie/tentacle1.png", "start": 6682281, "end": 6684549}, {"filename": "/data/images/groundpieces/ground/space/block1.png", "start": 6684549, "end": 6694098}, {"filename": "/data/images/groundpieces/ground/space/diagonal.png", "start": 6694098, "end": 6697917}, {"filename": "/data/images/groundpieces/ground/space/diagonalr.png", "start": 6697917, "end": 6701735}, {"filename": "/data/images/groundpieces/ground/space/smallblock1.png", "start": 6701735, "end": 6703229}, {"filename": "/data/images/groundpieces/ground/space/smallblock2.png", "start": 6703229, "end": 6705011}, {"filename": "/data/images/groundpieces/ground/space/smallblock3.png", "start": 6705011, "end": 6706817}, {"filename": "/data/images/groundpieces/ground/space/smalltower.png", "start": 6706817, "end": 6708834}, {"filename": "/data/images/groundpieces/ground/space/tower1.png", "start": 6708834, "end": 6716349}, {"filename": "/data/images/groundpieces/ground/space/way.png", "start": 6716349, "end": 6717546}, {"filename": "/data/images/groundpieces/ground/sweets/allsort1.png", "start": 6717546, "end": 6719312}, {"filename": "/data/images/groundpieces/ground/sweets/allsort2.png", "start": 6719312, "end": 6722083}, {"filename": "/data/images/groundpieces/ground/sweets/aquachoc.png", "start": 6722083, "end": 6730291}, {"filename": "/data/images/groundpieces/ground/sweets/cake1.png", "start": 6730291, "end": 6739147}, {"filename": "/data/images/groundpieces/ground/sweets/cake2.png", "start": 6739147, "end": 6751032}, {"filename": "/data/images/groundpieces/ground/sweets/cake3.png", "start": 6751032, "end": 6758442}, {"filename": "/data/images/groundpieces/ground/sweets/cake4.png", "start": 6758442, "end": 6765543}, {"filename": "/data/images/groundpieces/ground/sweets/cake5.png", "start": 6765543, "end": 6783594}, {"filename": "/data/images/groundpieces/ground/sweets/canestalk.png", "start": 6783594, "end": 6784379}, {"filename": "/data/images/groundpieces/ground/sweets/canestub.png", "start": 6784379, "end": 6784629}, {"filename": "/data/images/groundpieces/ground/sweets/canetop.png", "start": 6784629, "end": 6787470}, {"filename": "/data/images/groundpieces/ground/sweets/chocbar.png", "start": 6787470, "end": 6802622}, {"filename": "/data/images/groundpieces/ground/sweets/chocbloc-lowleft.png", "start": 6802622, "end": 6805854}, {"filename": "/data/images/groundpieces/ground/sweets/chocbloc-lowright.png", "start": 6805854, "end": 6809203}, {"filename": "/data/images/groundpieces/ground/sweets/chocbloc-topleft.png", "start": 6809203, "end": 6811896}, {"filename": "/data/images/groundpieces/ground/sweets/chocbloc-topright.png", "start": 6811896, "end": 6814510}, {"filename": "/data/images/groundpieces/ground/sweets/chocbloc.png", "start": 6814510, "end": 6817842}, {"filename": "/data/images/groundpieces/ground/sweets/goldchoc.png", "start": 6817842, "end": 6825979}, {"filename": "/data/images/groundpieces/ground/sweets/greenjellybaby.png", "start": 6825979, "end": 6828538}, {"filename": "/data/images/groundpieces/ground/sweets/icecream.png", "start": 6828538, "end": 6837192}, {"filename": "/data/images/groundpieces/ground/sweets/jube1.png", "start": 6837192, "end": 6839695}, {"filename": "/data/images/groundpieces/ground/sweets/jube2.png", "start": 6839695, "end": 6841636}, {"filename": "/data/images/groundpieces/ground/sweets/lollipop-purp.png", "start": 6841636, "end": 6845032}, {"filename": "/data/images/groundpieces/ground/sweets/lollipop.png", "start": 6845032, "end": 6847970}, {"filename": "/data/images/groundpieces/ground/sweets/mmblue.png", "start": 6847970, "end": 6849214}, {"filename": "/data/images/groundpieces/ground/sweets/mmbrown.png", "start": 6849214, "end": 6850844}, {"filename": "/data/images/groundpieces/ground/sweets/mmred.png", "start": 6850844, "end": 6852370}, {"filename": "/data/images/groundpieces/ground/sweets/mmyellow.png", "start": 6852370, "end": 6854238}, {"filename": "/data/images/groundpieces/ground/sweets/purpchoc.png", "start": 6854238, "end": 6861922}, {"filename": "/data/images/groundpieces/ground/sweets/purplechoc.png", "start": 6861922, "end": 6867516}, {"filename": "/data/images/groundpieces/ground/sweets/redjellybaby.png", "start": 6867516, "end": 6869644}, {"filename": "/data/images/groundpieces/ground/test/block1.png", "start": 6869644, "end": 6869846}, {"filename": "/data/images/groundpieces/ground/test/bpp24.png", "start": 6869846, "end": 6870996}, {"filename": "/data/images/groundpieces/ground/test/bpp32.png", "start": 6870996, "end": 6881337}, {"filename": "/data/images/groundpieces/ground/test/bpp8-colorkey.png", "start": 6881337, "end": 6882836}, {"filename": "/data/images/groundpieces/ground/test/bpp8.png", "start": 6882836, "end": 6884246}, {"filename": "/data/images/groundpieces/ground/test/test1.png", "start": 6884246, "end": 6884392}, {"filename": "/data/images/groundpieces/ground/test/test10.png", "start": 6884392, "end": 6884554}, {"filename": "/data/images/groundpieces/ground/test/test2.png", "start": 6884554, "end": 6884709}, {"filename": "/data/images/groundpieces/ground/test/test3.png", "start": 6884709, "end": 6884844}, {"filename": "/data/images/groundpieces/ground/test/test4.png", "start": 6884844, "end": 6884991}, {"filename": "/data/images/groundpieces/ground/test/test5.png", "start": 6884991, "end": 6885187}, {"filename": "/data/images/groundpieces/ground/test/test6.png", "start": 6885187, "end": 6885309}, {"filename": "/data/images/groundpieces/ground/test/test7.png", "start": 6885309, "end": 6885457}, {"filename": "/data/images/groundpieces/ground/test/test8.png", "start": 6885457, "end": 6885631}, {"filename": "/data/images/groundpieces/ground/test/test9.png", "start": 6885631, "end": 6885821}, {"filename": "/data/images/groundpieces/ground/xmas/ground1.png", "start": 6885821, "end": 6892897}, {"filename": "/data/images/groundpieces/ground/xmas/ground2.png", "start": 6892897, "end": 6904427}, {"filename": "/data/images/groundpieces/ground/xmas/ground3.png", "start": 6904427, "end": 6913115}, {"filename": "/data/images/groundpieces/ground/xmas/iceblock.png", "start": 6913115, "end": 6919838}, {"filename": "/data/images/groundpieces/ground/xmas/pingu.png", "start": 6919838, "end": 6927817}, {"filename": "/data/images/groundpieces/ground/xmas/snow1.png", "start": 6927817, "end": 6929367}, {"filename": "/data/images/groundpieces/ground/xmas/snow2.png", "start": 6929367, "end": 6931438}, {"filename": "/data/images/groundpieces/ground/xmas/snowball.png", "start": 6931438, "end": 6931859}, {"filename": "/data/images/groundpieces/ground/xmas/snowball1.png", "start": 6931859, "end": 6933077}, {"filename": "/data/images/groundpieces/ground/xmas/snowball2.png", "start": 6933077, "end": 6934333}, {"filename": "/data/images/groundpieces/ground/xmas/snowball3.png", "start": 6934333, "end": 6936408}, {"filename": "/data/images/groundpieces/ground/xmas/snowman_coal1.png", "start": 6936408, "end": 6936637}, {"filename": "/data/images/groundpieces/ground/xmas/snowman_coal2.png", "start": 6936637, "end": 6936869}, {"filename": "/data/images/groundpieces/ground/xmas/snowman_nose.png", "start": 6936869, "end": 6937343}, {"filename": "/data/images/groundpieces/ground/xmas/tree.png", "start": 6937343, "end": 6948631}, {"filename": "/data/images/groundpieces/remove/misc/column1.png", "start": 6948631, "end": 6948808}, {"filename": "/data/images/groundpieces/remove/misc/dia1.png", "start": 6948808, "end": 6949006}, {"filename": "/data/images/groundpieces/remove/misc/rect1.png", "start": 6949006, "end": 6950834}, {"filename": "/data/images/groundpieces/remove/misc/rect2.png", "start": 6950834, "end": 6950974}, {"filename": "/data/images/groundpieces/solid/crystal/rectsolid.png", "start": 6950974, "end": 6953152}, {"filename": "/data/images/groundpieces/solid/crystal/smallsolid.png", "start": 6953152, "end": 6954483}, {"filename": "/data/images/groundpieces/solid/crystal/squaresolid.png", "start": 6954483, "end": 6958142}, {"filename": "/data/images/groundpieces/solid/desert/bigbrickpiece.png", "start": 6958142, "end": 6996767}, {"filename": "/data/images/groundpieces/solid/desert/leftsmallbrick.png", "start": 6996767, "end": 6999085}, {"filename": "/data/images/groundpieces/solid/desert/middlebrickpiece.png", "start": 6999085, "end": 7009912}, {"filename": "/data/images/groundpieces/solid/desert/smallbrickpiece.png", "start": 7009912, "end": 7013507}, {"filename": "/data/images/groundpieces/solid/industrial/greybri1.png", "start": 7013507, "end": 7018104}, {"filename": "/data/images/groundpieces/solid/industrial/greybri2.png", "start": 7018104, "end": 7022875}, {"filename": "/data/images/groundpieces/solid/industrial/greybri3.png", "start": 7022875, "end": 7027162}, {"filename": "/data/images/groundpieces/solid/industrial/greybri5.png", "start": 7027162, "end": 7031887}, {"filename": "/data/images/groundpieces/solid/industrial/joint1.png", "start": 7031887, "end": 7034385}, {"filename": "/data/images/groundpieces/solid/industrial/joint2.png", "start": 7034385, "end": 7036710}, {"filename": "/data/images/groundpieces/solid/industrial/joint3.png", "start": 7036710, "end": 7039211}, {"filename": "/data/images/groundpieces/solid/industrial/joint4.png", "start": 7039211, "end": 7041854}, {"filename": "/data/images/groundpieces/solid/industrial/joint5.png", "start": 7041854, "end": 7044270}, {"filename": "/data/images/groundpieces/solid/industrial/rivet.png", "start": 7044270, "end": 7045323}, {"filename": "/data/images/groundpieces/solid/industrial/screw.png", "start": 7045323, "end": 7046395}, {"filename": "/data/images/groundpieces/solid/industrial/steel1.png", "start": 7046395, "end": 7048958}, {"filename": "/data/images/groundpieces/solid/industrial/steel2.png", "start": 7048958, "end": 7053888}, {"filename": "/data/images/groundpieces/solid/industrial/steel3.png", "start": 7053888, "end": 7058661}, {"filename": "/data/images/groundpieces/solid/industrial/steel4.png", "start": 7058661, "end": 7065633}, {"filename": "/data/images/groundpieces/solid/industrial/steel5.png", "start": 7065633, "end": 7073177}, {"filename": "/data/images/groundpieces/solid/industrial/weld1.png", "start": 7073177, "end": 7073664}, {"filename": "/data/images/groundpieces/solid/industrial/weld2.png", "start": 7073664, "end": 7074110}, {"filename": "/data/images/groundpieces/solid/industrial/weld3.png", "start": 7074110, "end": 7074861}, {"filename": "/data/images/groundpieces/solid/industrial/weld4.png", "start": 7074861, "end": 7075238}, {"filename": "/data/images/groundpieces/solid/industrial/weld5.png", "start": 7075238, "end": 7075826}, {"filename": "/data/images/groundpieces/solid/industrial/weld6.png", "start": 7075826, "end": 7077127}, {"filename": "/data/images/groundpieces/solid/industrial/weld7.png", "start": 7077127, "end": 7077876}, {"filename": "/data/images/groundpieces/solid/misc/metalplate_horiz.png", "start": 7077876, "end": 7080538}, {"filename": "/data/images/groundpieces/solid/misc/metalplate_large.png", "start": 7080538, "end": 7084899}, {"filename": "/data/images/groundpieces/solid/misc/metalplate_small.png", "start": 7084899, "end": 7086388}, {"filename": "/data/images/groundpieces/solid/misc/metalplate_vert.png", "start": 7086388, "end": 7089074}, {"filename": "/data/images/groundpieces/solid/rock/granit1.png", "start": 7089074, "end": 7099799}, {"filename": "/data/images/groundpieces/solid/rock/granit2.png", "start": 7099799, "end": 7110813}, {"filename": "/data/images/groundpieces/solid/rock/granit3.png", "start": 7110813, "end": 7128944}, {"filename": "/data/images/groundpieces/solid/rock/granit4.png", "start": 7128944, "end": 7136608}, {"filename": "/data/images/groundpieces/solid/rock/granit5.png", "start": 7136608, "end": 7144387}, {"filename": "/data/images/groundpieces/solid/rock/granit6.png", "start": 7144387, "end": 7150197}, {"filename": "/data/images/groundpieces/transparent/easter/flower1.png", "start": 7150197, "end": 7151535}, {"filename": "/data/images/groundpieces/transparent/easter/flower2.png", "start": 7151535, "end": 7152778}, {"filename": "/data/images/groundpieces/transparent/easter/flower3.png", "start": 7152778, "end": 7154061}, {"filename": "/data/images/groundpieces/transparent/easter/grass.png", "start": 7154061, "end": 7158322}, {"filename": "/data/images/groundpieces/transparent/foliage/grass1.png", "start": 7158322, "end": 7158760}, {"filename": "/data/images/groundpieces/transparent/foliage/grass10.png", "start": 7158760, "end": 7159001}, {"filename": "/data/images/groundpieces/transparent/foliage/grass11.png", "start": 7159001, "end": 7159287}, {"filename": "/data/images/groundpieces/transparent/foliage/grass12.png", "start": 7159287, "end": 7159549}, {"filename": "/data/images/groundpieces/transparent/foliage/grass13.png", "start": 7159549, "end": 7159728}, {"filename": "/data/images/groundpieces/transparent/foliage/grass14.png", "start": 7159728, "end": 7159967}, {"filename": "/data/images/groundpieces/transparent/foliage/grass15.png", "start": 7159967, "end": 7160513}, {"filename": "/data/images/groundpieces/transparent/foliage/grass16.png", "start": 7160513, "end": 7160721}, {"filename": "/data/images/groundpieces/transparent/foliage/grass2.png", "start": 7160721, "end": 7161024}, {"filename": "/data/images/groundpieces/transparent/foliage/grass3.png", "start": 7161024, "end": 7161288}, {"filename": "/data/images/groundpieces/transparent/foliage/grass4.png", "start": 7161288, "end": 7161598}, {"filename": "/data/images/groundpieces/transparent/foliage/grass5.png", "start": 7161598, "end": 7161767}, {"filename": "/data/images/groundpieces/transparent/foliage/grass6.png", "start": 7161767, "end": 7162202}, {"filename": "/data/images/groundpieces/transparent/foliage/grass7.png", "start": 7162202, "end": 7162439}, {"filename": "/data/images/groundpieces/transparent/foliage/grass8.png", "start": 7162439, "end": 7162670}, {"filename": "/data/images/groundpieces/transparent/foliage/grass9.png", "start": 7162670, "end": 7162908}, {"filename": "/data/images/groundpieces/transparent/foliage/turfconcave.png", "start": 7162908, "end": 7163830}, {"filename": "/data/images/groundpieces/transparent/foliage/turfflat.png", "start": 7163830, "end": 7164958}, {"filename": "/data/images/groundpieces/transparent/foliage/turfslopeleft.png", "start": 7164958, "end": 7166173}, {"filename": "/data/images/groundpieces/transparent/foliage/turfslopeleft20.png", "start": 7166173, "end": 7166863}, {"filename": "/data/images/groundpieces/transparent/foliage/turfsloperight.png", "start": 7166863, "end": 7167554}, {"filename": "/data/images/groundpieces/transparent/foliage/turfsloperight20.png", "start": 7167554, "end": 7168246}, {"filename": "/data/images/groundpieces/transparent/foliage/turfsmallbump.png", "start": 7168246, "end": 7168685}, {"filename": "/data/images/groundpieces/transparent/foliage/turfsmallnook.png", "start": 7168685, "end": 7169144}, {"filename": "/data/images/groundpieces/transparent/foliage/turftufty.png", "start": 7169144, "end": 7169603}, {"filename": "/data/images/groundpieces/transparent/forest/green1.png", "start": 7169603, "end": 7171992}, {"filename": "/data/images/groundpieces/transparent/halloween/candle1.png", "start": 7171992, "end": 7172705}, {"filename": "/data/images/groundpieces/transparent/halloween/fence1.png", "start": 7172705, "end": 7175560}, {"filename": "/data/images/groundpieces/transparent/halloween/gravestone1.png", "start": 7175560, "end": 7177044}, {"filename": "/data/images/groundpieces/transparent/halloween/gravestone2.png", "start": 7177044, "end": 7178753}, {"filename": "/data/images/groundpieces/transparent/halloween/gravestone3.png", "start": 7178753, "end": 7179644}, {"filename": "/data/images/groundpieces/transparent/halloween/gravestone4.png", "start": 7179644, "end": 7180445}, {"filename": "/data/images/groundpieces/transparent/halloween/gravestone5.png", "start": 7180445, "end": 7181412}, {"filename": "/data/images/groundpieces/transparent/halloween/hat1.png", "start": 7181412, "end": 7182645}, {"filename": "/data/images/groundpieces/transparent/halloween/hat2.png", "start": 7182645, "end": 7183858}, {"filename": "/data/images/groundpieces/transparent/halloween/kirby1.png", "start": 7183858, "end": 7185334}, {"filename": "/data/images/groundpieces/transparent/halloween/kirby2.png", "start": 7185334, "end": 7186757}, {"filename": "/data/images/groundpieces/transparent/halloween/kirby3.png", "start": 7186757, "end": 7188227}, {"filename": "/data/images/groundpieces/transparent/halloween/kirby4.png", "start": 7188227, "end": 7189623}, {"filename": "/data/images/groundpieces/transparent/halloween/pot1.png", "start": 7189623, "end": 7190917}, {"filename": "/data/images/groundpieces/transparent/halloween/spiderweb1.png", "start": 7190917, "end": 7191678}, {"filename": "/data/images/groundpieces/transparent/industrial/gunge1.png", "start": 7191678, "end": 7193168}, {"filename": "/data/images/groundpieces/transparent/industrial/gunge10.png", "start": 7193168, "end": 7194830}, {"filename": "/data/images/groundpieces/transparent/industrial/gunge11.png", "start": 7194830, "end": 7196332}, {"filename": "/data/images/groundpieces/transparent/industrial/gunge12.png", "start": 7196332, "end": 7196712}, {"filename": "/data/images/groundpieces/transparent/industrial/gunge13.png", "start": 7196712, "end": 7197213}, {"filename": "/data/images/groundpieces/transparent/industrial/gunge14.png", "start": 7197213, "end": 7198183}, {"filename": "/data/images/groundpieces/transparent/industrial/gunge15.png", "start": 7198183, "end": 7199139}, {"filename": "/data/images/groundpieces/transparent/industrial/gunge2.png", "start": 7199139, "end": 7199568}, {"filename": "/data/images/groundpieces/transparent/industrial/gunge3.png", "start": 7199568, "end": 7199937}, {"filename": "/data/images/groundpieces/transparent/industrial/gunge4.png", "start": 7199937, "end": 7200437}, {"filename": "/data/images/groundpieces/transparent/industrial/gunge5.png", "start": 7200437, "end": 7200821}, {"filename": "/data/images/groundpieces/transparent/industrial/gunge6.png", "start": 7200821, "end": 7201251}, {"filename": "/data/images/groundpieces/transparent/industrial/gunge7.png", "start": 7201251, "end": 7201688}, {"filename": "/data/images/groundpieces/transparent/industrial/gunge8.png", "start": 7201688, "end": 7202679}, {"filename": "/data/images/groundpieces/transparent/industrial/gunge9.png", "start": 7202679, "end": 7203057}, {"filename": "/data/images/groundpieces/transparent/misc/black.png", "start": 7203057, "end": 7212566}, {"filename": "/data/images/groundpieces/transparent/misc/flower.png", "start": 7212566, "end": 7213605}, {"filename": "/data/images/groundpieces/transparent/misc/moos1.png", "start": 7213605, "end": 7214647}, {"filename": "/data/images/groundpieces/transparent/misc/moos2.png", "start": 7214647, "end": 7215699}, {"filename": "/data/images/groundpieces/transparent/misc/moos3.png", "start": 7215699, "end": 7216349}, {"filename": "/data/images/groundpieces/transparent/misc/moos4.png", "start": 7216349, "end": 7218100}, {"filename": "/data/images/groundpieces/transparent/misc/moos5.png", "start": 7218100, "end": 7219582}, {"filename": "/data/images/groundpieces/transparent/misc/moos6.png", "start": 7219582, "end": 7221528}, {"filename": "/data/images/groundpieces/transparent/misc/moos7.png", "start": 7221528, "end": 7223073}, {"filename": "/data/images/groundpieces/transparent/misc/moos8.png", "start": 7223073, "end": 7224501}, {"filename": "/data/images/groundpieces/transparent/misc/sun.png", "start": 7224501, "end": 7259635}, {"filename": "/data/images/groundpieces/transparent/misc/weed1.png", "start": 7259635, "end": 7261163}, {"filename": "/data/images/groundpieces/transparent/misc/weed2.png", "start": 7261163, "end": 7262005}, {"filename": "/data/images/groundpieces/transparent/snow/grass1.png", "start": 7262005, "end": 7263862}, {"filename": "/data/images/groundpieces/transparent/snow/grass2.png", "start": 7263862, "end": 7264924}, {"filename": "/data/images/groundpieces/transparent/snow/grass3.png", "start": 7264924, "end": 7265826}, {"filename": "/data/images/groundpieces/transparent/snow/grass4.png", "start": 7265826, "end": 7266846}, {"filename": "/data/images/groundpieces/transparent/snow/grass5.png", "start": 7266846, "end": 7267791}, {"filename": "/data/images/groundpieces/transparent/snow/plant1.png", "start": 7267791, "end": 7268939}, {"filename": "/data/images/groundpieces/transparent/snow/plant2.png", "start": 7268939, "end": 7269741}, {"filename": "/data/images/groundpieces/transparent/xmas/ball1.png", "start": 7269741, "end": 7270820}, {"filename": "/data/images/groundpieces/transparent/xmas/ball2.png", "start": 7270820, "end": 7271865}, {"filename": "/data/images/groundpieces/transparent/xmas/ball3.png", "start": 7271865, "end": 7272940}, {"filename": "/data/images/groundpieces/transparent/xmas/ball4.png", "start": 7272940, "end": 7274078}, {"filename": "/data/images/groundpieces/transparent/xmas/boot1.png", "start": 7274078, "end": 7276335}, {"filename": "/data/images/groundpieces/transparent/xmas/boot2.png", "start": 7276335, "end": 7278657}, {"filename": "/data/images/groundpieces/transparent/xmas/boot3.png", "start": 7278657, "end": 7281406}, {"filename": "/data/images/groundpieces/transparent/xmas/candystick1.png", "start": 7281406, "end": 7283060}, {"filename": "/data/images/groundpieces/transparent/xmas/candystick2.png", "start": 7283060, "end": 7284661}, {"filename": "/data/images/groundpieces/transparent/xmas/candystick3.png", "start": 7284661, "end": 7286481}, {"filename": "/data/images/groundpieces/transparent/xmas/green1.png", "start": 7286481, "end": 7288687}, {"filename": "/data/images/groundpieces/transparent/xmas/green2.png", "start": 7288687, "end": 7289926}, {"filename": "/data/images/groundpieces/transparent/xmas/green3.png", "start": 7289926, "end": 7290438}, {"filename": "/data/images/groundpieces/transparent/xmas/green4.png", "start": 7290438, "end": 7292688}, {"filename": "/data/images/groundpieces/transparent/xmas/hat1.png", "start": 7292688, "end": 7294668}, {"filename": "/data/images/groundpieces/transparent/xmas/hat2.png", "start": 7294668, "end": 7296690}, {"filename": "/data/images/groundpieces/transparent/xmas/icicle1.png", "start": 7296690, "end": 7297781}, {"filename": "/data/images/groundpieces/transparent/xmas/icicle2.png", "start": 7297781, "end": 7298640}, {"filename": "/data/images/groundpieces/transparent/xmas/icicle3.png", "start": 7298640, "end": 7299295}, {"filename": "/data/images/groundpieces/transparent/xmas/icicle4.png", "start": 7299295, "end": 7300363}, {"filename": "/data/images/groundpieces/transparent/xmas/present1.png", "start": 7300363, "end": 7302330}, {"filename": "/data/images/groundpieces/transparent/xmas/present2.png", "start": 7302330, "end": 7304381}, {"filename": "/data/images/groundpieces/transparent/xmas/present3.png", "start": 7304381, "end": 7306375}, {"filename": "/data/images/gui/checkbox/checked.tga", "start": 7306375, "end": 7306926}, {"filename": "/data/images/gui/checkbox/checked_disabled.tga", "start": 7306926, "end": 7307477}, {"filename": "/data/images/gui/checkbox/unchecked.tga", "start": 7307477, "end": 7308028}, {"filename": "/data/images/gui/checkbox/unchecked_disabled.tga", "start": 7308028, "end": 7308579}, {"filename": "/data/images/gui/checkbox_checked.png", "start": 7308579, "end": 7308680}, {"filename": "/data/images/gui/checkbox_checked_disabled.png", "start": 7308680, "end": 7308816}, {"filename": "/data/images/gui/checkbox_unchecked.png", "start": 7308816, "end": 7308891}, {"filename": "/data/images/gui/checkbox_unchecked_disabled.png", "start": 7308891, "end": 7308996}, {"filename": "/data/images/gui/font_black.png", "start": 7308996, "end": 7309745}, {"filename": "/data/images/gui/font_black.tga", "start": 7309745, "end": 7360861}, {"filename": "/data/images/gui/font_gray.png", "start": 7360861, "end": 7361610}, {"filename": "/data/images/gui/font_gray.tga", "start": 7361610, "end": 7372148}, {"filename": "/data/images/gui/font_white.tga", "start": 7372148, "end": 7382735}, {"filename": "/data/images/gui/fonts/font_black.tga", "start": 7382735, "end": 7433851}, {"filename": "/data/images/gui/fonts/font_gray.tga", "start": 7433851, "end": 7444389}, {"filename": "/data/images/gui/radiobutton/checked.tga", "start": 7444389, "end": 7445009}, {"filename": "/data/images/gui/radiobutton/checked_disabled.tga", "start": 7445009, "end": 7445629}, {"filename": "/data/images/gui/radiobutton/unchecked.tga", "start": 7445629, "end": 7446249}, {"filename": "/data/images/gui/radiobutton/unchecked_disabled.tga", "start": 7446249, "end": 7446869}, {"filename": "/data/images/gui/radiobutton_checked.png", "start": 7446869, "end": 7446997}, {"filename": "/data/images/gui/radiobutton_checked_disabled.png", "start": 7446997, "end": 7447129}, {"filename": "/data/images/gui/radiobutton_unchecked.png", "start": 7447129, "end": 7447252}, {"filename": "/data/images/gui/radiobutton_unchecked_disabled.png", "start": 7447252, "end": 7447417}, {"filename": "/data/images/hotspots/desert/bigdimwall.png", "start": 7447417, "end": 7449583}, {"filename": "/data/images/hotspots/desert/mediumdimwall.png", "start": 7449583, "end": 7451404}, {"filename": "/data/images/hotspots/desert/mediumegyptpic.png", "start": 7451404, "end": 7563774}, {"filename": "/data/images/hotspots/desert/mediummummy.png", "start": 7563774, "end": 7577571}, {"filename": "/data/images/hotspots/desert/mediumsphinx.png", "start": 7577571, "end": 7583842}, {"filename": "/data/images/hotspots/desert/smallD.png", "start": 7583842, "end": 7584122}, {"filename": "/data/images/hotspots/desert/smallE.png", "start": 7584122, "end": 7584387}, {"filename": "/data/images/hotspots/desert/smallG.png", "start": 7584387, "end": 7584661}, {"filename": "/data/images/hotspots/desert/smallO.png", "start": 7584661, "end": 7584944}, {"filename": "/data/images/hotspots/desert/smalldimwall.png", "start": 7584944, "end": 7586503}, {"filename": "/data/images/hotspots/desert/smallegyptpic.png", "start": 7586503, "end": 7597334}, {"filename": "/data/images/hotspots/desert/smallmummy.png", "start": 7597334, "end": 7599027}, {"filename": "/data/images/hotspots/desert/smallsphinx.png", "start": 7599027, "end": 7601580}, {"filename": "/data/images/hotspots/halloween/moon.png", "start": 7601580, "end": 7610592}, {"filename": "/data/images/hotspots/halloween/sign-down.png", "start": 7610592, "end": 7612360}, {"filename": "/data/images/hotspots/halloween/sign-left.png", "start": 7612360, "end": 7614364}, {"filename": "/data/images/hotspots/halloween/sign-right.png", "start": 7614364, "end": 7616423}, {"filename": "/data/images/hotspots/halloween/sign-up.png", "start": 7616423, "end": 7618418}, {"filename": "/data/images/hotspots/misc/bridge.png", "start": 7618418, "end": 7623249}, {"filename": "/data/images/hotspots/misc/crystal.png", "start": 7623249, "end": 7632677}, {"filename": "/data/images/hotspots/misc/deadly_fall_height.png", "start": 7632677, "end": 7637566}, {"filename": "/data/images/hotspots/misc/jumper_path.png", "start": 7637566, "end": 7642879}, {"filename": "/data/images/hotspots/misc/tree.png", "start": 7642879, "end": 7662921}, {"filename": "/data/images/hotspots/signposts/arrow_east.png", "start": 7662921, "end": 7664725}, {"filename": "/data/images/hotspots/signposts/arrow_north.png", "start": 7664725, "end": 7666502}, {"filename": "/data/images/hotspots/signposts/arrow_northeast.png", "start": 7666502, "end": 7668312}, {"filename": "/data/images/hotspots/signposts/arrow_northwest.png", "start": 7668312, "end": 7670120}, {"filename": "/data/images/hotspots/signposts/arrow_south.png", "start": 7670120, "end": 7671933}, {"filename": "/data/images/hotspots/signposts/arrow_southeast.png", "start": 7671933, "end": 7673754}, {"filename": "/data/images/hotspots/signposts/arrow_southwest.png", "start": 7673754, "end": 7675567}, {"filename": "/data/images/hotspots/signposts/arrow_west.png", "start": 7675567, "end": 7677388}, {"filename": "/data/images/hotspots/signposts/basher.png", "start": 7677388, "end": 7679153}, {"filename": "/data/images/hotspots/signposts/blocker.png", "start": 7679153, "end": 7680911}, {"filename": "/data/images/hotspots/signposts/bomber.png", "start": 7680911, "end": 7682674}, {"filename": "/data/images/hotspots/signposts/bridger.png", "start": 7682674, "end": 7684450}, {"filename": "/data/images/hotspots/signposts/climber.png", "start": 7684450, "end": 7686203}, {"filename": "/data/images/hotspots/signposts/danger.png", "start": 7686203, "end": 7688021}, {"filename": "/data/images/hotspots/signposts/digger.png", "start": 7688021, "end": 7689788}, {"filename": "/data/images/hotspots/signposts/floater.png", "start": 7689788, "end": 7691577}, {"filename": "/data/images/hotspots/signposts/miner.png", "start": 7691577, "end": 7693336}, {"filename": "/data/images/hotspots/signposts/nogo.png", "start": 7693336, "end": 7695113}, {"filename": "/data/images/hotspots/space/engine.png", "start": 7695113, "end": 7747885}, {"filename": "/data/images/hotspots/space/engine.sprite", "start": 7747885, "end": 7747982}, {"filename": "/data/images/icons/pingus-icon.png", "start": 7747982, "end": 7752704}, {"filename": "/data/images/icons/pingus-icon.svg", "start": 7752704, "end": 7758363}, {"filename": "/data/images/icons/pingus-icon2.png", "start": 7758363, "end": 7761573}, {"filename": "/data/images/icons/pingus-icon2.svg", "start": 7761573, "end": 7771909}, {"filename": "/data/images/icons/pingus.ico", "start": 7771909, "end": 7785851}, {"filename": "/data/images/icons/pingus.png", "start": 7785851, "end": 7788658}, {"filename": "/data/images/icons/pingus.svg", "start": 7788658, "end": 7804670}, {"filename": "/data/images/icons/supertux-icon.svg", "start": 7804670, "end": 7809584}, {"filename": "/data/images/levelsets/alien.png", "start": 7809584, "end": 7810984}, {"filename": "/data/images/levelsets/desert.png", "start": 7810984, "end": 7822218}, {"filename": "/data/images/levelsets/factory.png", "start": 7822218, "end": 7826082}, {"filename": "/data/images/levelsets/halloween.png", "start": 7826082, "end": 7841157}, {"filename": "/data/images/levelsets/halloween2011.png", "start": 7841157, "end": 7851590}, {"filename": "/data/images/levelsets/mysteryisland.png", "start": 7851590, "end": 7864834}, {"filename": "/data/images/levelsets/pacman.png", "start": 7864834, "end": 7878529}, {"filename": "/data/images/levelsets/underconstruction.png", "start": 7878529, "end": 7884065}, {"filename": "/data/images/levelsets/xmas.png", "start": 7884065, "end": 7886471}, {"filename": "/data/images/levelsets/xmas2011.png", "start": 7886471, "end": 7890076}, {"filename": "/data/images/liquids/lava.png", "start": 7890076, "end": 7907290}, {"filename": "/data/images/liquids/lava.sprite", "start": 7907290, "end": 7907384}, {"filename": "/data/images/liquids/slime.png", "start": 7907384, "end": 7955769}, {"filename": "/data/images/liquids/slime.sprite", "start": 7955769, "end": 7955864}, {"filename": "/data/images/liquids/swater.png", "start": 7955864, "end": 7956743}, {"filename": "/data/images/liquids/swater.sprite", "start": 7956743, "end": 7956838}, {"filename": "/data/images/liquids/water.png", "start": 7956838, "end": 7958104}, {"filename": "/data/images/liquids/water.sprite", "start": 7958104, "end": 7958199}, {"filename": "/data/images/liquids/water2.png", "start": 7958199, "end": 7964074}, {"filename": "/data/images/liquids/water2.sprite", "start": 7964074, "end": 7964169}, {"filename": "/data/images/liquids/water3.png", "start": 7964169, "end": 7975713}, {"filename": "/data/images/liquids/water3.sprite", "start": 7975713, "end": 7975808}, {"filename": "/data/images/liquids/water4.png", "start": 7975808, "end": 7983878}, {"filename": "/data/images/liquids/water4.sprite", "start": 7983878, "end": 7983973}, {"filename": "/data/images/liquids/water5.png", "start": 7983973, "end": 7995517}, {"filename": "/data/images/liquids/water5.sprite", "start": 7995517, "end": 7995612}, {"filename": "/data/images/liquids/water_cmap.png", "start": 7995612, "end": 7995724}, {"filename": "/data/images/other/bash_radius.sprite", "start": 7995724, "end": 7995791}, {"filename": "/data/images/other/bash_radius_gfx.sprite", "start": 7995791, "end": 7995862}, {"filename": "/data/images/other/bomber_radius.sprite", "start": 7995862, "end": 7995931}, {"filename": "/data/images/other/bomber_radius_gfx.sprite", "start": 7995931, "end": 7996004}, {"filename": "/data/images/other/brick_left.sprite", "start": 7996004, "end": 7996070}, {"filename": "/data/images/other/brick_right.sprite", "start": 7996070, "end": 7996137}, {"filename": "/data/images/other/digger_radius.sprite", "start": 7996137, "end": 7996206}, {"filename": "/data/images/other/digger_radius_gfx.sprite", "start": 7996206, "end": 7996279}, {"filename": "/data/images/other/floaterlayer/left.sprite", "start": 7996279, "end": 7996444}, {"filename": "/data/images/other/floaterlayer/right.sprite", "start": 7996444, "end": 7996627}, {"filename": "/data/images/other/laser_kill/left.sprite", "start": 7996627, "end": 7996789}, {"filename": "/data/images/other/laser_kill/right.sprite", "start": 7996789, "end": 7996969}, {"filename": "/data/images/other/light.sprite", "start": 7996969, "end": 7997050}, {"filename": "/data/images/other/splash.sprite", "start": 7997050, "end": 7997168}, {"filename": "/data/images/other/splash_debris.sprite", "start": 7997168, "end": 7997292}, {"filename": "/data/images/particles/explosive.png", "start": 7997292, "end": 7997425}, {"filename": "/data/images/particles/ground.png", "start": 7997425, "end": 8001883}, {"filename": "/data/images/particles/ground.sprite", "start": 8001883, "end": 8001978}, {"filename": "/data/images/particles/ground_snow.png", "start": 8001978, "end": 8002134}, {"filename": "/data/images/particles/particle.png", "start": 8002134, "end": 8002251}, {"filename": "/data/images/particles/pingu_explo.png", "start": 8002251, "end": 8002379}, {"filename": "/data/images/particles/pingu_explo.sprite", "start": 8002379, "end": 8002477}, {"filename": "/data/images/particles/rain1.png", "start": 8002477, "end": 8002957}, {"filename": "/data/images/particles/rain2.png", "start": 8002957, "end": 8003360}, {"filename": "/data/images/particles/rain_splash.png", "start": 8003360, "end": 8003514}, {"filename": "/data/images/particles/smoke.png", "start": 8003514, "end": 8010672}, {"filename": "/data/images/particles/smoke.sprite", "start": 8010672, "end": 8010786}, {"filename": "/data/images/particles/smoke2.png", "start": 8010786, "end": 8015931}, {"filename": "/data/images/particles/smoke2.sprite", "start": 8015931, "end": 8016046}, {"filename": "/data/images/particles/snow1.png", "start": 8016046, "end": 8016167}, {"filename": "/data/images/particles/snow2.png", "start": 8016167, "end": 8016308}, {"filename": "/data/images/particles/snow3.png", "start": 8016308, "end": 8016415}, {"filename": "/data/images/particles/snow4.png", "start": 8016415, "end": 8016526}, {"filename": "/data/images/particles/snow5.png", "start": 8016526, "end": 8016621}, {"filename": "/data/images/pingus/README", "start": 8016621, "end": 8017396}, {"filename": "/data/images/pingus/common/bash_radius.png", "start": 8017396, "end": 8017550}, {"filename": "/data/images/pingus/common/bash_radius_gfx.png", "start": 8017550, "end": 8017711}, {"filename": "/data/images/pingus/common/bomber_radius.png", "start": 8017711, "end": 8019679}, {"filename": "/data/images/pingus/common/bomber_radius_gfx.png", "start": 8019679, "end": 8021661}, {"filename": "/data/images/pingus/common/brick_left.png", "start": 8021661, "end": 8021795}, {"filename": "/data/images/pingus/common/brick_right.png", "start": 8021795, "end": 8021928}, {"filename": "/data/images/pingus/common/digger_radius.png", "start": 8021928, "end": 8022146}, {"filename": "/data/images/pingus/common/digger_radius_final.png", "start": 8022146, "end": 8022368}, {"filename": "/data/images/pingus/common/digger_radius_final_gfx.png", "start": 8022368, "end": 8022590}, {"filename": "/data/images/pingus/common/digger_radius_gfx.png", "start": 8022590, "end": 8022808}, {"filename": "/data/images/pingus/common/floaterlayer.png", "start": 8022808, "end": 8024236}, {"filename": "/data/images/pingus/common/laser_kill.png", "start": 8024236, "end": 8035275}, {"filename": "/data/images/pingus/common/light.png", "start": 8035275, "end": 8064837}, {"filename": "/data/images/pingus/common/miner_radius.png", "start": 8064837, "end": 8064991}, {"filename": "/data/images/pingus/common/miner_radius_gfx.png", "start": 8064991, "end": 8065152}, {"filename": "/data/images/pingus/common/miner_radius_left.png", "start": 8065152, "end": 8065384}, {"filename": "/data/images/pingus/common/miner_radius_left_gfx.png", "start": 8065384, "end": 8065637}, {"filename": "/data/images/pingus/common/miner_radius_right.png", "start": 8065637, "end": 8065867}, {"filename": "/data/images/pingus/common/miner_radius_right_gfx.png", "start": 8065867, "end": 8066117}, {"filename": "/data/images/pingus/common/splash.png", "start": 8066117, "end": 8066776}, {"filename": "/data/images/pingus/common/splash_debris.png", "start": 8066776, "end": 8067935}, {"filename": "/data/images/pingus/common/xmas-walker.png", "start": 8067935, "end": 8073126}, {"filename": "/data/images/pingus/player0/angel.png", "start": 8073126, "end": 8074168}, {"filename": "/data/images/pingus/player0/angel.sprite", "start": 8074168, "end": 8074262}, {"filename": "/data/images/pingus/player0/basher.png", "start": 8074262, "end": 8079765}, {"filename": "/data/images/pingus/player0/basher/left.sprite", "start": 8079765, "end": 8079906}, {"filename": "/data/images/pingus/player0/basher/right.sprite", "start": 8079906, "end": 8080065}, {"filename": "/data/images/pingus/player0/blocker.png", "start": 8080065, "end": 8081270}, {"filename": "/data/images/pingus/player0/blocker/left.sprite", "start": 8081270, "end": 8081412}, {"filename": "/data/images/pingus/player0/blocker/right.sprite", "start": 8081412, "end": 8081554}, {"filename": "/data/images/pingus/player0/boarder.png", "start": 8081554, "end": 8082530}, {"filename": "/data/images/pingus/player0/boarder/left.sprite", "start": 8082530, "end": 8082589}, {"filename": "/data/images/pingus/player0/boarder/right.sprite", "start": 8082589, "end": 8082666}, {"filename": "/data/images/pingus/player0/bomber.png", "start": 8082666, "end": 8086287}, {"filename": "/data/images/pingus/player0/bomber/left.sprite", "start": 8086287, "end": 8086427}, {"filename": "/data/images/pingus/player0/bomber/right.sprite", "start": 8086427, "end": 8086567}, {"filename": "/data/images/pingus/player0/bridger.png", "start": 8086567, "end": 8092630}, {"filename": "/data/images/pingus/player0/bridger/left.sprite", "start": 8092630, "end": 8092771}, {"filename": "/data/images/pingus/player0/bridger/right.sprite", "start": 8092771, "end": 8092930}, {"filename": "/data/images/pingus/player0/bridger_walk.png", "start": 8092930, "end": 8094930}, {"filename": "/data/images/pingus/player0/bridger_walk/left.sprite", "start": 8094930, "end": 8095075}, {"filename": "/data/images/pingus/player0/bridger_walk/right.sprite", "start": 8095075, "end": 8095238}, {"filename": "/data/images/pingus/player0/climber.png", "start": 8095238, "end": 8099835}, {"filename": "/data/images/pingus/player0/climber/left.sprite", "start": 8099835, "end": 8099974}, {"filename": "/data/images/pingus/player0/climber/right.sprite", "start": 8099974, "end": 8100132}, {"filename": "/data/images/pingus/player0/digger.png", "start": 8100132, "end": 8102246}, {"filename": "/data/images/pingus/player0/digger/left.sprite", "start": 8102246, "end": 8102387}, {"filename": "/data/images/pingus/player0/digger/right.sprite", "start": 8102387, "end": 8102528}, {"filename": "/data/images/pingus/player0/drownfall.png", "start": 8102528, "end": 8109085}, {"filename": "/data/images/pingus/player0/drownfall/left.sprite", "start": 8109085, "end": 8109228}, {"filename": "/data/images/pingus/player0/drownfall/right.sprite", "start": 8109228, "end": 8109389}, {"filename": "/data/images/pingus/player0/drownwalk.png", "start": 8109389, "end": 8116178}, {"filename": "/data/images/pingus/player0/drownwalk/left.sprite", "start": 8116178, "end": 8116279}, {"filename": "/data/images/pingus/player0/drownwalk/right.sprite", "start": 8116279, "end": 8116398}, {"filename": "/data/images/pingus/player0/exit.png", "start": 8116398, "end": 8118869}, {"filename": "/data/images/pingus/player0/exit/left.sprite", "start": 8118869, "end": 8119007}, {"filename": "/data/images/pingus/player0/exit/right.sprite", "start": 8119007, "end": 8119162}, {"filename": "/data/images/pingus/player0/explo.png", "start": 8119162, "end": 8120628}, {"filename": "/data/images/pingus/player0/faller.png", "start": 8120628, "end": 8123111}, {"filename": "/data/images/pingus/player0/faller/left.sprite", "start": 8123111, "end": 8123250}, {"filename": "/data/images/pingus/player0/faller/right.sprite", "start": 8123250, "end": 8123389}, {"filename": "/data/images/pingus/player0/floater.png", "start": 8123389, "end": 8124376}, {"filename": "/data/images/pingus/player0/floater/left.sprite", "start": 8124376, "end": 8124517}, {"filename": "/data/images/pingus/player0/floater/right.sprite", "start": 8124517, "end": 8124658}, {"filename": "/data/images/pingus/player0/jumper/left.sprite", "start": 8124658, "end": 8124798}, {"filename": "/data/images/pingus/player0/jumper/right.sprite", "start": 8124798, "end": 8124938}, {"filename": "/data/images/pingus/player0/miner.png", "start": 8124938, "end": 8132505}, {"filename": "/data/images/pingus/player0/miner/left.sprite", "start": 8132505, "end": 8132645}, {"filename": "/data/images/pingus/player0/miner/right.sprite", "start": 8132645, "end": 8132803}, {"filename": "/data/images/pingus/player0/rocketlauncher.png", "start": 8132803, "end": 8134026}, {"filename": "/data/images/pingus/player0/rocketlauncher/left.sprite", "start": 8134026, "end": 8134173}, {"filename": "/data/images/pingus/player0/rocketlauncher/right.sprite", "start": 8134173, "end": 8134338}, {"filename": "/data/images/pingus/player0/slider.png", "start": 8134338, "end": 8135731}, {"filename": "/data/images/pingus/player0/slider/left.sprite", "start": 8135731, "end": 8135831}, {"filename": "/data/images/pingus/player0/slider/right.sprite", "start": 8135831, "end": 8135949}, {"filename": "/data/images/pingus/player0/splat.png", "start": 8135949, "end": 8138327}, {"filename": "/data/images/pingus/player0/splat.sprite", "start": 8138327, "end": 8138463}, {"filename": "/data/images/pingus/player0/superman.png", "start": 8138463, "end": 8139467}, {"filename": "/data/images/pingus/player0/superman.sprite", "start": 8139467, "end": 8139564}, {"filename": "/data/images/pingus/player0/tumble.png", "start": 8139564, "end": 8142278}, {"filename": "/data/images/pingus/player0/tumbler/left.sprite", "start": 8142278, "end": 8142417}, {"filename": "/data/images/pingus/player0/tumbler/right.sprite", "start": 8142417, "end": 8142556}, {"filename": "/data/images/pingus/player0/waiter.png", "start": 8142556, "end": 8143590}, {"filename": "/data/images/pingus/player0/waiter/left.sprite", "start": 8143590, "end": 8143730}, {"filename": "/data/images/pingus/player0/waiter/right.sprite", "start": 8143730, "end": 8143870}, {"filename": "/data/images/pingus/player0/walker.png", "start": 8143870, "end": 8148675}, {"filename": "/data/images/pingus/player0/walker/left.sprite", "start": 8148675, "end": 8148814}, {"filename": "/data/images/pingus/player0/walker/right.sprite", "start": 8148814, "end": 8148971}, {"filename": "/data/images/pingus/player1/angel.sprite", "start": 8148971, "end": 8149065}, {"filename": "/data/images/pingus/player1/basher/left.sprite", "start": 8149065, "end": 8149206}, {"filename": "/data/images/pingus/player1/basher/right.sprite", "start": 8149206, "end": 8149365}, {"filename": "/data/images/pingus/player1/blocker/left.sprite", "start": 8149365, "end": 8149506}, {"filename": "/data/images/pingus/player1/blocker/right.sprite", "start": 8149506, "end": 8149647}, {"filename": "/data/images/pingus/player1/boarder/left.sprite", "start": 8149647, "end": 8149706}, {"filename": "/data/images/pingus/player1/boarder/right.sprite", "start": 8149706, "end": 8149783}, {"filename": "/data/images/pingus/player1/bomber/left.sprite", "start": 8149783, "end": 8149923}, {"filename": "/data/images/pingus/player1/bomber/right.sprite", "start": 8149923, "end": 8150063}, {"filename": "/data/images/pingus/player1/bridger/left.sprite", "start": 8150063, "end": 8150204}, {"filename": "/data/images/pingus/player1/bridger/right.sprite", "start": 8150204, "end": 8150363}, {"filename": "/data/images/pingus/player1/bridger_walk/left.sprite", "start": 8150363, "end": 8150508}, {"filename": "/data/images/pingus/player1/bridger_walk/right.sprite", "start": 8150508, "end": 8150671}, {"filename": "/data/images/pingus/player1/climber/left.sprite", "start": 8150671, "end": 8150813}, {"filename": "/data/images/pingus/player1/climber/right.sprite", "start": 8150813, "end": 8150974}, {"filename": "/data/images/pingus/player1/digger/left.sprite", "start": 8150974, "end": 8151115}, {"filename": "/data/images/pingus/player1/digger/right.sprite", "start": 8151115, "end": 8151256}, {"filename": "/data/images/pingus/player1/drownfall/left.sprite", "start": 8151256, "end": 8151399}, {"filename": "/data/images/pingus/player1/drownfall/right.sprite", "start": 8151399, "end": 8151560}, {"filename": "/data/images/pingus/player1/drownwalk/left.sprite", "start": 8151560, "end": 8151661}, {"filename": "/data/images/pingus/player1/drownwalk/right.sprite", "start": 8151661, "end": 8151780}, {"filename": "/data/images/pingus/player1/exit/left.sprite", "start": 8151780, "end": 8151918}, {"filename": "/data/images/pingus/player1/exit/right.sprite", "start": 8151918, "end": 8152073}, {"filename": "/data/images/pingus/player1/faller/left.sprite", "start": 8152073, "end": 8152213}, {"filename": "/data/images/pingus/player1/faller/right.sprite", "start": 8152213, "end": 8152353}, {"filename": "/data/images/pingus/player1/floater/left.sprite", "start": 8152353, "end": 8152494}, {"filename": "/data/images/pingus/player1/floater/right.sprite", "start": 8152494, "end": 8152635}, {"filename": "/data/images/pingus/player1/jumper/left.sprite", "start": 8152635, "end": 8152775}, {"filename": "/data/images/pingus/player1/jumper/right.sprite", "start": 8152775, "end": 8152915}, {"filename": "/data/images/pingus/player1/miner/left.sprite", "start": 8152915, "end": 8153055}, {"filename": "/data/images/pingus/player1/miner/right.sprite", "start": 8153055, "end": 8153213}, {"filename": "/data/images/pingus/player1/rocketlauncher/left.sprite", "start": 8153213, "end": 8153360}, {"filename": "/data/images/pingus/player1/rocketlauncher/right.sprite", "start": 8153360, "end": 8153525}, {"filename": "/data/images/pingus/player1/slider/left.sprite", "start": 8153525, "end": 8153625}, {"filename": "/data/images/pingus/player1/slider/right.sprite", "start": 8153625, "end": 8153743}, {"filename": "/data/images/pingus/player1/splat.sprite", "start": 8153743, "end": 8153879}, {"filename": "/data/images/pingus/player1/superman.sprite", "start": 8153879, "end": 8153976}, {"filename": "/data/images/pingus/player1/tumbler/left.sprite", "start": 8153976, "end": 8154116}, {"filename": "/data/images/pingus/player1/tumbler/right.sprite", "start": 8154116, "end": 8154256}, {"filename": "/data/images/pingus/player1/waiter/left.sprite", "start": 8154256, "end": 8154396}, {"filename": "/data/images/pingus/player1/waiter/right.sprite", "start": 8154396, "end": 8154536}, {"filename": "/data/images/pingus/player1/walker/left.sprite", "start": 8154536, "end": 8154675}, {"filename": "/data/images/pingus/player1/walker/right.sprite", "start": 8154675, "end": 8154832}, {"filename": "/data/images/pingus/player2/angel.sprite", "start": 8154832, "end": 8154926}, {"filename": "/data/images/pingus/player2/basher/left.sprite", "start": 8154926, "end": 8155067}, {"filename": "/data/images/pingus/player2/basher/right.sprite", "start": 8155067, "end": 8155226}, {"filename": "/data/images/pingus/player2/blocker/left.sprite", "start": 8155226, "end": 8155367}, {"filename": "/data/images/pingus/player2/blocker/right.sprite", "start": 8155367, "end": 8155508}, {"filename": "/data/images/pingus/player2/boarder/left.sprite", "start": 8155508, "end": 8155567}, {"filename": "/data/images/pingus/player2/boarder/right.sprite", "start": 8155567, "end": 8155644}, {"filename": "/data/images/pingus/player2/bomber/left.sprite", "start": 8155644, "end": 8155784}, {"filename": "/data/images/pingus/player2/bomber/right.sprite", "start": 8155784, "end": 8155924}, {"filename": "/data/images/pingus/player2/bridger/left.sprite", "start": 8155924, "end": 8156065}, {"filename": "/data/images/pingus/player2/bridger/right.sprite", "start": 8156065, "end": 8156224}, {"filename": "/data/images/pingus/player2/bridger_walk/left.sprite", "start": 8156224, "end": 8156369}, {"filename": "/data/images/pingus/player2/bridger_walk/right.sprite", "start": 8156369, "end": 8156532}, {"filename": "/data/images/pingus/player2/climber/left.sprite", "start": 8156532, "end": 8156674}, {"filename": "/data/images/pingus/player2/climber/right.sprite", "start": 8156674, "end": 8156835}, {"filename": "/data/images/pingus/player2/digger/left.sprite", "start": 8156835, "end": 8156976}, {"filename": "/data/images/pingus/player2/digger/right.sprite", "start": 8156976, "end": 8157117}, {"filename": "/data/images/pingus/player2/drownfall/left.sprite", "start": 8157117, "end": 8157260}, {"filename": "/data/images/pingus/player2/drownfall/right.sprite", "start": 8157260, "end": 8157421}, {"filename": "/data/images/pingus/player2/drownwalk/left.sprite", "start": 8157421, "end": 8157522}, {"filename": "/data/images/pingus/player2/drownwalk/right.sprite", "start": 8157522, "end": 8157641}, {"filename": "/data/images/pingus/player2/exit/left.sprite", "start": 8157641, "end": 8157779}, {"filename": "/data/images/pingus/player2/exit/right.sprite", "start": 8157779, "end": 8157934}, {"filename": "/data/images/pingus/player2/faller/left.sprite", "start": 8157934, "end": 8158074}, {"filename": "/data/images/pingus/player2/faller/right.sprite", "start": 8158074, "end": 8158214}, {"filename": "/data/images/pingus/player2/floater/left.sprite", "start": 8158214, "end": 8158355}, {"filename": "/data/images/pingus/player2/floater/right.sprite", "start": 8158355, "end": 8158496}, {"filename": "/data/images/pingus/player2/jumper/left.sprite", "start": 8158496, "end": 8158636}, {"filename": "/data/images/pingus/player2/jumper/right.sprite", "start": 8158636, "end": 8158776}, {"filename": "/data/images/pingus/player2/miner/left.sprite", "start": 8158776, "end": 8158916}, {"filename": "/data/images/pingus/player2/miner/right.sprite", "start": 8158916, "end": 8159074}, {"filename": "/data/images/pingus/player2/rocketlauncher/left.sprite", "start": 8159074, "end": 8159221}, {"filename": "/data/images/pingus/player2/rocketlauncher/right.sprite", "start": 8159221, "end": 8159386}, {"filename": "/data/images/pingus/player2/slider/left.sprite", "start": 8159386, "end": 8159486}, {"filename": "/data/images/pingus/player2/slider/right.sprite", "start": 8159486, "end": 8159604}, {"filename": "/data/images/pingus/player2/splat.sprite", "start": 8159604, "end": 8159740}, {"filename": "/data/images/pingus/player2/superman.sprite", "start": 8159740, "end": 8159837}, {"filename": "/data/images/pingus/player2/tumbler/left.sprite", "start": 8159837, "end": 8159977}, {"filename": "/data/images/pingus/player2/tumbler/right.sprite", "start": 8159977, "end": 8160117}, {"filename": "/data/images/pingus/player2/waiter/left.sprite", "start": 8160117, "end": 8160257}, {"filename": "/data/images/pingus/player2/waiter/right.sprite", "start": 8160257, "end": 8160397}, {"filename": "/data/images/pingus/player2/walker/left.sprite", "start": 8160397, "end": 8160536}, {"filename": "/data/images/pingus/player2/walker/right.sprite", "start": 8160536, "end": 8160693}, {"filename": "/data/images/pingus/player3/angel.sprite", "start": 8160693, "end": 8160787}, {"filename": "/data/images/pingus/player3/basher/left.sprite", "start": 8160787, "end": 8160928}, {"filename": "/data/images/pingus/player3/basher/right.sprite", "start": 8160928, "end": 8161087}, {"filename": "/data/images/pingus/player3/blocker/left.sprite", "start": 8161087, "end": 8161228}, {"filename": "/data/images/pingus/player3/blocker/right.sprite", "start": 8161228, "end": 8161369}, {"filename": "/data/images/pingus/player3/boarder/left.sprite", "start": 8161369, "end": 8161428}, {"filename": "/data/images/pingus/player3/boarder/right.sprite", "start": 8161428, "end": 8161505}, {"filename": "/data/images/pingus/player3/bomber/left.sprite", "start": 8161505, "end": 8161645}, {"filename": "/data/images/pingus/player3/bomber/right.sprite", "start": 8161645, "end": 8161785}, {"filename": "/data/images/pingus/player3/bridger/left.sprite", "start": 8161785, "end": 8161926}, {"filename": "/data/images/pingus/player3/bridger/right.sprite", "start": 8161926, "end": 8162085}, {"filename": "/data/images/pingus/player3/bridger_walk/left.sprite", "start": 8162085, "end": 8162230}, {"filename": "/data/images/pingus/player3/bridger_walk/right.sprite", "start": 8162230, "end": 8162393}, {"filename": "/data/images/pingus/player3/climber/left.sprite", "start": 8162393, "end": 8162535}, {"filename": "/data/images/pingus/player3/climber/right.sprite", "start": 8162535, "end": 8162696}, {"filename": "/data/images/pingus/player3/digger/left.sprite", "start": 8162696, "end": 8162837}, {"filename": "/data/images/pingus/player3/digger/right.sprite", "start": 8162837, "end": 8162978}, {"filename": "/data/images/pingus/player3/drownfall/left.sprite", "start": 8162978, "end": 8163121}, {"filename": "/data/images/pingus/player3/drownfall/right.sprite", "start": 8163121, "end": 8163282}, {"filename": "/data/images/pingus/player3/drownwalk/left.sprite", "start": 8163282, "end": 8163383}, {"filename": "/data/images/pingus/player3/drownwalk/right.sprite", "start": 8163383, "end": 8163502}, {"filename": "/data/images/pingus/player3/exit/left.sprite", "start": 8163502, "end": 8163640}, {"filename": "/data/images/pingus/player3/exit/right.sprite", "start": 8163640, "end": 8163795}, {"filename": "/data/images/pingus/player3/faller/left.sprite", "start": 8163795, "end": 8163935}, {"filename": "/data/images/pingus/player3/faller/right.sprite", "start": 8163935, "end": 8164075}, {"filename": "/data/images/pingus/player3/floater/left.sprite", "start": 8164075, "end": 8164216}, {"filename": "/data/images/pingus/player3/floater/right.sprite", "start": 8164216, "end": 8164357}, {"filename": "/data/images/pingus/player3/jumper/left.sprite", "start": 8164357, "end": 8164497}, {"filename": "/data/images/pingus/player3/jumper/right.sprite", "start": 8164497, "end": 8164637}, {"filename": "/data/images/pingus/player3/miner/left.sprite", "start": 8164637, "end": 8164777}, {"filename": "/data/images/pingus/player3/miner/right.sprite", "start": 8164777, "end": 8164935}, {"filename": "/data/images/pingus/player3/rocketlauncher/left.sprite", "start": 8164935, "end": 8165082}, {"filename": "/data/images/pingus/player3/rocketlauncher/right.sprite", "start": 8165082, "end": 8165247}, {"filename": "/data/images/pingus/player3/slider/left.sprite", "start": 8165247, "end": 8165347}, {"filename": "/data/images/pingus/player3/slider/right.sprite", "start": 8165347, "end": 8165465}, {"filename": "/data/images/pingus/player3/splat.sprite", "start": 8165465, "end": 8165601}, {"filename": "/data/images/pingus/player3/superman.sprite", "start": 8165601, "end": 8165698}, {"filename": "/data/images/pingus/player3/tumbler/left.sprite", "start": 8165698, "end": 8165838}, {"filename": "/data/images/pingus/player3/tumbler/right.sprite", "start": 8165838, "end": 8165978}, {"filename": "/data/images/pingus/player3/waiter/left.sprite", "start": 8165978, "end": 8166118}, {"filename": "/data/images/pingus/player3/waiter/right.sprite", "start": 8166118, "end": 8166258}, {"filename": "/data/images/pingus/player3/walker/left.sprite", "start": 8166258, "end": 8166397}, {"filename": "/data/images/pingus/player3/walker/right.sprite", "start": 8166397, "end": 8166554}, {"filename": "/data/images/prefabs/desert_entrance.png", "start": 8166554, "end": 8179707}, {"filename": "/data/images/prefabs/desert_entrance.sprite", "start": 8179707, "end": 8179775}, {"filename": "/data/images/prefabs/entrances/cloud.png", "start": 8179775, "end": 8186661}, {"filename": "/data/images/prefabs/entrances/cloud.sprite", "start": 8186661, "end": 8186720}, {"filename": "/data/images/prefabs/entrances/desert.png", "start": 8186720, "end": 8200203}, {"filename": "/data/images/prefabs/entrances/desert.sprite", "start": 8200203, "end": 8200262}, {"filename": "/data/images/prefabs/entrances/eastern.png", "start": 8200262, "end": 8209862}, {"filename": "/data/images/prefabs/entrances/eastern.sprite", "start": 8209862, "end": 8209922}, {"filename": "/data/images/prefabs/entrances/halloween.png", "start": 8209922, "end": 8217740}, {"filename": "/data/images/prefabs/entrances/halloween.sprite", "start": 8217740, "end": 8217802}, {"filename": "/data/images/prefabs/entrances/industrial.png", "start": 8217802, "end": 8239109}, {"filename": "/data/images/prefabs/entrances/industrial.sprite", "start": 8239109, "end": 8239173}, {"filename": "/data/images/prefabs/entrances/snow.png", "start": 8239173, "end": 8245194}, {"filename": "/data/images/prefabs/entrances/snow.sprite", "start": 8245194, "end": 8245251}, {"filename": "/data/images/prefabs/entrances/sortie.png", "start": 8245251, "end": 8339029}, {"filename": "/data/images/prefabs/entrances/sortie.sprite", "start": 8339029, "end": 8339090}, {"filename": "/data/images/prefabs/entrances/space.png", "start": 8339090, "end": 8341463}, {"filename": "/data/images/prefabs/entrances/space.sprite", "start": 8341463, "end": 8341521}, {"filename": "/data/images/prefabs/entrances/woodbox.png", "start": 8341521, "end": 8348730}, {"filename": "/data/images/prefabs/entrances/woodbox.sprite", "start": 8348730, "end": 8348790}, {"filename": "/data/images/prefabs/entrances/woodthing.png", "start": 8348790, "end": 8375259}, {"filename": "/data/images/prefabs/entrances/woodthing.sprite", "start": 8375259, "end": 8375322}, {"filename": "/data/images/prefabs/entrances/xmas.png", "start": 8375322, "end": 8381370}, {"filename": "/data/images/prefabs/entrances/xmas.sprite", "start": 8381370, "end": 8381427}, {"filename": "/data/images/prefabs/industrial_entrance.png", "start": 8381427, "end": 8402102}, {"filename": "/data/images/prefabs/industrial_entrance.sprite", "start": 8402102, "end": 8402175}, {"filename": "/data/images/prefabs/liquid.png", "start": 8402175, "end": 8406464}, {"filename": "/data/images/prefabs/liquid.sprite", "start": 8406464, "end": 8406523}, {"filename": "/data/images/prefabs/liquids/slime.png", "start": 8406523, "end": 8410812}, {"filename": "/data/images/prefabs/liquids/slime.sprite", "start": 8410812, "end": 8410870}, {"filename": "/data/images/prefabs/liquids/water.png", "start": 8410870, "end": 8411820}, {"filename": "/data/images/prefabs/liquids/water.sprite", "start": 8411820, "end": 8411878}, {"filename": "/data/images/prefabs/misc/snowman1.png", "start": 8411878, "end": 8416934}, {"filename": "/data/images/prefabs/misc/snowman1.sprite", "start": 8416934, "end": 8416996}, {"filename": "/data/images/prefabs/snow_entrance.png", "start": 8416996, "end": 8423142}, {"filename": "/data/images/prefabs/snow_entrance.sprite", "start": 8423142, "end": 8423208}, {"filename": "/data/images/prefabs/snowman1.png", "start": 8423208, "end": 8428264}, {"filename": "/data/images/prefabs/snowman1.sprite", "start": 8428264, "end": 8428326}, {"filename": "/data/images/prefabs/sortie_entrance.png", "start": 8428326, "end": 8521982}, {"filename": "/data/images/prefabs/sortie_entrance.sprite", "start": 8521982, "end": 8522052}, {"filename": "/data/images/prefabs/woodthing_entrance.png", "start": 8522052, "end": 8548102}, {"filename": "/data/images/prefabs/woodthing_entrance.sprite", "start": 8548102, "end": 8548174}, {"filename": "/data/images/special/README", "start": 8548174, "end": 8548230}, {"filename": "/data/images/special/pacman/blinky.png", "start": 8548230, "end": 8548403}, {"filename": "/data/images/special/pacman/clyde.png", "start": 8548403, "end": 8548610}, {"filename": "/data/images/special/pacman/inky.png", "start": 8548610, "end": 8548791}, {"filename": "/data/images/special/pacman/pacman-bkg.png", "start": 8548791, "end": 8549748}, {"filename": "/data/images/special/pacman/pacman-frame.png", "start": 8549748, "end": 8550680}, {"filename": "/data/images/special/pacman/pacman-maze.png", "start": 8550680, "end": 8552068}, {"filename": "/data/images/special/pacman/pacman.png", "start": 8552068, "end": 8552217}, {"filename": "/data/images/special/pacman/pacman.sprite", "start": 8552217, "end": 8552284}, {"filename": "/data/images/special/pacman/pinky.png", "start": 8552284, "end": 8552454}, {"filename": "/data/images/story/background.sprite", "start": 8552454, "end": 8552539}, {"filename": "/data/images/story/credits1.png", "start": 8552539, "end": 8575945}, {"filename": "/data/images/story/credits1.sprite", "start": 8575945, "end": 8576007}, {"filename": "/data/images/story/credits2.png", "start": 8576007, "end": 8609265}, {"filename": "/data/images/story/credits2.sprite", "start": 8609265, "end": 8609327}, {"filename": "/data/images/story/credits3.png", "start": 8609327, "end": 8638763}, {"filename": "/data/images/story/credits3.sprite", "start": 8638763, "end": 8638825}, {"filename": "/data/images/story/credits4.png", "start": 8638825, "end": 8663803}, {"filename": "/data/images/story/credits4.sprite", "start": 8663803, "end": 8663865}, {"filename": "/data/images/story/story0.png", "start": 8663865, "end": 8686121}, {"filename": "/data/images/story/story0.sprite", "start": 8686121, "end": 8686181}, {"filename": "/data/images/story/story1.png", "start": 8686181, "end": 8722364}, {"filename": "/data/images/story/story1.sprite", "start": 8722364, "end": 8722424}, {"filename": "/data/images/story/story2.png", "start": 8722424, "end": 8760553}, {"filename": "/data/images/story/story2.sprite", "start": 8760553, "end": 8760613}, {"filename": "/data/images/story/story3.png", "start": 8760613, "end": 8792003}, {"filename": "/data/images/story/story3.sprite", "start": 8792003, "end": 8792063}, {"filename": "/data/images/story/story4.png", "start": 8792063, "end": 8825872}, {"filename": "/data/images/story/story4.sprite", "start": 8825872, "end": 8825932}, {"filename": "/data/images/story/story5.png", "start": 8825932, "end": 8879771}, {"filename": "/data/images/story/story5.sprite", "start": 8879771, "end": 8879831}, {"filename": "/data/images/story/story6.png", "start": 8879831, "end": 8918830}, {"filename": "/data/images/story/story6.sprite", "start": 8918830, "end": 8918890}, {"filename": "/data/images/textures/README", "start": 8918890, "end": 8920005}, {"filename": "/data/images/textures/anim_fire.jpg", "start": 8920005, "end": 8951072}, {"filename": "/data/images/textures/anim_fire.sprite", "start": 8951072, "end": 8951171}, {"filename": "/data/images/textures/blueflame.jpg", "start": 8951171, "end": 8960836}, {"filename": "/data/images/textures/bluestars.jpg", "start": 8960836, "end": 9009427}, {"filename": "/data/images/textures/bwsortiebg.jpg", "start": 9009427, "end": 9051634}, {"filename": "/data/images/textures/clouds.jpg", "start": 9051634, "end": 9054820}, {"filename": "/data/images/textures/clouds2.jpg", "start": 9054820, "end": 9067490}, {"filename": "/data/images/textures/clouds3.png", "start": 9067490, "end": 9189344}, {"filename": "/data/images/textures/creepers-mirrored.png", "start": 9189344, "end": 9210819}, {"filename": "/data/images/textures/creepers.png", "start": 9210819, "end": 9232313}, {"filename": "/data/images/textures/crystal.jpg", "start": 9232313, "end": 9237151}, {"filename": "/data/images/textures/cyanspace.jpg", "start": 9237151, "end": 9273244}, {"filename": "/data/images/textures/darkjungle.jpg", "start": 9273244, "end": 9290451}, {"filename": "/data/images/textures/default.png", "start": 9290451, "end": 9290571}, {"filename": "/data/images/textures/desert.jpg", "start": 9290571, "end": 9294709}, {"filename": "/data/images/textures/desert_room.jpg", "start": 9294709, "end": 9305662}, {"filename": "/data/images/textures/easter_grass.png", "start": 9305662, "end": 9401553}, {"filename": "/data/images/textures/easter_sky.jpg", "start": 9401553, "end": 9409901}, {"filename": "/data/images/textures/enchantedjungle.jpg", "start": 9409901, "end": 9420737}, {"filename": "/data/images/textures/flame.sprite", "start": 9420737, "end": 9420778}, {"filename": "/data/images/textures/flamebg.jpg", "start": 9420778, "end": 9427553}, {"filename": "/data/images/textures/fond1.sprite", "start": 9427553, "end": 9427593}, {"filename": "/data/images/textures/fruitcaketile.jpg", "start": 9427593, "end": 9451948}, {"filename": "/data/images/textures/green_tendrils.png", "start": 9451948, "end": 9487222}, {"filename": "/data/images/textures/greentex.jpg", "start": 9487222, "end": 9497907}, {"filename": "/data/images/textures/happyclouds.jpg", "start": 9497907, "end": 9517882}, {"filename": "/data/images/textures/icetile.jpg", "start": 9517882, "end": 9523586}, {"filename": "/data/images/textures/industrial.jpg", "start": 9523586, "end": 9536201}, {"filename": "/data/images/textures/latejungle.jpg", "start": 9536201, "end": 9552194}, {"filename": "/data/images/textures/lunartile.jpg", "start": 9552194, "end": 9562226}, {"filename": "/data/images/textures/mountain.png", "start": 9562226, "end": 9629503}, {"filename": "/data/images/textures/nightjungle.jpg", "start": 9629503, "end": 9638063}, {"filename": "/data/images/textures/ordina.jpg", "start": 9638063, "end": 9652437}, {"filename": "/data/images/textures/rock6.jpg", "start": 9652437, "end": 9674608}, {"filename": "/data/images/textures/rockagglo.jpg", "start": 9674608, "end": 9682189}, {"filename": "/data/images/textures/rocktile.jpg", "start": 9682189, "end": 9689669}, {"filename": "/data/images/textures/rooftile.jpg", "start": 9689669, "end": 9701646}, {"filename": "/data/images/textures/rooftile2.jpg", "start": 9701646, "end": 9714782}, {"filename": "/data/images/textures/solartile.jpg", "start": 9714782, "end": 9730839}, {"filename": "/data/images/textures/sortie.jpg", "start": 9730839, "end": 9738528}, {"filename": "/data/images/textures/sortiebgred.jpg", "start": 9738528, "end": 9806093}, {"filename": "/data/images/textures/stars.jpg", "start": 9806093, "end": 9825197}, {"filename": "/data/images/textures/stone.jpg", "start": 9825197, "end": 9834800}, {"filename": "/data/images/textures/stone.sprite", "start": 9834800, "end": 9834840}, {"filename": "/data/images/textures/stones.png", "start": 9834840, "end": 9893339}, {"filename": "/data/images/textures/stones.sprite", "start": 9893339, "end": 9893378}, {"filename": "/data/images/textures/swirljungle.png", "start": 9893378, "end": 9944977}, {"filename": "/data/images/textures/thunderstorm.png", "start": 9944977, "end": 9957724}, {"filename": "/data/images/traps/bumper.png", "start": 9957724, "end": 9966776}, {"filename": "/data/images/traps/bumper.sprite", "start": 9966776, "end": 9966899}, {"filename": "/data/images/traps/bumper_cmap.png", "start": 9966899, "end": 9969082}, {"filename": "/data/images/traps/fake_exit.png", "start": 9969082, "end": 9992049}, {"filename": "/data/images/traps/fake_exit.sprite", "start": 9992049, "end": 9992175}, {"filename": "/data/images/traps/gateway.png", "start": 9992175, "end": 9994525}, {"filename": "/data/images/traps/guillotineidle.png", "start": 9994525, "end": 9997815}, {"filename": "/data/images/traps/guillotineidle.sprite", "start": 9997815, "end": 9997918}, {"filename": "/data/images/traps/guillotinekill.png", "start": 9997918, "end": 10014201}, {"filename": "/data/images/traps/guillotinekill/left.sprite", "start": 10014201, "end": 10014308}, {"filename": "/data/images/traps/guillotinekill/right.sprite", "start": 10014308, "end": 10014433}, {"filename": "/data/images/traps/hammer.png", "start": 10014433, "end": 10035903}, {"filename": "/data/images/traps/hammer.sprite", "start": 10035903, "end": 10036000}, {"filename": "/data/images/traps/laser_exit.png", "start": 10036000, "end": 10055756}, {"filename": "/data/images/traps/laser_exit.sprite", "start": 10055756, "end": 10055855}, {"filename": "/data/images/traps/quicksand.png", "start": 10055855, "end": 10057540}, {"filename": "/data/images/traps/smasher.png", "start": 10057540, "end": 10177853}, {"filename": "/data/images/traps/smasher.sprite", "start": 10177853, "end": 10177937}, {"filename": "/data/images/traps/smasher_cmap.png", "start": 10177937, "end": 10178246}, {"filename": "/data/images/traps/spike.png", "start": 10178246, "end": 10183987}, {"filename": "/data/images/traps/spike.sprite", "start": 10183987, "end": 10184082}, {"filename": "/data/images/traps/spike_editor.png", "start": 10184082, "end": 10185842}, {"filename": "/data/images/traps/tut.png", "start": 10185842, "end": 10198519}, {"filename": "/data/images/worldmaps/misc/pacman.sprite", "start": 10198519, "end": 10198562}, {"filename": "/data/images/worldmaps/tutorial/layer0.sprite", "start": 10198562, "end": 10198614}, {"filename": "/data/images/worldmaps/tutorial/layer1.sprite", "start": 10198614, "end": 10198666}, {"filename": "/data/images/worldmaps/tutorial/layer2.sprite", "start": 10198666, "end": 10198718}, {"filename": "/data/images/worldmaps/tutorial/layer3.sprite", "start": 10198718, "end": 10198770}, {"filename": "/data/images/worldmaps/tutorial_layer0.jpg", "start": 10198770, "end": 10358036}, {"filename": "/data/images/worldmaps/tutorial_layer1.png", "start": 10358036, "end": 10370616}, {"filename": "/data/images/worldmaps/tutorial_layer2.png", "start": 10370616, "end": 10374195}, {"filename": "/data/images/worldmaps/tutorial_layer3.png", "start": 10374195, "end": 10375890}, {"filename": "/data/images/worldmaps/volcano/island.sprite", "start": 10375890, "end": 10375934}, {"filename": "/data/images/worldobjs/conveyorbelt_cmap.png", "start": 10375934, "end": 10376868}, {"filename": "/data/images/worldobjs/conveyorbelt_left.png", "start": 10376868, "end": 10377293}, {"filename": "/data/images/worldobjs/conveyorbelt_left.sprite", "start": 10377293, "end": 10377400}, {"filename": "/data/images/worldobjs/conveyorbelt_middle.png", "start": 10377400, "end": 10377625}, {"filename": "/data/images/worldobjs/conveyorbelt_middle.sprite", "start": 10377625, "end": 10377734}, {"filename": "/data/images/worldobjs/conveyorbelt_right.png", "start": 10377734, "end": 10378116}, {"filename": "/data/images/worldobjs/conveyorbelt_right.sprite", "start": 10378116, "end": 10378224}, {"filename": "/data/images/worldobjs/iceblock.png", "start": 10378224, "end": 10379569}, {"filename": "/data/images/worldobjs/iceblock.sprite", "start": 10379569, "end": 10379666}, {"filename": "/data/images/worldobjs/iceblock_cmap.png", "start": 10379666, "end": 10380118}, {"filename": "/data/images/worldobjs/infobox.png", "start": 10380118, "end": 10382863}, {"filename": "/data/images/worldobjs/infobox.sprite", "start": 10382863, "end": 10382931}, {"filename": "/data/images/worldobjs/switchdoor_box.png", "start": 10382931, "end": 10383783}, {"filename": "/data/images/worldobjs/switchdoor_switch.png", "start": 10383783, "end": 10384750}, {"filename": "/data/images/worldobjs/switchdoor_tile.png", "start": 10384750, "end": 10385000}, {"filename": "/data/images/worldobjs/switchdoor_tile_cmap.png", "start": 10385000, "end": 10385096}, {"filename": "/data/images/worldobjs/teleporter.png", "start": 10385096, "end": 10394776}, {"filename": "/data/images/worldobjs/teleporter.sprite", "start": 10394776, "end": 10394901}, {"filename": "/data/images/worldobjs/teleporter2.png", "start": 10394901, "end": 10401499}, {"filename": "/data/images/worldobjs/teleporter2.sprite", "start": 10401499, "end": 10401564}, {"filename": "/data/images/worldobjs/teleportertarget.png", "start": 10401564, "end": 10425339}, {"filename": "/data/images/worldobjs/teleportertarget.sprite", "start": 10425339, "end": 10425463}, {"filename": "/data/levels/COMMENTS", "start": 10425463, "end": 10427606}, {"filename": "/data/levels/alien/aliens1-phil.pingus", "start": 10427606, "end": 10452393}, {"filename": "/data/levels/alien/aliens2-phil.pingus", "start": 10452393, "end": 10477301}, {"filename": "/data/levels/alien/aliens4-phil.pingus", "start": 10477301, "end": 10525796}, {"filename": "/data/levels/alien/aliens5-phil.pingus", "start": 10525796, "end": 10575560}, {"filename": "/data/levels/alien/aliens6-phil.pingus", "start": 10575560, "end": 10629589}, {"filename": "/data/levels/alien/aliens7-phil.pingus", "start": 10629589, "end": 10680884}, {"filename": "/data/levels/alien/space-11-rz+eriksoe.pingus", "start": 10680884, "end": 10693556}, {"filename": "/data/levels/alien/space-9-tom.pingus", "start": 10693556, "end": 10698807}, {"filename": "/data/levels/alien/space-loop-timpany.pingus", "start": 10698807, "end": 10709044}, {"filename": "/data/levels/alien/space-tom1.pingus", "start": 10709044, "end": 10714446}, {"filename": "/data/levels/alien/space2.pingus", "start": 10714446, "end": 10738540}, {"filename": "/data/levels/candy/block-timpany.pingus", "start": 10738540, "end": 10756892}, {"filename": "/data/levels/crystal/cave-crystal1-mw.pingus", "start": 10756892, "end": 10777880}, {"filename": "/data/levels/crystal/cave-crystal2-mw.pingus", "start": 10777880, "end": 10797062}, {"filename": "/data/levels/crystal/crystal-phil1.pingus", "start": 10797062, "end": 10822348}, {"filename": "/data/levels/crystal/crystal1.pingus", "start": 10822348, "end": 10835479}, {"filename": "/data/levels/crystal/crystal10-rz.pingus", "start": 10835479, "end": 10878358}, {"filename": "/data/levels/crystal/crystal2.pingus", "start": 10878358, "end": 10896708}, {"filename": "/data/levels/crystal/crystal3.pingus", "start": 10896708, "end": 10920171}, {"filename": "/data/levels/crystal/crystal4.pingus", "start": 10920171, "end": 10955110}, {"filename": "/data/levels/crystal/crystal5.pingus", "start": 10955110, "end": 10967724}, {"filename": "/data/levels/crystal/crystalcave1-gunter.pingus", "start": 10967724, "end": 10987807}, {"filename": "/data/levels/crystal/crystalcave2-gunter.pingus", "start": 10987807, "end": 10994724}, {"filename": "/data/levels/crystal/crystalcave3-gunter.pingus", "start": 10994724, "end": 11007760}, {"filename": "/data/levels/crystal/crystalcave4-gunter.pingus", "start": 11007760, "end": 11017845}, {"filename": "/data/levels/crystal/jewel.pingus", "start": 11017845, "end": 11042016}, {"filename": "/data/levels/crystal/lonely.pingus", "start": 11042016, "end": 11061287}, {"filename": "/data/levels/crystal/longway.pingus", "start": 11061287, "end": 11085003}, {"filename": "/data/levels/crystal/parallel.pingus", "start": 11085003, "end": 11106172}, {"filename": "/data/levels/crystal/sept-crystal1-mw.pingus", "start": 11106172, "end": 11125656}, {"filename": "/data/levels/desert/desert-crawl-timpany.pingus", "start": 11125656, "end": 11145002}, {"filename": "/data/levels/desert/desert1-janne.pingus", "start": 11145002, "end": 11157287}, {"filename": "/data/levels/desert/desert1.pingus", "start": 11157287, "end": 11177579}, {"filename": "/data/levels/desert/desert2.pingus", "start": 11177579, "end": 11193949}, {"filename": "/data/levels/desert/desert3-jings.pingus", "start": 11193949, "end": 11219107}, {"filename": "/data/levels/desert/desert3.pingus", "start": 11219107, "end": 11231926}, {"filename": "/data/levels/desert/desert4.pingus", "start": 11231926, "end": 11244619}, {"filename": "/data/levels/desert/desert5-tflavel.pingus", "start": 11244619, "end": 11255736}, {"filename": "/data/levels/desert/desert5.pingus", "start": 11255736, "end": 11270619}, {"filename": "/data/levels/desert/desert6-grumbel.pingus", "start": 11270619, "end": 11280448}, {"filename": "/data/levels/desert/desert7-grumbel.pingus", "start": 11280448, "end": 11295423}, {"filename": "/data/levels/desert/desert8-grumbel.pingus", "start": 11295423, "end": 11308414}, {"filename": "/data/levels/desert/desertwaste1-grumbel.pingus", "start": 11308414, "end": 11318355}, {"filename": "/data/levels/desert/indiana-yingwan.pingus", "start": 11318355, "end": 11335534}, {"filename": "/data/levels/easter/easter1-grumbel.pingus", "start": 11335534, "end": 11353744}, {"filename": "/data/levels/easter/easter2-grumbel.pingus", "start": 11353744, "end": 11367614}, {"filename": "/data/levels/easter/easter3-grumbel.pingus", "start": 11367614, "end": 11376435}, {"filename": "/data/levels/factorycampaign/factory_campaign1.pingus", "start": 11376435, "end": 11391710}, {"filename": "/data/levels/factorycampaign/factory_campaign10.pingus", "start": 11391710, "end": 11415179}, {"filename": "/data/levels/factorycampaign/factory_campaign11.pingus", "start": 11415179, "end": 11453150}, {"filename": "/data/levels/factorycampaign/factory_campaign12.pingus", "start": 11453150, "end": 11484566}, {"filename": "/data/levels/factorycampaign/factory_campaign13.pingus", "start": 11484566, "end": 11506915}, {"filename": "/data/levels/factorycampaign/factory_campaign2.pingus", "start": 11506915, "end": 11525447}, {"filename": "/data/levels/factorycampaign/factory_campaign3.pingus", "start": 11525447, "end": 11549523}, {"filename": "/data/levels/factorycampaign/factory_campaign4.pingus", "start": 11549523, "end": 11590086}, {"filename": "/data/levels/factorycampaign/factory_campaign5.pingus", "start": 11590086, "end": 11608170}, {"filename": "/data/levels/factorycampaign/factory_campaign6.pingus", "start": 11608170, "end": 11624043}, {"filename": "/data/levels/factorycampaign/factory_campaign7.pingus", "start": 11624043, "end": 11648859}, {"filename": "/data/levels/factorycampaign/factory_campaign8.pingus", "start": 11648859, "end": 11670127}, {"filename": "/data/levels/factorycampaign/factory_campaign9.pingus", "start": 11670127, "end": 11700232}, {"filename": "/data/levels/forest/forest1-grumbel.pingus", "start": 11700232, "end": 11721037}, {"filename": "/data/levels/halloween/halloween1-grumbel.pingus", "start": 11721037, "end": 11759869}, {"filename": "/data/levels/halloween/halloween2-grumbel.pingus", "start": 11759869, "end": 11795380}, {"filename": "/data/levels/halloween/halloween3-grumbel.pingus", "start": 11795380, "end": 11830257}, {"filename": "/data/levels/halloween/halloween4-grumbel.pingus", "start": 11830257, "end": 11849294}, {"filename": "/data/levels/halloween/halloween5-grumbel.pingus", "start": 11849294, "end": 11876455}, {"filename": "/data/levels/halloween/halloween6-grumbel.pingus", "start": 11876455, "end": 11932838}, {"filename": "/data/levels/halloween/halloween7-grumbel.pingus", "start": 11932838, "end": 11974670}, {"filename": "/data/levels/halloween/halloween8-plouj.pingus", "start": 11974670, "end": 12018378}, {"filename": "/data/levels/halloween2011/halloween10-grumbel.pingus", "start": 12018378, "end": 12108375}, {"filename": "/data/levels/halloween2011/halloween11-grumbel.pingus", "start": 12108375, "end": 12207469}, {"filename": "/data/levels/halloween2011/halloween12-grumbel.pingus", "start": 12207469, "end": 12288895}, {"filename": "/data/levels/halloween2011/halloween13-grumbel.pingus", "start": 12288895, "end": 12397490}, {"filename": "/data/levels/halloween2011/halloween14-grumbel.pingus", "start": 12397490, "end": 12493998}, {"filename": "/data/levels/halloween2011/halloween15-grumbel.pingus", "start": 12493998, "end": 12560246}, {"filename": "/data/levels/halloween2011/halloween16-grumbel.pingus", "start": 12560246, "end": 12612905}, {"filename": "/data/levels/halloween2011/halloween17-grumbel.pingus", "start": 12612905, "end": 12658098}, {"filename": "/data/levels/halloween2011/halloween18-grumbel.pingus", "start": 12658098, "end": 12756854}, {"filename": "/data/levels/halloween2011/halloween19-rz.pingus", "start": 12756854, "end": 12827818}, {"filename": "/data/levels/hellmouth/hellmouth01-grumbel.pingus", "start": 12827818, "end": 12845259}, {"filename": "/data/levels/hellmouth/hellmouth02-grumbel.pingus", "start": 12845259, "end": 12868410}, {"filename": "/data/levels/hellmouth/hellmouth03-grumbel.pingus", "start": 12868410, "end": 12881267}, {"filename": "/data/levels/hellmouth/hellmouth04-grumbel.pingus", "start": 12881267, "end": 12891639}, {"filename": "/data/levels/hellmouth/hellmouth05-grumbel.pingus", "start": 12891639, "end": 12907246}, {"filename": "/data/levels/hellmouth/hellmouth06-grumbel.pingus", "start": 12907246, "end": 12918147}, {"filename": "/data/levels/hellmouth/hellmouth07-grumbel.pingus", "start": 12918147, "end": 12930407}, {"filename": "/data/levels/hellmouth/hellmouth08-grumbel.pingus", "start": 12930407, "end": 12940465}, {"filename": "/data/levels/hellmouth/hellmouth09-grumbel.pingus", "start": 12940465, "end": 12952584}, {"filename": "/data/levels/hellmouth/hellmouth10-grumbel.pingus", "start": 12952584, "end": 12966681}, {"filename": "/data/levels/hellmouth/hellmouth11-rz.pingus", "start": 12966681, "end": 12980291}, {"filename": "/data/levels/hellmouth/hellmouth12-grumbel.pingus", "start": 12980291, "end": 12992219}, {"filename": "/data/levels/hellmouth/hellmouth13-grumbel.pingus", "start": 12992219, "end": 13009741}, {"filename": "/data/levels/hellmouth/hellmouth14-grumbel.pingus", "start": 13009741, "end": 13025130}, {"filename": "/data/levels/hellmouth/hellmouth15-grumbel.pingus", "start": 13025130, "end": 13045109}, {"filename": "/data/levels/hellmouth/hellmouth17-grumbel.pingus", "start": 13045109, "end": 13057862}, {"filename": "/data/levels/hellmouth/hellmouth20-grumbel.pingus", "start": 13057862, "end": 13061626}, {"filename": "/data/levels/hellmouth/hellmouth21-grumbel.pingus", "start": 13061626, "end": 13070534}, {"filename": "/data/levels/hellmouth/hellmouth22-grumbel.pingus", "start": 13070534, "end": 13080156}, {"filename": "/data/levels/hellmouth/hellmouth23-rz+eriksoe.pingus", "start": 13080156, "end": 13105530}, {"filename": "/data/levels/hellmouth/hellmouth24-rz.pingus", "start": 13105530, "end": 13130692}, {"filename": "/data/levels/incoming/README", "start": 13130692, "end": 13130838}, {"filename": "/data/levels/incoming/bouncing-bp-1.pingus", "start": 13130838, "end": 13139484}, {"filename": "/data/levels/incoming/glassy1-howard.pingus", "start": 13139484, "end": 13151724}, {"filename": "/data/levels/incoming/gletcher1-darune.pingus", "start": 13151724, "end": 13158247}, {"filename": "/data/levels/incoming/gletcher2-darune.pingus", "start": 13158247, "end": 13198920}, {"filename": "/data/levels/incoming/stone1-darune.pingus", "start": 13198920, "end": 13210047}, {"filename": "/data/levels/incoming/stone2-darune.pingus", "start": 13210047, "end": 13225863}, {"filename": "/data/levels/incoming/stone3-darune.pingus", "start": 13225863, "end": 13241719}, {"filename": "/data/levels/incoming/tester.pingus", "start": 13241719, "end": 13248259}, {"filename": "/data/levels/jungle/cave-jungle1-mw.pingus", "start": 13248259, "end": 13265138}, {"filename": "/data/levels/jungle/foliage3.pingus", "start": 13265138, "end": 13293545}, {"filename": "/data/levels/jungle/headbang.pingus", "start": 13293545, "end": 13301651}, {"filename": "/data/levels/jungle/intersec.pingus", "start": 13301651, "end": 13306790}, {"filename": "/data/levels/jungle/jungle-13-rz+eriksoe.pingus", "start": 13306790, "end": 13317193}, {"filename": "/data/levels/jungle/jungle-airline-timpany.pingus", "start": 13317193, "end": 13322835}, {"filename": "/data/levels/jungle/jungle-crisscross-timpany.pingus", "start": 13322835, "end": 13330433}, {"filename": "/data/levels/jungle/jungle1.pingus", "start": 13330433, "end": 13336632}, {"filename": "/data/levels/jungle/jungle2.pingus", "start": 13336632, "end": 13339504}, {"filename": "/data/levels/jungle/rinse.pingus", "start": 13339504, "end": 13345947}, {"filename": "/data/levels/jungle/wland-timpany.pingus", "start": 13345947, "end": 13359589}, {"filename": "/data/levels/multiplayer/multi1-grumbel.pingus", "start": 13359589, "end": 13371671}, {"filename": "/data/levels/multiplayer/multi2-grumbel.pingus", "start": 13371671, "end": 13419249}, {"filename": "/data/levels/mysteryisland/cave-lac.pingus", "start": 13419249, "end": 13446550}, {"filename": "/data/levels/mysteryisland/cave1-marcotte.pingus", "start": 13446550, "end": 13473105}, {"filename": "/data/levels/mysteryisland/emperiment-lac.pingus", "start": 13473105, "end": 13478321}, {"filename": "/data/levels/mysteryisland/hall-of-illusion-lac.pingus", "start": 13478321, "end": 13497017}, {"filename": "/data/levels/mysteryisland/lavapit3.pingus", "start": 13497017, "end": 13523640}, {"filename": "/data/levels/mysteryisland/madscientist1-lac.pingus", "start": 13523640, "end": 13536032}, {"filename": "/data/levels/mysteryisland/multi1-lac.pingus", "start": 13536032, "end": 13543973}, {"filename": "/data/levels/mysteryisland/rainy1-lac.pingus", "start": 13543973, "end": 13570889}, {"filename": "/data/levels/mysteryisland/revenge1-lac.pingus", "start": 13570889, "end": 13587850}, {"filename": "/data/levels/mysteryisland/revenge2-lac.pingus", "start": 13587850, "end": 13608208}, {"filename": "/data/levels/mysteryisland/snow2-lac.pingus", "start": 13608208, "end": 13640118}, {"filename": "/data/levels/mysteryisland/theend-lac.pingus", "start": 13640118, "end": 13647539}, {"filename": "/data/levels/mysteryisland/use-the-slide-lac.pingus", "start": 13647539, "end": 13660947}, {"filename": "/data/levels/mysteryisland/volcano1-grumbel.pingus", "start": 13660947, "end": 13676082}, {"filename": "/data/levels/pacman/pacman1-yingwan.pingus", "start": 13676082, "end": 13678458}, {"filename": "/data/levels/pacman/pacman2-yingwan.pingus", "start": 13678458, "end": 13680788}, {"filename": "/data/levels/pacman/pacman3-yingwan.pingus", "start": 13680788, "end": 13683159}, {"filename": "/data/levels/playable/bombing.pingus", "start": 13683159, "end": 13707293}, {"filename": "/data/levels/playable/dentist.pingus", "start": 13707293, "end": 13715010}, {"filename": "/data/levels/playable/desert8-ralph.pingus", "start": 13715010, "end": 13732947}, {"filename": "/data/levels/playable/desert9-jings.pingus", "start": 13732947, "end": 13751443}, {"filename": "/data/levels/playable/egypt1-judit.pingus", "start": 13751443, "end": 13784729}, {"filename": "/data/levels/playable/future3-jgoebbert.pingus", "start": 13784729, "end": 13827104}, {"filename": "/data/levels/playable/novelty-jings.pingus", "start": 13827104, "end": 13845566}, {"filename": "/data/levels/playable/particle.pingus", "start": 13845566, "end": 13851035}, {"filename": "/data/levels/playable/pingustemple2-pacho.pingus", "start": 13851035, "end": 13860705}, {"filename": "/data/levels/playable/pyramid1-yingwan.pingus", "start": 13860705, "end": 13865525}, {"filename": "/data/levels/playable/real1.pingus", "start": 13865525, "end": 13879753}, {"filename": "/data/levels/playable/real5.pingus", "start": 13879753, "end": 13886258}, {"filename": "/data/levels/playable/real6.pingus", "start": 13886258, "end": 13895980}, {"filename": "/data/levels/playable/rockhopping.pingus", "start": 13895980, "end": 13902263}, {"filename": "/data/levels/playable/sno1-marcotte.pingus", "start": 13902263, "end": 13927224}, {"filename": "/data/levels/playable/sortie1.pingus", "start": 13927224, "end": 13933361}, {"filename": "/data/levels/playable/stone13-grumbel.pingus", "start": 13933361, "end": 13946985}, {"filename": "/data/levels/playable/stone14-grumbel.pingus", "start": 13946985, "end": 13962752}, {"filename": "/data/levels/playable/stone15-grumbel.pingus", "start": 13962752, "end": 13976330}, {"filename": "/data/levels/playable/w1-judit.pingus", "start": 13976330, "end": 13992696}, {"filename": "/data/levels/playable/xmas-complex-timpany.pingus", "start": 13992696, "end": 14004929}, {"filename": "/data/levels/snow/sas.pingus", "start": 14004929, "end": 14024225}, {"filename": "/data/levels/test/actions.pingus", "start": 14024225, "end": 14069309}, {"filename": "/data/levels/test/background-test.pingus", "start": 14069309, "end": 14073152}, {"filename": "/data/levels/test/basher.pingus", "start": 14073152, "end": 14078912}, {"filename": "/data/levels/test/bg-test.pingus", "start": 14078912, "end": 14081541}, {"filename": "/data/levels/test/blitter.pingus", "start": 14081541, "end": 14085165}, {"filename": "/data/levels/test/blocker.pingus", "start": 14085165, "end": 14130250}, {"filename": "/data/levels/test/bridger.pingus", "start": 14130250, "end": 14139336}, {"filename": "/data/levels/test/chink.pingus", "start": 14139336, "end": 14141485}, {"filename": "/data/levels/test/climber.pingus", "start": 14141485, "end": 14147879}, {"filename": "/data/levels/test/conveyorbelt.pingus", "start": 14147879, "end": 14149205}, {"filename": "/data/levels/test/exit.pingus", "start": 14149205, "end": 14150713}, {"filename": "/data/levels/test/fallbug.pingus", "start": 14150713, "end": 14152259}, {"filename": "/data/levels/test/faller.pingus", "start": 14152259, "end": 14161090}, {"filename": "/data/levels/test/highfall.pingus", "start": 14161090, "end": 14162119}, {"filename": "/data/levels/test/jumper.pingus", "start": 14162119, "end": 14165810}, {"filename": "/data/levels/test/jumper2.pingus", "start": 14165810, "end": 14169005}, {"filename": "/data/levels/test/jumperbounce.pingus", "start": 14169005, "end": 14170886}, {"filename": "/data/levels/test/meta.pingus", "start": 14170886, "end": 14171492}, {"filename": "/data/levels/test/order.pingus", "start": 14171492, "end": 14172602}, {"filename": "/data/levels/test/rotation.pingus", "start": 14172602, "end": 14174428}, {"filename": "/data/levels/test/smallmap.pingus", "start": 14174428, "end": 14175998}, {"filename": "/data/levels/test/test1.pingus", "start": 14175998, "end": 14179779}, {"filename": "/data/levels/test/test2.pingus", "start": 14179779, "end": 14183176}, {"filename": "/data/levels/test/test3.pingus", "start": 14183176, "end": 14190312}, {"filename": "/data/levels/test/test6.pingus", "start": 14190312, "end": 14194997}, {"filename": "/data/levels/test/test8.pingus", "start": 14194997, "end": 14197201}, {"filename": "/data/levels/test/walker.pingus", "start": 14197201, "end": 14202807}, {"filename": "/data/levels/tutorial/basher-tutorial-grumbel.pingus", "start": 14202807, "end": 14228199}, {"filename": "/data/levels/tutorial/bomber-tutorial2-grumbel.pingus", "start": 14228199, "end": 14247864}, {"filename": "/data/levels/tutorial/digger-tutorial2-grumbel.pingus", "start": 14247864, "end": 14260246}, {"filename": "/data/levels/tutorial/floater-tutorial-grumbel.pingus", "start": 14260246, "end": 14269558}, {"filename": "/data/levels/tutorial/jumper-tutorial-grumbel.pingus", "start": 14269558, "end": 14295753}, {"filename": "/data/levels/tutorial/miner-tutorial2-grumbel.pingus", "start": 14295753, "end": 14319598}, {"filename": "/data/levels/tutorial/snow10-grumbel.pingus", "start": 14319598, "end": 14341380}, {"filename": "/data/levels/tutorial/snow11-grumbel.pingus", "start": 14341380, "end": 14350952}, {"filename": "/data/levels/tutorial/snow12-grumbel.pingus", "start": 14350952, "end": 14365014}, {"filename": "/data/levels/tutorial/snow14-grumbel.pingus", "start": 14365014, "end": 14382352}, {"filename": "/data/levels/tutorial/snow15-grumbel.pingus", "start": 14382352, "end": 14401159}, {"filename": "/data/levels/tutorial/snow16-grumbel.pingus", "start": 14401159, "end": 14418275}, {"filename": "/data/levels/tutorial/snow17-grumbel.pingus", "start": 14418275, "end": 14436575}, {"filename": "/data/levels/tutorial/snow19-grumbel.pingus", "start": 14436575, "end": 14464421}, {"filename": "/data/levels/tutorial/snow20-grumbel.pingus", "start": 14464421, "end": 14485931}, {"filename": "/data/levels/tutorial/snow21-grumbel.pingus", "start": 14485931, "end": 14500062}, {"filename": "/data/levels/tutorial/snow22-grumbel.pingus", "start": 14500062, "end": 14512106}, {"filename": "/data/levels/tutorial/snow7-grumbel.pingus", "start": 14512106, "end": 14527103}, {"filename": "/data/levels/tutorial/snow8-grumbel.pingus", "start": 14527103, "end": 14568065}, {"filename": "/data/levels/tutorial/snow9-grumbel.pingus", "start": 14568065, "end": 14584099}, {"filename": "/data/levels/tutorial/solid-tutorial-grumbel.pingus", "start": 14584099, "end": 14598503}, {"filename": "/data/levels/volcano/volcano2-grumbel.pingus", "start": 14598503, "end": 14620491}, {"filename": "/data/levels/wip/am_nil-luki.pingus", "start": 14620491, "end": 14625018}, {"filename": "/data/levels/wip/belt1-grumbel.pingus", "start": 14625018, "end": 14626815}, {"filename": "/data/levels/wip/block.pingus", "start": 14626815, "end": 14635935}, {"filename": "/data/levels/wip/candy-lukis.pingus", "start": 14635935, "end": 14641508}, {"filename": "/data/levels/wip/candy1.pingus", "start": 14641508, "end": 14657276}, {"filename": "/data/levels/wip/cave-cave1-mw.pingus", "start": 14657276, "end": 14685599}, {"filename": "/data/levels/wip/cave-cave2-mw.pingus", "start": 14685599, "end": 14718525}, {"filename": "/data/levels/wip/cave-food1-mw.pingus", "start": 14718525, "end": 14733610}, {"filename": "/data/levels/wip/cave-snow1-mw.pingus", "start": 14733610, "end": 14754975}, {"filename": "/data/levels/wip/cave-space1-mw.pingus", "start": 14754975, "end": 14761126}, {"filename": "/data/levels/wip/cave-space2-mw.pingus", "start": 14761126, "end": 14792717}, {"filename": "/data/levels/wip/cave-tubes1-mw.pingus", "start": 14792717, "end": 14821108}, {"filename": "/data/levels/wip/conv.pingus", "start": 14821108, "end": 14821823}, {"filename": "/data/levels/wip/desert-crawl-ralph.pingus", "start": 14821823, "end": 14844915}, {"filename": "/data/levels/wip/desert-phil1.pingus", "start": 14844915, "end": 14850775}, {"filename": "/data/levels/wip/desert-phil2.pingus", "start": 14850775, "end": 14861295}, {"filename": "/data/levels/wip/desert3-tflavel.pingus", "start": 14861295, "end": 14877858}, {"filename": "/data/levels/wip/editor_tut.pingus", "start": 14877858, "end": 14886575}, {"filename": "/data/levels/wip/foliage1.pingus", "start": 14886575, "end": 14894638}, {"filename": "/data/levels/wip/foliage4.pingus", "start": 14894638, "end": 14900426}, {"filename": "/data/levels/wip/granit1.pingus", "start": 14900426, "end": 14910989}, {"filename": "/data/levels/wip/green1-grumbel.pingus", "start": 14910989, "end": 14914206}, {"filename": "/data/levels/wip/hellmouth-phil1.pingus", "start": 14914206, "end": 14923666}, {"filename": "/data/levels/wip/hellmouth11-grumbel.pingus", "start": 14923666, "end": 14930391}, {"filename": "/data/levels/wip/hellmouth16-grumbel.pingus", "start": 14930391, "end": 14935521}, {"filename": "/data/levels/wip/hellmouth18-grumbel.pingus", "start": 14935521, "end": 14943050}, {"filename": "/data/levels/wip/hellmouth19-grumbel.pingus", "start": 14943050, "end": 14962928}, {"filename": "/data/levels/wip/hellmouth23-grumbel.pingus", "start": 14962928, "end": 14969079}, {"filename": "/data/levels/wip/hotmush-gordon.pingus", "start": 14969079, "end": 14976650}, {"filename": "/data/levels/wip/iceblock-grumbel1.pingus", "start": 14976650, "end": 14982424}, {"filename": "/data/levels/wip/industrial1-grumbel.pingus", "start": 14982424, "end": 14985160}, {"filename": "/data/levels/wip/industrial2-grumbel.pingus", "start": 14985160, "end": 15003374}, {"filename": "/data/levels/wip/isle1-grumbel.pingus", "start": 15003374, "end": 15009202}, {"filename": "/data/levels/wip/large1.pingus", "start": 15009202, "end": 15073517}, {"filename": "/data/levels/wip/level0.pingus", "start": 15073517, "end": 15076542}, {"filename": "/data/levels/wip/level10.pingus", "start": 15076542, "end": 15081001}, {"filename": "/data/levels/wip/level12.pingus", "start": 15081001, "end": 15096761}, {"filename": "/data/levels/wip/level19.pingus", "start": 15096761, "end": 15102047}, {"filename": "/data/levels/wip/level2.pingus", "start": 15102047, "end": 15112854}, {"filename": "/data/levels/wip/level3.pingus", "start": 15112854, "end": 15143512}, {"filename": "/data/levels/wip/level5.pingus", "start": 15143512, "end": 15157608}, {"filename": "/data/levels/wip/level7.pingus", "start": 15157608, "end": 15165924}, {"filename": "/data/levels/wip/level8.pingus", "start": 15165924, "end": 15172397}, {"filename": "/data/levels/wip/mud1-grumbel.pingus", "start": 15172397, "end": 15180283}, {"filename": "/data/levels/wip/mud2-grumbel.pingus", "start": 15180283, "end": 15183007}, {"filename": "/data/levels/wip/mushroom.pingus", "start": 15183007, "end": 15191468}, {"filename": "/data/levels/wip/ordina1-lawrence.pingus", "start": 15191468, "end": 15199299}, {"filename": "/data/levels/wip/park-mkoller.pingus", "start": 15199299, "end": 15208512}, {"filename": "/data/levels/wip/penguinworld-franko.pingus", "start": 15208512, "end": 15225878}, {"filename": "/data/levels/wip/pipedreams1-grumbel.pingus", "start": 15225878, "end": 15243617}, {"filename": "/data/levels/wip/pipes1.pingus", "start": 15243617, "end": 15252494}, {"filename": "/data/levels/wip/pyramid-bandara.pingus", "start": 15252494, "end": 15260843}, {"filename": "/data/levels/wip/real2.pingus", "start": 15260843, "end": 15268133}, {"filename": "/data/levels/wip/real3.pingus", "start": 15268133, "end": 15273572}, {"filename": "/data/levels/wip/real4.pingus", "start": 15273572, "end": 15279237}, {"filename": "/data/levels/wip/rock1.pingus", "start": 15279237, "end": 15289711}, {"filename": "/data/levels/wip/sept-aztec1-mw.pingus", "start": 15289711, "end": 15296680}, {"filename": "/data/levels/wip/sept-cave1-mw.pingus", "start": 15296680, "end": 15314986}, {"filename": "/data/levels/wip/sept-snow1-mw.pingus", "start": 15314986, "end": 15326883}, {"filename": "/data/levels/wip/sept-space1-mw.pingus", "start": 15326883, "end": 15336135}, {"filename": "/data/levels/wip/small1.pingus", "start": 15336135, "end": 15346882}, {"filename": "/data/levels/wip/snow-lukis.pingus", "start": 15346882, "end": 15358453}, {"filename": "/data/levels/wip/snow2.pingus", "start": 15358453, "end": 15387784}, {"filename": "/data/levels/wip/snow3.pingus", "start": 15387784, "end": 15398077}, {"filename": "/data/levels/wip/snow4.pingus", "start": 15398077, "end": 15412169}, {"filename": "/data/levels/wip/snow5.pingus", "start": 15412169, "end": 15440802}, {"filename": "/data/levels/wip/snow6.pingus", "start": 15440802, "end": 15456072}, {"filename": "/data/levels/wip/sortie-lukis.pingus", "start": 15456072, "end": 15461413}, {"filename": "/data/levels/wip/sortie2.pingus", "start": 15461413, "end": 15476838}, {"filename": "/data/levels/wip/sortie3.pingus", "start": 15476838, "end": 15478542}, {"filename": "/data/levels/wip/space-phil1.pingus", "start": 15478542, "end": 15507449}, {"filename": "/data/levels/wip/space1.pingus", "start": 15507449, "end": 15528870}, {"filename": "/data/levels/wip/space3.pingus", "start": 15528870, "end": 15547614}, {"filename": "/data/levels/wip/space4-grumbel.pingus", "start": 15547614, "end": 15559233}, {"filename": "/data/levels/wip/stone-brinkmann.pingus", "start": 15559233, "end": 15563420}, {"filename": "/data/levels/wip/stone.pingus", "start": 15563420, "end": 15627792}, {"filename": "/data/levels/wip/stone10-grumbel.pingus", "start": 15627792, "end": 15646799}, {"filename": "/data/levels/wip/stone11-grumbel.pingus", "start": 15646799, "end": 15655393}, {"filename": "/data/levels/wip/stone12-grumbel.pingus", "start": 15655393, "end": 15683739}, {"filename": "/data/levels/wip/stone2.pingus", "start": 15683739, "end": 15704082}, {"filename": "/data/levels/wip/stone3-grumbel.pingus", "start": 15704082, "end": 15710926}, {"filename": "/data/levels/wip/stone4-grumbel.pingus", "start": 15710926, "end": 15718776}, {"filename": "/data/levels/wip/stone6-grumbel.pingus", "start": 15718776, "end": 15727941}, {"filename": "/data/levels/wip/stone8-grumbel.pingus", "start": 15727941, "end": 15736925}, {"filename": "/data/levels/wip/sweets-phil1.pingus", "start": 15736925, "end": 15744103}, {"filename": "/data/levels/wip/test-luki.pingus", "start": 15744103, "end": 15746870}, {"filename": "/data/levels/wip/volcano3-grumbel.pingus", "start": 15746870, "end": 15756446}, {"filename": "/data/levels/wip/volcano4-grumbel.pingus", "start": 15756446, "end": 15760643}, {"filename": "/data/levels/xmas2011/xmas01-grumbel.pingus", "start": 15760643, "end": 15804976}, {"filename": "/data/levels/xmas2011/xmas02-grumbel.pingus", "start": 15804976, "end": 15859486}, {"filename": "/data/levels/xmas2011/xmas03-grumbel.pingus", "start": 15859486, "end": 15918789}, {"filename": "/data/levels/xmas2011/xmas04-grumbel.pingus", "start": 15918789, "end": 15964583}, {"filename": "/data/levels/xmas2011/xmas05-grumbel.pingus", "start": 15964583, "end": 16023487}, {"filename": "/data/levels/xmas2011/xmas06-grumbel.pingus", "start": 16023487, "end": 16066264}, {"filename": "/data/levels/xmas2011/xmas07-grumbel.pingus", "start": 16066264, "end": 16115585}, {"filename": "/data/levels/xmas2011/xmas08-grumbel.pingus", "start": 16115585, "end": 16151885}, {"filename": "/data/levels/xmas2011/xmas09-grumbel.pingus", "start": 16151885, "end": 16208085}, {"filename": "/data/levels/xmas2011/xmas10-grumbel.pingus", "start": 16208085, "end": 16244661}, {"filename": "/data/levels/xskat/new/achtung_falle_15-jonas_bannert.pingus", "start": 16244661, "end": 16252224}, {"filename": "/data/levels/xskat/new/alle.pingus", "start": 16252224, "end": 16258654}, {"filename": "/data/levels/xskat/new/avaritia-cbrucher.pingus", "start": 16258654, "end": 16262418}, {"filename": "/data/levels/xskat/new/blue1-marcotte.pingus", "start": 16262418, "end": 16280074}, {"filename": "/data/levels/xskat/new/blue2-marcotte.pingus", "start": 16280074, "end": 16300953}, {"filename": "/data/levels/xskat/new/blue3-marcotte.pingus", "start": 16300953, "end": 16321523}, {"filename": "/data/levels/xskat/new/brick1-marcotte.pingus", "start": 16321523, "end": 16402817}, {"filename": "/data/levels/xskat/new/columns-luca.pingus", "start": 16402817, "end": 16410860}, {"filename": "/data/levels/xskat/new/dangerseasons-chekov.pingus", "start": 16410860, "end": 16419469}, {"filename": "/data/levels/xskat/new/demo/Achtung_Falle_15-Jonas_Bannert.pingus-demo", "start": 16419469, "end": 16419790}, {"filename": "/data/levels/xskat/new/demo/DangerSeasons-Chekov.pingus-demo", "start": 16419790, "end": 16420260}, {"filename": "/data/levels/xskat/new/demo/alle.pingus-demo", "start": 16420260, "end": 16421458}, {"filename": "/data/levels/xskat/new/demo/avaritia-cbrucher.pingus-demo", "start": 16421458, "end": 16422030}, {"filename": "/data/levels/xskat/new/demo/blue1-marcotte.pingus-demo", "start": 16422030, "end": 16422549}, {"filename": "/data/levels/xskat/new/demo/blue2-marcotte.pingus-demo", "start": 16422549, "end": 16423605}, {"filename": "/data/levels/xskat/new/demo/blue3-marcotte.pingus-demo", "start": 16423605, "end": 16425413}, {"filename": "/data/levels/xskat/new/demo/brick1-marcotte.pingus-demo", "start": 16425413, "end": 16428083}, {"filename": "/data/levels/xskat/new/demo/cave1-marcotte.pingus-demo", "start": 16428083, "end": 16428596}, {"filename": "/data/levels/xskat/new/demo/columns-luca.pingus-demo", "start": 16428596, "end": 16429851}, {"filename": "/data/levels/xskat/new/demo/crystal-10-rz.pingus-demo", "start": 16429851, "end": 16430570}, {"filename": "/data/levels/xskat/new/demo/crystalcave1-gunter.pingus-demo", "start": 16430570, "end": 16432184}, {"filename": "/data/levels/xskat/new/demo/crystalcave2-gunter.pingus-demo", "start": 16432184, "end": 16434301}, {"filename": "/data/levels/xskat/new/demo/crystalcave3-gunter.pingus-demo", "start": 16434301, "end": 16434611}, {"filename": "/data/levels/xskat/new/demo/crystalcave4-gunter.pingus-demo", "start": 16434611, "end": 16436560}, {"filename": "/data/levels/xskat/new/demo/desert1-janne.pingus-demo", "start": 16436560, "end": 16438069}, {"filename": "/data/levels/xskat/new/demo/desert5-tflavel-original.pingus-demo", "start": 16438069, "end": 16438591}, {"filename": "/data/levels/xskat/new/demo/dig1-marcotte.pingus-demo", "start": 16438591, "end": 16442956}, {"filename": "/data/levels/xskat/new/demo/dschungel.pingus-demo", "start": 16442956, "end": 16445285}, {"filename": "/data/levels/xskat/new/demo/egypt1-moredhel.pingus-demo", "start": 16445285, "end": 16446381}, {"filename": "/data/levels/xskat/new/demo/egypts1-judit.pingus-demo", "start": 16446381, "end": 16447260}, {"filename": "/data/levels/xskat/new/demo/forest1-chei.pingus-demo", "start": 16447260, "end": 16447723}, {"filename": "/data/levels/xskat/new/demo/forest2-chei.pingus-demo", "start": 16447723, "end": 16449019}, {"filename": "/data/levels/xskat/new/demo/gate1-janne.pingus-demo", "start": 16449019, "end": 16449163}, {"filename": "/data/levels/xskat/new/demo/hellmouth-11-rz.pingus-demo", "start": 16449163, "end": 16449569}, {"filename": "/data/levels/xskat/new/demo/hellmouth-23-rz+eriksoe.pingus-demo", "start": 16449569, "end": 16452495}, {"filename": "/data/levels/xskat/new/demo/hellmouth-24-rz.pingus-demo", "start": 16452495, "end": 16453332}, {"filename": "/data/levels/xskat/new/demo/if_only_i_can_fly_-_wayne_shelley.pingus-demo", "start": 16453332, "end": 16454075}, {"filename": "/data/levels/xskat/new/demo/job_switching.pingus-demo", "start": 16454075, "end": 16454693}, {"filename": "/data/levels/xskat/new/demo/jungle-13-rz+eriksoe.pingus-demo", "start": 16454693, "end": 16455158}, {"filename": "/data/levels/xskat/new/demo/mauern.pingus-demo", "start": 16455158, "end": 16455713}, {"filename": "/data/levels/xskat/new/demo/panic-cbrucher.pingus-demo", "start": 16455713, "end": 16456015}, {"filename": "/data/levels/xskat/new/demo/paratrooper-janne.pingus-demo", "start": 16456015, "end": 16457099}, {"filename": "/data/levels/xskat/new/demo/pingfrog-mips.pingus-demo", "start": 16457099, "end": 16459176}, {"filename": "/data/levels/xskat/new/demo/pingustemple2-pacho.pingus-demo", "start": 16459176, "end": 16460405}, {"filename": "/data/levels/xskat/new/demo/pingusworld1-pacho.pingus-demo", "start": 16460405, "end": 16463949}, {"filename": "/data/levels/xskat/new/demo/pingusworld2-pacho.pingus-demo", "start": 16463949, "end": 16465154}, {"filename": "/data/levels/xskat/new/demo/pingusworld3-pacho.pingus-demo", "start": 16465154, "end": 16466207}, {"filename": "/data/levels/xskat/new/demo/sand1-marcotte.pingus-demo", "start": 16466207, "end": 16467200}, {"filename": "/data/levels/xskat/new/demo/sand2-marcotte.pingus-demo", "start": 16467200, "end": 16468153}, {"filename": "/data/levels/xskat/new/demo/snow1-marcotte.pingus-demo", "start": 16468153, "end": 16468931}, {"filename": "/data/levels/xskat/new/demo/space-11-rz+eriksoe.pingus-demo", "start": 16468931, "end": 16469234}, {"filename": "/data/levels/xskat/new/demo/stairway1-valar.pingus-demo", "start": 16469234, "end": 16470131}, {"filename": "/data/levels/xskat/new/demo/stone-1-rz.pingus-demo", "start": 16470131, "end": 16470957}, {"filename": "/data/levels/xskat/new/demo/stone-6-rz+eriksoe.pingus-demo", "start": 16470957, "end": 16471321}, {"filename": "/data/levels/xskat/new/demo/stone1-marcotte.pingus-demo", "start": 16471321, "end": 16471839}, {"filename": "/data/levels/xskat/new/demo/stone2-marcotte.pingus-demo", "start": 16471839, "end": 16472192}, {"filename": "/data/levels/xskat/new/demo/stone3-marcotte.pingus-demo", "start": 16472192, "end": 16475491}, {"filename": "/data/levels/xskat/new/demo/superunknown1-valar.pingus-demo", "start": 16475491, "end": 16477340}, {"filename": "/data/levels/xskat/new/demo/teamwork-cbrucher.pingus-demo", "start": 16477340, "end": 16478120}, {"filename": "/data/levels/xskat/new/demo/theway-mips.pingus-demo", "start": 16478120, "end": 16479003}, {"filename": "/data/levels/xskat/new/demo/w1-judit.pingus-demo", "start": 16479003, "end": 16480344}, {"filename": "/data/levels/xskat/new/demo/winter1-chei.pingus-demo", "start": 16480344, "end": 16480804}, {"filename": "/data/levels/xskat/new/demo/winter2-chei.pingus-demo", "start": 16480804, "end": 16483485}, {"filename": "/data/levels/xskat/new/dig1-marcotte.pingus", "start": 16483485, "end": 16513548}, {"filename": "/data/levels/xskat/new/dschungel.pingus", "start": 16513548, "end": 16520411}, {"filename": "/data/levels/xskat/new/egypt1-moredhel.pingus", "start": 16520411, "end": 16530226}, {"filename": "/data/levels/xskat/new/forest1-chei.pingus", "start": 16530226, "end": 16550098}, {"filename": "/data/levels/xskat/new/forest2-chei.pingus", "start": 16550098, "end": 16569637}, {"filename": "/data/levels/xskat/new/gate1-janne.pingus", "start": 16569637, "end": 16573829}, {"filename": "/data/levels/xskat/new/hellmouth-11-rz.pingus", "start": 16573829, "end": 16585634}, {"filename": "/data/levels/xskat/new/if_only_i_can_fly_-_wayne_shelley.pingus", "start": 16585634, "end": 16596763}, {"filename": "/data/levels/xskat/new/job_switching.pingus", "start": 16596763, "end": 16604768}, {"filename": "/data/levels/xskat/new/mauern.pingus", "start": 16604768, "end": 16610410}, {"filename": "/data/levels/xskat/new/panic-cbrucher.pingus", "start": 16610410, "end": 16613862}, {"filename": "/data/levels/xskat/new/paratrooper-janne.pingus", "start": 16613862, "end": 16616450}, {"filename": "/data/levels/xskat/new/pingfrog-mips.pingus", "start": 16616450, "end": 16646528}, {"filename": "/data/levels/xskat/new/pingusworld1-pacho.pingus", "start": 16646528, "end": 16660203}, {"filename": "/data/levels/xskat/new/pingusworld2-pacho.pingus", "start": 16660203, "end": 16667111}, {"filename": "/data/levels/xskat/new/pingusworld3-pacho.pingus", "start": 16667111, "end": 16673391}, {"filename": "/data/levels/xskat/new/sand1-marcotte.pingus", "start": 16673391, "end": 16683004}, {"filename": "/data/levels/xskat/new/sand2-marcotte.pingus", "start": 16683004, "end": 16690305}, {"filename": "/data/levels/xskat/new/snow1-marcotte.pingus", "start": 16690305, "end": 16715421}, {"filename": "/data/levels/xskat/new/stairway1-valar.pingus", "start": 16715421, "end": 16722004}, {"filename": "/data/levels/xskat/new/stone-1-rz.pingus", "start": 16722004, "end": 16727059}, {"filename": "/data/levels/xskat/new/stone-6-rz+eriksoe.pingus", "start": 16727059, "end": 16742121}, {"filename": "/data/levels/xskat/new/stone1-marcotte.pingus", "start": 16742121, "end": 16750023}, {"filename": "/data/levels/xskat/new/stone2-marcotte.pingus", "start": 16750023, "end": 16759036}, {"filename": "/data/levels/xskat/new/stone3-marcotte.pingus", "start": 16759036, "end": 16771386}, {"filename": "/data/levels/xskat/new/superunknown1-valar.pingus", "start": 16771386, "end": 16786839}, {"filename": "/data/levels/xskat/new/teamwork-cbrucher.pingus", "start": 16786839, "end": 16797624}, {"filename": "/data/levels/xskat/new/theway-mips.pingus", "start": 16797624, "end": 16803457}, {"filename": "/data/levels/xskat/new/winter1-chei.pingus", "start": 16803457, "end": 16815298}, {"filename": "/data/levels/xskat/new/winter2-chei.pingus", "start": 16815298, "end": 16830249}, {"filename": "/data/levels/xskat/ok/blockers-timpany-tutorial.pingus", "start": 16830249, "end": 16836770}, {"filename": "/data/levels/xskat/ok/bomber-tutorial-grumbel.pingus", "start": 16836770, "end": 16842582}, {"filename": "/data/levels/xskat/ok/bridger-tutorial-grumbel.pingus", "start": 16842582, "end": 16848518}, {"filename": "/data/levels/xskat/ok/cages.pingus", "start": 16848518, "end": 16858266}, {"filename": "/data/levels/xskat/ok/candy-timpany-premoi.pingus", "start": 16858266, "end": 16867198}, {"filename": "/data/levels/xskat/ok/chouser02.pingus", "start": 16867198, "end": 16876311}, {"filename": "/data/levels/xskat/ok/climber-tutorial-lukis.pingus", "start": 16876311, "end": 16886868}, {"filename": "/data/levels/xskat/ok/demo/Dentist.pingus-demo", "start": 16886868, "end": 16888584}, {"filename": "/data/levels/xskat/ok/demo/Lev4.pingus-demo", "start": 16888584, "end": 16889296}, {"filename": "/data/levels/xskat/ok/demo/Stair.pingus-demo", "start": 16889296, "end": 16890603}, {"filename": "/data/levels/xskat/ok/demo/aliens1-phil.pingus-demo", "start": 16890603, "end": 16891283}, {"filename": "/data/levels/xskat/ok/demo/aliens2-phil.pingus-demo", "start": 16891283, "end": 16891803}, {"filename": "/data/levels/xskat/ok/demo/aliens4-phil.pingus-demo", "start": 16891803, "end": 16892956}, {"filename": "/data/levels/xskat/ok/demo/aliens5-phil.pingus-demo", "start": 16892956, "end": 16893845}, {"filename": "/data/levels/xskat/ok/demo/aliens6-phil.pingus-demo", "start": 16893845, "end": 16894999}, {"filename": "/data/levels/xskat/ok/demo/aliens7-phil.pingus-demo", "start": 16894999, "end": 16895040}, {"filename": "/data/levels/xskat/ok/demo/block-timpany.pingus-demo", "start": 16895040, "end": 16895603}, {"filename": "/data/levels/xskat/ok/demo/blockers-timpany-tutorial.pingus-demo", "start": 16895603, "end": 16896081}, {"filename": "/data/levels/xskat/ok/demo/bomber-tutorial-grumbel.pingus-demo", "start": 16896081, "end": 16896286}, {"filename": "/data/levels/xskat/ok/demo/bridger-tutorial-grumbel.pingus-demo", "start": 16896286, "end": 16896547}, {"filename": "/data/levels/xskat/ok/demo/cages.pingus-demo", "start": 16896547, "end": 16899198}, {"filename": "/data/levels/xskat/ok/demo/candy-timpany-premoi.pingus-demo", "start": 16899198, "end": 16899982}, {"filename": "/data/levels/xskat/ok/demo/chouser02.pingus-demo", "start": 16899982, "end": 16900602}, {"filename": "/data/levels/xskat/ok/demo/climber-tutorial-lukis.pingus-demo", "start": 16900602, "end": 16901277}, {"filename": "/data/levels/xskat/ok/demo/crystal2.pingus-demo", "start": 16901277, "end": 16901472}, {"filename": "/data/levels/xskat/ok/demo/crystal5.pingus-demo", "start": 16901472, "end": 16902347}, {"filename": "/data/levels/xskat/ok/demo/desert-crawl-timpany.pingus-demo", "start": 16902347, "end": 16903026}, {"filename": "/data/levels/xskat/ok/demo/desert1.pingus-demo", "start": 16903026, "end": 16903219}, {"filename": "/data/levels/xskat/ok/demo/desert2.pingus-demo", "start": 16903219, "end": 16904258}, {"filename": "/data/levels/xskat/ok/demo/desert3-tflavel.pingus-demo", "start": 16904258, "end": 16905040}, {"filename": "/data/levels/xskat/ok/demo/desert3.pingus-demo", "start": 16905040, "end": 16905389}, {"filename": "/data/levels/xskat/ok/demo/desert4.pingus-demo", "start": 16905389, "end": 16906258}, {"filename": "/data/levels/xskat/ok/demo/desert5-tflavel.pingus-demo", "start": 16906258, "end": 16906666}, {"filename": "/data/levels/xskat/ok/demo/desert5.pingus-demo", "start": 16906666, "end": 16907488}, {"filename": "/data/levels/xskat/ok/demo/desert6-grumbel.pingus-demo", "start": 16907488, "end": 16907848}, {"filename": "/data/levels/xskat/ok/demo/desert7-grumbel.pingus-demo", "start": 16907848, "end": 16908534}, {"filename": "/data/levels/xskat/ok/demo/desertwaste1-grumbel.pingus-demo", "start": 16908534, "end": 16908945}, {"filename": "/data/levels/xskat/ok/demo/digger-tutorial-grumbel.pingus-demo", "start": 16908945, "end": 16909048}, {"filename": "/data/levels/xskat/ok/demo/doors-grumbel.pingus-demo", "start": 16909048, "end": 16909818}, {"filename": "/data/levels/xskat/ok/demo/doors2-grumbel.pingus-demo", "start": 16909818, "end": 16912907}, {"filename": "/data/levels/xskat/ok/demo/foliage3.pingus-demo", "start": 16912907, "end": 16913877}, {"filename": "/data/levels/xskat/ok/demo/future1-jgoebbert.pingus-demo", "start": 16913877, "end": 16915132}, {"filename": "/data/levels/xskat/ok/demo/future2-jgoebbert.pingus-demo", "start": 16915132, "end": 16916333}, {"filename": "/data/levels/xskat/ok/demo/headbang.pingus-demo", "start": 16916333, "end": 16917006}, {"filename": "/data/levels/xskat/ok/demo/hellmouth01-grumbel.pingus-demo", "start": 16917006, "end": 16917739}, {"filename": "/data/levels/xskat/ok/demo/hellmouth02-grumbel.pingus-demo", "start": 16917739, "end": 16918419}, {"filename": "/data/levels/xskat/ok/demo/hellmouth03-grumbel.pingus-demo", "start": 16918419, "end": 16918990}, {"filename": "/data/levels/xskat/ok/demo/hellmouth04-grumbel.pingus-demo", "start": 16918990, "end": 16919297}, {"filename": "/data/levels/xskat/ok/demo/hellmouth05-grumbel.pingus-demo", "start": 16919297, "end": 16919920}, {"filename": "/data/levels/xskat/ok/demo/hellmouth06-grumbel.pingus-demo", "start": 16919920, "end": 16921657}, {"filename": "/data/levels/xskat/ok/demo/hellmouth07-grumbel.pingus-demo", "start": 16921657, "end": 16922438}, {"filename": "/data/levels/xskat/ok/demo/hellmouth08-grumbel.pingus-demo", "start": 16922438, "end": 16922998}, {"filename": "/data/levels/xskat/ok/demo/hellmouth09-grumbel.pingus-demo", "start": 16922998, "end": 16923629}, {"filename": "/data/levels/xskat/ok/demo/hellmouth10-grumbel.pingus-demo", "start": 16923629, "end": 16924143}, {"filename": "/data/levels/xskat/ok/demo/hellmouth12-grumbel.pingus-demo", "start": 16924143, "end": 16925127}, {"filename": "/data/levels/xskat/ok/demo/hellmouth13-grumbel.pingus-demo", "start": 16925127, "end": 16926393}, {"filename": "/data/levels/xskat/ok/demo/hellmouth14-grumbel.pingus-demo", "start": 16926393, "end": 16927547}, {"filename": "/data/levels/xskat/ok/demo/hellmouth15-grumbel.pingus-demo", "start": 16927547, "end": 16929300}, {"filename": "/data/levels/xskat/ok/demo/hellmouth17-grumbel.pingus-demo", "start": 16929300, "end": 16930183}, {"filename": "/data/levels/xskat/ok/demo/hellmouth18-grumbel.pingus-demo", "start": 16930183, "end": 16930862}, {"filename": "/data/levels/xskat/ok/demo/hellmouth19-grumbel.pingus-demo", "start": 16930862, "end": 16932246}, {"filename": "/data/levels/xskat/ok/demo/hellmouth20-grumbel.pingus-demo", "start": 16932246, "end": 16940351}, {"filename": "/data/levels/xskat/ok/demo/hellmouth21-grumbel.pingus-demo", "start": 16940351, "end": 16940914}, {"filename": "/data/levels/xskat/ok/demo/hellmouth22-grumbel.pingus-demo", "start": 16940914, "end": 16941166}, {"filename": "/data/levels/xskat/ok/demo/indiana-yingwan.pingus-demo", "start": 16941166, "end": 16944585}, {"filename": "/data/levels/xskat/ok/demo/industrial-plumber-timpany.pingus-demo", "start": 16944585, "end": 16945423}, {"filename": "/data/levels/xskat/ok/demo/industrial3-grumbel.pingus-demo", "start": 16945423, "end": 16945735}, {"filename": "/data/levels/xskat/ok/demo/industrial4-grumbel.pingus-demo", "start": 16945735, "end": 16948177}, {"filename": "/data/levels/xskat/ok/demo/intensiv-timpany.pingus-demo", "start": 16948177, "end": 16950639}, {"filename": "/data/levels/xskat/ok/demo/intersec.pingus-demo", "start": 16950639, "end": 16951671}, {"filename": "/data/levels/xskat/ok/demo/jewel.pingus-demo", "start": 16951671, "end": 16952759}, {"filename": "/data/levels/xskat/ok/demo/jungle-airline-timpany.pingus-demo", "start": 16952759, "end": 16954661}, {"filename": "/data/levels/xskat/ok/demo/jungle-crisscross-timpany.pingus-demo", "start": 16954661, "end": 16955074}, {"filename": "/data/levels/xskat/ok/demo/jungle1.pingus-demo", "start": 16955074, "end": 16955267}, {"filename": "/data/levels/xskat/ok/demo/level13.pingus-demo", "start": 16955267, "end": 16956351}, {"filename": "/data/levels/xskat/ok/demo/level9.pingus-demo", "start": 16956351, "end": 16957286}, {"filename": "/data/levels/xskat/ok/demo/lonely.pingus-demo", "start": 16957286, "end": 16957476}, {"filename": "/data/levels/xskat/ok/demo/longway.pingus-demo", "start": 16957476, "end": 16957869}, {"filename": "/data/levels/xskat/ok/demo/miner-tutorial-grumbel.pingus-demo", "start": 16957869, "end": 16958071}, {"filename": "/data/levels/xskat/ok/demo/mud3-grumbel.pingus-demo", "start": 16958071, "end": 16958680}, {"filename": "/data/levels/xskat/ok/demo/mud4-grumbel.pingus-demo", "start": 16958680, "end": 16959138}, {"filename": "/data/levels/xskat/ok/demo/pacman1-yingwan.pingus-demo", "start": 16959138, "end": 16960283}, {"filename": "/data/levels/xskat/ok/demo/pacman2-yingwan.pingus-demo", "start": 16960283, "end": 16961698}, {"filename": "/data/levels/xskat/ok/demo/pacman3-yingwan.pingus-demo", "start": 16961698, "end": 16964510}, {"filename": "/data/levels/xskat/ok/demo/parallel.pingus-demo", "start": 16964510, "end": 16965065}, {"filename": "/data/levels/xskat/ok/demo/partic2.pingus-demo", "start": 16965065, "end": 16965575}, {"filename": "/data/levels/xskat/ok/demo/particle.pingus-demo", "start": 16965575, "end": 16966134}, {"filename": "/data/levels/xskat/ok/demo/pyramid2-yingwan.pingus-demo", "start": 16966134, "end": 16967605}, {"filename": "/data/levels/xskat/ok/demo/real5.pingus-demo", "start": 16967605, "end": 16968063}, {"filename": "/data/levels/xskat/ok/demo/real6.pingus-demo", "start": 16968063, "end": 16968780}, {"filename": "/data/levels/xskat/ok/demo/rinse.pingus-demo", "start": 16968780, "end": 16969928}, {"filename": "/data/levels/xskat/ok/demo/rockhopping.pingus-demo", "start": 16969928, "end": 16970488}, {"filename": "/data/levels/xskat/ok/demo/sas.pingus-demo", "start": 16970488, "end": 16971537}, {"filename": "/data/levels/xskat/ok/demo/slidenride1-grumbel.pingus-demo", "start": 16971537, "end": 16972206}, {"filename": "/data/levels/xskat/ok/demo/snow1.pingus-demo", "start": 16972206, "end": 16974170}, {"filename": "/data/levels/xskat/ok/demo/sortie1.pingus-demo", "start": 16974170, "end": 16977079}, {"filename": "/data/levels/xskat/ok/demo/sortie4-grumbel.pingus-demo", "start": 16977079, "end": 16978236}, {"filename": "/data/levels/xskat/ok/demo/space-9-tom.pingus-demo", "start": 16978236, "end": 16978909}, {"filename": "/data/levels/xskat/ok/demo/space-loop-timpany.pingus-demo", "start": 16978909, "end": 16979541}, {"filename": "/data/levels/xskat/ok/demo/space-tom1.pingus-demo", "start": 16979541, "end": 16980158}, {"filename": "/data/levels/xskat/ok/demo/space2.pingus-demo", "start": 16980158, "end": 16982978}, {"filename": "/data/levels/xskat/ok/demo/stone-castle-timpany.pingus-demo", "start": 16982978, "end": 16983869}, {"filename": "/data/levels/xskat/ok/demo/stone5-grumbel.pingus-demo", "start": 16983869, "end": 16984224}, {"filename": "/data/levels/xskat/ok/demo/stone5-phlog.pingus-demo", "start": 16984224, "end": 16984841}, {"filename": "/data/levels/xskat/ok/demo/stone7-grumbel.pingus-demo", "start": 16984841, "end": 16986088}, {"filename": "/data/levels/xskat/ok/demo/stone9-grumbel.pingus-demo", "start": 16986088, "end": 16986442}, {"filename": "/data/levels/xskat/ok/demo/sweets-phil2.pingus-demo", "start": 16986442, "end": 16986585}, {"filename": "/data/levels/xskat/ok/demo/teleporter1-grumbel.pingus-demo", "start": 16986585, "end": 16987976}, {"filename": "/data/levels/xskat/ok/demo/teleporter2-grumbel.pingus-demo", "start": 16987976, "end": 16989508}, {"filename": "/data/levels/xskat/ok/demo/wland-timpany.pingus-demo", "start": 16989508, "end": 16989919}, {"filename": "/data/levels/xskat/ok/demo/xmas-blockblow-timpany.pingus-demo", "start": 16989919, "end": 16991086}, {"filename": "/data/levels/xskat/ok/demo/xmas-complex-timpany.pingus-demo", "start": 16991086, "end": 16991662}, {"filename": "/data/levels/xskat/ok/digger-tutorial-grumbel.pingus", "start": 16991662, "end": 17003335}, {"filename": "/data/levels/xskat/ok/doors-grumbel.pingus", "start": 17003335, "end": 17046302}, {"filename": "/data/levels/xskat/ok/doors2-grumbel.pingus", "start": 17046302, "end": 17086472}, {"filename": "/data/levels/xskat/ok/future1-jgoebbert.pingus", "start": 17086472, "end": 17137186}, {"filename": "/data/levels/xskat/ok/future2-jgoebbert.pingus", "start": 17137186, "end": 17224901}, {"filename": "/data/levels/xskat/ok/industrial-plumber-timpany.pingus", "start": 17224901, "end": 17234414}, {"filename": "/data/levels/xskat/ok/industrial3-grumbel.pingus", "start": 17234414, "end": 17239923}, {"filename": "/data/levels/xskat/ok/industrial4-grumbel.pingus", "start": 17239923, "end": 17248221}, {"filename": "/data/levels/xskat/ok/intensiv-timpany.pingus", "start": 17248221, "end": 17263117}, {"filename": "/data/levels/xskat/ok/lev4.pingus", "start": 17263117, "end": 17266981}, {"filename": "/data/levels/xskat/ok/level13.pingus", "start": 17266981, "end": 17295384}, {"filename": "/data/levels/xskat/ok/level9.pingus", "start": 17295384, "end": 17312735}, {"filename": "/data/levels/xskat/ok/miner-tutorial-grumbel.pingus", "start": 17312735, "end": 17320195}, {"filename": "/data/levels/xskat/ok/mud3-grumbel.pingus", "start": 17320195, "end": 17333794}, {"filename": "/data/levels/xskat/ok/mud4-grumbel.pingus", "start": 17333794, "end": 17341249}, {"filename": "/data/levels/xskat/ok/partic2.pingus", "start": 17341249, "end": 17346769}, {"filename": "/data/levels/xskat/ok/pyramid2-yingwan.pingus", "start": 17346769, "end": 17361539}, {"filename": "/data/levels/xskat/ok/slidenride1-grumbel.pingus", "start": 17361539, "end": 17372504}, {"filename": "/data/levels/xskat/ok/snow1.pingus", "start": 17372504, "end": 17395017}, {"filename": "/data/levels/xskat/ok/sortie4-grumbel.pingus", "start": 17395017, "end": 17410381}, {"filename": "/data/levels/xskat/ok/stair.pingus", "start": 17410381, "end": 17420099}, {"filename": "/data/levels/xskat/ok/stone-castle-timpany.pingus", "start": 17420099, "end": 17439814}, {"filename": "/data/levels/xskat/ok/stone5-grumbel.pingus", "start": 17439814, "end": 17447486}, {"filename": "/data/levels/xskat/ok/stone5-phlog.pingus", "start": 17447486, "end": 17453925}, {"filename": "/data/levels/xskat/ok/stone7-grumbel.pingus", "start": 17453925, "end": 17465618}, {"filename": "/data/levels/xskat/ok/stone9-grumbel.pingus", "start": 17465618, "end": 17474221}, {"filename": "/data/levels/xskat/ok/sweets-phil2.pingus", "start": 17474221, "end": 17481236}, {"filename": "/data/levels/xskat/ok/teleporter1-grumbel.pingus", "start": 17481236, "end": 17490873}, {"filename": "/data/levels/xskat/ok/teleporter2-grumbel.pingus", "start": 17490873, "end": 17510245}, {"filename": "/data/levels/xskat/ok/xmas-blockblow-timpany.pingus", "start": 17510245, "end": 17535988}, {"filename": "/data/levelsets/alien.levelset", "start": 17535988, "end": 17536627}, {"filename": "/data/levelsets/crystal.levelset", "start": 17536627, "end": 17537612}, {"filename": "/data/levelsets/desert.levelset", "start": 17537612, "end": 17538369}, {"filename": "/data/levelsets/factory.levelset", "start": 17538369, "end": 17539278}, {"filename": "/data/levelsets/halloween.levelset", "start": 17539278, "end": 17539856}, {"filename": "/data/levelsets/halloween2011.levelset", "start": 17539856, "end": 17540565}, {"filename": "/data/levelsets/hellmouth.levelset", "start": 17540565, "end": 17541857}, {"filename": "/data/levelsets/jungle.levelset", "start": 17541857, "end": 17542493}, {"filename": "/data/levelsets/mysteryisland.levelset", "start": 17542493, "end": 17543326}, {"filename": "/data/levelsets/pacman.levelset", "start": 17543326, "end": 17543648}, {"filename": "/data/levelsets/playable.levelset.JoshDye", "start": 17543648, "end": 17548073}, {"filename": "/data/levelsets/xmas2011.levelset", "start": 17548073, "end": 17548758}, {"filename": "/data/music/README", "start": 17548758, "end": 17549160}, {"filename": "/data/music/gd-cancn.it", "start": 17549160, "end": 17848215}, {"filename": "/data/music/gd-giirm.s3m", "start": 17848215, "end": 17920010}, {"filename": "/data/music/gd-ite.it", "start": 17920010, "end": 17961462}, {"filename": "/data/music/gd-matth.it", "start": 17961462, "end": 17969802}, {"filename": "/data/music/gd-myla.it", "start": 17969802, "end": 18093444}, {"filename": "/data/music/goin_march.it", "start": 18093444, "end": 18331839}, {"filename": "/data/music/pingus-1.it", "start": 18331839, "end": 18461338}, {"filename": "/data/music/pingus-2.it", "start": 18461338, "end": 18626671}, {"filename": "/data/music/pingus-3.it", "start": 18626671, "end": 18801597}, {"filename": "/data/music/pingus-4.it", "start": 18801597, "end": 18894365}, {"filename": "/data/music/pingus-5.it", "start": 18894365, "end": 19087631}, {"filename": "/data/music/pingus-6.it", "start": 19087631, "end": 19206439}, {"filename": "/data/music/pingus-7.it", "start": 19206439, "end": 19312611}, {"filename": "/data/music/pingus-8.it", "start": 19312611, "end": 19441755}, {"filename": "/data/music/pingus-9.it", "start": 19441755, "end": 19588316}, {"filename": "/data/music/rough_journey.it", "start": 19588316, "end": 19647908}, {"filename": "/data/music/sorcerer.it", "start": 19647908, "end": 19797490}, {"filename": "/data/music/success_1.it", "start": 19797490, "end": 20086688}, {"filename": "/data/music/success_2.it", "start": 20086688, "end": 20145094}, {"filename": "/data/music/the_big_march_in_space.it", "start": 20145094, "end": 20161036}, {"filename": "/data/po/ast.po", "start": 20161036, "end": 20221648}, {"filename": "/data/po/bg.po", "start": 20221648, "end": 20285622}, {"filename": "/data/po/cs.po", "start": 20285622, "end": 20377943}, {"filename": "/data/po/da.po", "start": 20377943, "end": 20455578}, {"filename": "/data/po/de.po", "start": 20455578, "end": 20567136}, {"filename": "/data/po/es.po", "start": 20567136, "end": 20648881}, {"filename": "/data/po/extract-levels.guile", "start": 20648881, "end": 20651860}, {"filename": "/data/po/extract-po.sh", "start": 20651860, "end": 20653614}, {"filename": "/data/po/fi.po", "start": 20653614, "end": 20729841}, {"filename": "/data/po/fr.po", "start": 20729841, "end": 20824291}, {"filename": "/data/po/hu.po", "start": 20824291, "end": 20906579}, {"filename": "/data/po/it.po", "start": 20906579, "end": 21023278}, {"filename": "/data/po/nb.po", "start": 21023278, "end": 21092695}, {"filename": "/data/po/nl.po", "start": 21092695, "end": 21182107}, {"filename": "/data/po/nn.po", "start": 21182107, "end": 21255311}, {"filename": "/data/po/pingus.pot", "start": 21255311, "end": 21315825}, {"filename": "/data/po/pl.po", "start": 21315825, "end": 21380892}, {"filename": "/data/po/pt.po", "start": 21380892, "end": 21461453}, {"filename": "/data/po/pt_BR.po", "start": 21461453, "end": 21543007}, {"filename": "/data/po/ru.po", "start": 21543007, "end": 21607758}, {"filename": "/data/po/sq.po", "start": 21607758, "end": 21669360}, {"filename": "/data/po/sr.po", "start": 21669360, "end": 21738348}, {"filename": "/data/po/sv.po", "start": 21738348, "end": 21817835}, {"filename": "/data/po/th.po", "start": 21817835, "end": 21881812}, {"filename": "/data/po/tr.po", "start": 21881812, "end": 21961021}, {"filename": "/data/po/uk.po", "start": 21961021, "end": 22026317}, {"filename": "/data/po/update-po.sh", "start": 22026317, "end": 22026574}, {"filename": "/data/po/zh_CN.po", "start": 22026574, "end": 22104045}, {"filename": "/data/po/zh_TW.po", "start": 22104045, "end": 22181727}, {"filename": "/data/prefabs/entrances/cloud.prefab", "start": 22181727, "end": 22182125}, {"filename": "/data/prefabs/entrances/desert.prefab", "start": 22182125, "end": 22182692}, {"filename": "/data/prefabs/entrances/eastern.prefab", "start": 22182692, "end": 22183090}, {"filename": "/data/prefabs/entrances/halloween.prefab", "start": 22183090, "end": 22183491}, {"filename": "/data/prefabs/entrances/industrial.prefab", "start": 22183491, "end": 22184056}, {"filename": "/data/prefabs/entrances/snow.prefab", "start": 22184056, "end": 22184545}, {"filename": "/data/prefabs/entrances/sortie.prefab", "start": 22184545, "end": 22185284}, {"filename": "/data/prefabs/entrances/space.prefab", "start": 22185284, "end": 22185681}, {"filename": "/data/prefabs/entrances/woodbox.prefab", "start": 22185681, "end": 22186168}, {"filename": "/data/prefabs/entrances/woodthing.prefab", "start": 22186168, "end": 22186738}, {"filename": "/data/prefabs/entrances/xmas.prefab", "start": 22186738, "end": 22187301}, {"filename": "/data/prefabs/liquids/slime.prefab", "start": 22187301, "end": 22187685}, {"filename": "/data/prefabs/liquids/water.prefab", "start": 22187685, "end": 22188071}, {"filename": "/data/prefabs/misc/snowman1.prefab", "start": 22188071, "end": 22190421}, {"filename": "/data/sounds/chink.wav", "start": 22190421, "end": 22192413, "audio": 1}, {"filename": "/data/sounds/digger.wav", "start": 22192413, "end": 22199609, "audio": 1}, {"filename": "/data/sounds/goodidea.wav", "start": 22199609, "end": 22226899, "audio": 1}, {"filename": "/data/sounds/letsgo.wav", "start": 22226899, "end": 22265855, "audio": 1}, {"filename": "/data/sounds/ohno.wav", "start": 22265855, "end": 22272995, "audio": 1}, {"filename": "/data/sounds/plop.wav", "start": 22272995, "end": 22277183, "audio": 1}, {"filename": "/data/sounds/plop2.wav", "start": 22277183, "end": 22278207, "audio": 1}, {"filename": "/data/sounds/splash.wav", "start": 22278207, "end": 22287383, "audio": 1}, {"filename": "/data/sounds/tick.wav", "start": 22287383, "end": 22288011, "audio": 1}, {"filename": "/data/sounds/ting.wav", "start": 22288011, "end": 22288637, "audio": 1}, {"filename": "/data/sounds/yipee.wav", "start": 22288637, "end": 22294365, "audio": 1}, {"filename": "/data/stories/tutorial_intro.story", "start": 22294365, "end": 22297256}, {"filename": "/data/stories/tutorial_outro.story", "start": 22297256, "end": 22298855}, {"filename": "/data/themes/playable.xml", "start": 22298855, "end": 22299621}, {"filename": "/data/themes/playable2.xml", "start": 22299621, "end": 22300340}, {"filename": "/data/worldmaps/pacman.old", "start": 22300340, "end": 22301375}, {"filename": "/data/worldmaps/tutorial.worldmap", "start": 22301375, "end": 22309391}, {"filename": "/data/worldmaps/tutorial.xml", "start": 22309391, "end": 22326898}, {"filename": "/data/worldmaps/volcano.worldmap", "start": 22326898, "end": 22333409}, {"filename": "/data/worldmaps/volcano.xml", "start": 22333409, "end": 22344018}], "remote_package_size": 22344018});

  })();

// end include: /tmp/tmpam84_755.js
// include: /tmp/tmp41k0nllw.js

    // All the pre-js content up to here must remain later on, we need to run
    // it.
    if (Module['$ww'] || (typeof ENVIRONMENT_IS_PTHREAD != 'undefined' && ENVIRONMENT_IS_PTHREAD)) Module['preRun'] = [];
    var necessaryPreJSTasks = Module['preRun'].slice();
  // end include: /tmp/tmp41k0nllw.js
// include: /tmp/tmphxja07ly.js

    if (!Module['preRun']) throw 'Module.preRun should exist because file support used it; did a pre-js delete it?';
    necessaryPreJSTasks.forEach((task) => {
      if (Module['preRun'].indexOf(task) < 0) throw 'All preRun tasks that exist before user pre-js code should remain after; did you replace Module or modify Module.preRun?';
    });
  // end include: /tmp/tmphxja07ly.js


// Sometimes an existing Module object exists with properties
// meant to overwrite the default module functionality. Here
// we collect those properties and reapply _after_ we configure
// the current environment's defaults to avoid having to be so
// defensive during initialization.
var moduleOverrides = Object.assign({}, Module);

var arguments_ = [];
var thisProgram = './this.program';
var quit_ = (status, toThrow) => {
  throw toThrow;
};

// `/` should be present at the end if `scriptDirectory` is not empty
var scriptDirectory = '';
function locateFile(path) {
  if (Module['locateFile']) {
    return Module['locateFile'](path, scriptDirectory);
  }
  return scriptDirectory + path;
}

// Hooks that are implemented differently in different runtime environments.
var readAsync, readBinary;

if (ENVIRONMENT_IS_SHELL) {

  if ((typeof process == 'object' && typeof require === 'function') || typeof window == 'object' || typeof importScripts == 'function') throw new Error('not compiled for this environment (did you build to HTML and try to run it not on the web, or set ENVIRONMENT to something - like node - and run it someplace else - like on the web?)');

} else

// Note that this includes Node.js workers when relevant (pthreads is enabled).
// Node.js workers are detected as a combination of ENVIRONMENT_IS_WORKER and
// ENVIRONMENT_IS_NODE.
if (ENVIRONMENT_IS_WEB || ENVIRONMENT_IS_WORKER) {
  if (ENVIRONMENT_IS_WORKER) { // Check worker, not web, since window could be polyfilled
    scriptDirectory = self.location.href;
  } else if (typeof document != 'undefined' && document.currentScript) { // web
    scriptDirectory = document.currentScript.src;
  }
  // blob urls look like blob:http://site.com/etc/etc and we cannot infer anything from them.
  // otherwise, slice off the final part of the url to find the script directory.
  // if scriptDirectory does not contain a slash, lastIndexOf will return -1,
  // and scriptDirectory will correctly be replaced with an empty string.
  // If scriptDirectory contains a query (starting with ?) or a fragment (starting with #),
  // they are removed because they could contain a slash.
  if (scriptDirectory.startsWith('blob:')) {
    scriptDirectory = '';
  } else {
    scriptDirectory = scriptDirectory.substr(0, scriptDirectory.replace(/[?#].*/, '').lastIndexOf('/')+1);
  }

  if (!(typeof window == 'object' || typeof importScripts == 'function')) throw new Error('not compiled for this environment (did you build to HTML and try to run it not on the web, or set ENVIRONMENT to something - like node - and run it someplace else - like on the web?)');

  {
// include: web_or_worker_shell_read.js
readAsync = (url) => {
    assert(!isFileURI(url), "readAsync does not work with file:// URLs");
    return fetch(url, { credentials: 'same-origin' })
      .then((response) => {
        if (response.ok) {
          return response.arrayBuffer();
        }
        return Promise.reject(new Error(response.status + ' : ' + response.url));
      })
  };
// end include: web_or_worker_shell_read.js
  }
} else
{
  throw new Error('environment detection error');
}

var out = Module['print'] || console.log.bind(console);
var err = Module['printErr'] || console.error.bind(console);

// Merge back in the overrides
Object.assign(Module, moduleOverrides);
// Free the object hierarchy contained in the overrides, this lets the GC
// reclaim data used.
moduleOverrides = null;
checkIncomingModuleAPI();

// Emit code to handle expected values on the Module object. This applies Module.x
// to the proper local x. This has two benefits: first, we only emit it if it is
// expected to arrive, and second, by using a local everywhere else that can be
// minified.

if (Module['arguments']) arguments_ = Module['arguments'];legacyModuleProp('arguments', 'arguments_');

if (Module['thisProgram']) thisProgram = Module['thisProgram'];legacyModuleProp('thisProgram', 'thisProgram');

if (Module['quit']) quit_ = Module['quit'];legacyModuleProp('quit', 'quit_');

// perform assertions in shell.js after we set up out() and err(), as otherwise if an assertion fails it cannot print the message
// Assertions on removed incoming Module JS APIs.
assert(typeof Module['memoryInitializerPrefixURL'] == 'undefined', 'Module.memoryInitializerPrefixURL option was removed, use Module.locateFile instead');
assert(typeof Module['pthreadMainPrefixURL'] == 'undefined', 'Module.pthreadMainPrefixURL option was removed, use Module.locateFile instead');
assert(typeof Module['cdInitializerPrefixURL'] == 'undefined', 'Module.cdInitializerPrefixURL option was removed, use Module.locateFile instead');
assert(typeof Module['filePackagePrefixURL'] == 'undefined', 'Module.filePackagePrefixURL option was removed, use Module.locateFile instead');
assert(typeof Module['read'] == 'undefined', 'Module.read option was removed');
assert(typeof Module['readAsync'] == 'undefined', 'Module.readAsync option was removed (modify readAsync in JS)');
assert(typeof Module['readBinary'] == 'undefined', 'Module.readBinary option was removed (modify readBinary in JS)');
assert(typeof Module['setWindowTitle'] == 'undefined', 'Module.setWindowTitle option was removed (modify emscripten_set_window_title in JS)');
assert(typeof Module['TOTAL_MEMORY'] == 'undefined', 'Module.TOTAL_MEMORY has been renamed Module.INITIAL_MEMORY');
legacyModuleProp('asm', 'wasmExports');
legacyModuleProp('readAsync', 'readAsync');
legacyModuleProp('readBinary', 'readBinary');
legacyModuleProp('setWindowTitle', 'setWindowTitle');

var PROXYFS = 'PROXYFS is no longer included by default; build with -lproxyfs.js';
var WORKERFS = 'WORKERFS is no longer included by default; build with -lworkerfs.js';
var FETCHFS = 'FETCHFS is no longer included by default; build with -lfetchfs.js';
var ICASEFS = 'ICASEFS is no longer included by default; build with -licasefs.js';
var JSFILEFS = 'JSFILEFS is no longer included by default; build with -ljsfilefs.js';
var OPFS = 'OPFS is no longer included by default; build with -lopfs.js';

var NODEFS = 'NODEFS is no longer included by default; build with -lnodefs.js';

assert(!ENVIRONMENT_IS_WORKER, 'worker environment detected but not enabled at build time.  Add `worker` to `-sENVIRONMENT` to enable.');

assert(!ENVIRONMENT_IS_NODE, 'node environment detected but not enabled at build time.  Add `node` to `-sENVIRONMENT` to enable.');

assert(!ENVIRONMENT_IS_SHELL, 'shell environment detected but not enabled at build time.  Add `shell` to `-sENVIRONMENT` to enable.');

// end include: shell.js

// include: preamble.js
// === Preamble library stuff ===

// Documentation for the public APIs defined in this file must be updated in:
//    site/source/docs/api_reference/preamble.js.rst
// A prebuilt local version of the documentation is available at:
//    site/build/text/docs/api_reference/preamble.js.txt
// You can also build docs locally as HTML or other formats in site/
// An online HTML version (which may be of a different version of Emscripten)
//    is up at http://kripken.github.io/emscripten-site/docs/api_reference/preamble.js.html

var wasmBinary; 
if (Module['wasmBinary']) wasmBinary = Module['wasmBinary'];legacyModuleProp('wasmBinary', 'wasmBinary');

if (typeof WebAssembly != 'object') {
  err('no native wasm support detected');
}

// include: base64Utils.js
// Converts a string of base64 into a byte array (Uint8Array).
function intArrayFromBase64(s) {

  var decoded = atob(s);
  var bytes = new Uint8Array(decoded.length);
  for (var i = 0 ; i < decoded.length ; ++i) {
    bytes[i] = decoded.charCodeAt(i);
  }
  return bytes;
}

// If filename is a base64 data URI, parses and returns data (Buffer on node,
// Uint8Array otherwise). If filename is not a base64 data URI, returns undefined.
function tryParseAsDataURI(filename) {
  if (!isDataURI(filename)) {
    return;
  }

  return intArrayFromBase64(filename.slice(dataURIPrefix.length));
}
// end include: base64Utils.js
// Wasm globals

var wasmMemory;

//========================================
// Runtime essentials
//========================================

// whether we are quitting the application. no code should run after this.
// set in exit() and abort()
var ABORT = false;

// set by exit() and abort().  Passed to 'onExit' handler.
// NOTE: This is also used as the process return code code in shell environments
// but only when noExitRuntime is false.
var EXITSTATUS;

// In STRICT mode, we only define assert() when ASSERTIONS is set.  i.e. we
// don't define it at all in release modes.  This matches the behaviour of
// MINIMAL_RUNTIME.
// TODO(sbc): Make this the default even without STRICT enabled.
/** @type {function(*, string=)} */
function assert(condition, text) {
  if (!condition) {
    abort('Assertion failed' + (text ? ': ' + text : ''));
  }
}

// We used to include malloc/free by default in the past. Show a helpful error in
// builds with assertions.

// Memory management

var HEAP,
/** @type {!Int8Array} */
  HEAP8,
/** @type {!Uint8Array} */
  HEAPU8,
/** @type {!Int16Array} */
  HEAP16,
/** @type {!Uint16Array} */
  HEAPU16,
/** @type {!Int32Array} */
  HEAP32,
/** @type {!Uint32Array} */
  HEAPU32,
/** @type {!Float32Array} */
  HEAPF32,
/** @type {!Float64Array} */
  HEAPF64;

// include: runtime_shared.js
function updateMemoryViews() {
  var b = wasmMemory.buffer;
  Module['HEAP8'] = HEAP8 = new Int8Array(b);
  Module['HEAP16'] = HEAP16 = new Int16Array(b);
  Module['HEAPU8'] = HEAPU8 = new Uint8Array(b);
  Module['HEAPU16'] = HEAPU16 = new Uint16Array(b);
  Module['HEAP32'] = HEAP32 = new Int32Array(b);
  Module['HEAPU32'] = HEAPU32 = new Uint32Array(b);
  Module['HEAPF32'] = HEAPF32 = new Float32Array(b);
  Module['HEAPF64'] = HEAPF64 = new Float64Array(b);
}
// end include: runtime_shared.js
assert(!Module['STACK_SIZE'], 'STACK_SIZE can no longer be set at runtime.  Use -sSTACK_SIZE at link time')

assert(typeof Int32Array != 'undefined' && typeof Float64Array !== 'undefined' && Int32Array.prototype.subarray != undefined && Int32Array.prototype.set != undefined,
       'JS engine does not provide full typed array support');

// If memory is defined in wasm, the user can't provide it, or set INITIAL_MEMORY
assert(!Module['wasmMemory'], 'Use of `wasmMemory` detected.  Use -sIMPORTED_MEMORY to define wasmMemory externally');
assert(!Module['INITIAL_MEMORY'], 'Detected runtime INITIAL_MEMORY setting.  Use -sIMPORTED_MEMORY to define wasmMemory dynamically');

// include: runtime_stack_check.js
// Initializes the stack cookie. Called at the startup of main and at the startup of each thread in pthreads mode.
function writeStackCookie() {
  var max = _emscripten_stack_get_end();
  assert((max & 3) == 0);
  // If the stack ends at address zero we write our cookies 4 bytes into the
  // stack.  This prevents interference with SAFE_HEAP and ASAN which also
  // monitor writes to address zero.
  if (max == 0) {
    max += 4;
  }
  // The stack grow downwards towards _emscripten_stack_get_end.
  // We write cookies to the final two words in the stack and detect if they are
  // ever overwritten.
  HEAPU32[((max)>>2)] = 0x02135467;
  HEAPU32[(((max)+(4))>>2)] = 0x89BACDFE;
  // Also test the global address 0 for integrity.
  HEAPU32[((0)>>2)] = 1668509029;
}

function checkStackCookie() {
  if (ABORT) return;
  var max = _emscripten_stack_get_end();
  // See writeStackCookie().
  if (max == 0) {
    max += 4;
  }
  var cookie1 = HEAPU32[((max)>>2)];
  var cookie2 = HEAPU32[(((max)+(4))>>2)];
  if (cookie1 != 0x02135467 || cookie2 != 0x89BACDFE) {
    abort(`Stack overflow! Stack cookie has been overwritten at ${ptrToString(max)}, expected hex dwords 0x89BACDFE and 0x2135467, but received ${ptrToString(cookie2)} ${ptrToString(cookie1)}`);
  }
  // Also test the global address 0 for integrity.
  if (HEAPU32[((0)>>2)] != 0x63736d65 /* 'emsc' */) {
    abort('Runtime error: The application has corrupted its heap memory area (address zero)!');
  }
}
// end include: runtime_stack_check.js
// include: runtime_assertions.js
// Endianness check
(function() {
  var h16 = new Int16Array(1);
  var h8 = new Int8Array(h16.buffer);
  h16[0] = 0x6373;
  if (h8[0] !== 0x73 || h8[1] !== 0x63) throw 'Runtime error: expected the system to be little-endian! (Run with -sSUPPORT_BIG_ENDIAN to bypass)';
})();

// end include: runtime_assertions.js
var __ATPRERUN__  = []; // functions called before the runtime is initialized
var __ATINIT__    = []; // functions called during startup
var __ATMAIN__    = []; // functions called when main() is to be run
var __ATEXIT__    = []; // functions called during shutdown
var __ATPOSTRUN__ = []; // functions called after the main() is called

var runtimeInitialized = false;

function preRun() {
  if (Module['preRun']) {
    if (typeof Module['preRun'] == 'function') Module['preRun'] = [Module['preRun']];
    while (Module['preRun'].length) {
      addOnPreRun(Module['preRun'].shift());
    }
  }
  callRuntimeCallbacks(__ATPRERUN__);
}

function initRuntime() {
  assert(!runtimeInitialized);
  runtimeInitialized = true;

  checkStackCookie();

  
if (!Module['noFSInit'] && !FS.init.initialized)
  FS.init();
FS.ignorePermissions = false;

TTY.init();
  callRuntimeCallbacks(__ATINIT__);
}

function preMain() {
  checkStackCookie();
  
  callRuntimeCallbacks(__ATMAIN__);
}

function postRun() {
  checkStackCookie();

  if (Module['postRun']) {
    if (typeof Module['postRun'] == 'function') Module['postRun'] = [Module['postRun']];
    while (Module['postRun'].length) {
      addOnPostRun(Module['postRun'].shift());
    }
  }

  callRuntimeCallbacks(__ATPOSTRUN__);
}

function addOnPreRun(cb) {
  __ATPRERUN__.unshift(cb);
}

function addOnInit(cb) {
  __ATINIT__.unshift(cb);
}

function addOnPreMain(cb) {
  __ATMAIN__.unshift(cb);
}

function addOnExit(cb) {
}

function addOnPostRun(cb) {
  __ATPOSTRUN__.unshift(cb);
}

// include: runtime_math.js
// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Math/imul

// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Math/fround

// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Math/clz32

// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Math/trunc

assert(Math.imul, 'This browser does not support Math.imul(), build with LEGACY_VM_SUPPORT or POLYFILL_OLD_MATH_FUNCTIONS to add in a polyfill');
assert(Math.fround, 'This browser does not support Math.fround(), build with LEGACY_VM_SUPPORT or POLYFILL_OLD_MATH_FUNCTIONS to add in a polyfill');
assert(Math.clz32, 'This browser does not support Math.clz32(), build with LEGACY_VM_SUPPORT or POLYFILL_OLD_MATH_FUNCTIONS to add in a polyfill');
assert(Math.trunc, 'This browser does not support Math.trunc(), build with LEGACY_VM_SUPPORT or POLYFILL_OLD_MATH_FUNCTIONS to add in a polyfill');
// end include: runtime_math.js
// A counter of dependencies for calling run(). If we need to
// do asynchronous work before running, increment this and
// decrement it. Incrementing must happen in a place like
// Module.preRun (used by emcc to add file preloading).
// Note that you can add dependencies in preRun, even though
// it happens right before run - run will be postponed until
// the dependencies are met.
var runDependencies = 0;
var runDependencyWatcher = null;
var dependenciesFulfilled = null; // overridden to take different actions when all run dependencies are fulfilled
var runDependencyTracking = {};

function getUniqueRunDependency(id) {
  var orig = id;
  while (1) {
    if (!runDependencyTracking[id]) return id;
    id = orig + Math.random();
  }
}

function addRunDependency(id) {
  runDependencies++;

  Module['monitorRunDependencies']?.(runDependencies);

  if (id) {
    assert(!runDependencyTracking[id]);
    runDependencyTracking[id] = 1;
    if (runDependencyWatcher === null && typeof setInterval != 'undefined') {
      // Check for missing dependencies every few seconds
      runDependencyWatcher = setInterval(() => {
        if (ABORT) {
          clearInterval(runDependencyWatcher);
          runDependencyWatcher = null;
          return;
        }
        var shown = false;
        for (var dep in runDependencyTracking) {
          if (!shown) {
            shown = true;
            err('still waiting on run dependencies:');
          }
          err(`dependency: ${dep}`);
        }
        if (shown) {
          err('(end of list)');
        }
      }, 10000);
    }
  } else {
    err('warning: run dependency added without ID');
  }
}

function removeRunDependency(id) {
  runDependencies--;

  Module['monitorRunDependencies']?.(runDependencies);

  if (id) {
    assert(runDependencyTracking[id]);
    delete runDependencyTracking[id];
  } else {
    err('warning: run dependency removed without ID');
  }
  if (runDependencies == 0) {
    if (runDependencyWatcher !== null) {
      clearInterval(runDependencyWatcher);
      runDependencyWatcher = null;
    }
    if (dependenciesFulfilled) {
      var callback = dependenciesFulfilled;
      dependenciesFulfilled = null;
      callback(); // can add another dependenciesFulfilled
    }
  }
}

/** @param {string|number=} what */
function abort(what) {
  Module['onAbort']?.(what);

  what = 'Aborted(' + what + ')';
  // TODO(sbc): Should we remove printing and leave it up to whoever
  // catches the exception?
  err(what);

  ABORT = true;
  EXITSTATUS = 1;

  if (what.indexOf('RuntimeError: unreachable') >= 0) {
    what += '. "unreachable" may be due to ASYNCIFY_STACK_SIZE not being large enough (try increasing it)';
  }

  // Use a wasm runtime error, because a JS error might be seen as a foreign
  // exception, which means we'd run destructors on it. We need the error to
  // simply make the program stop.
  // FIXME This approach does not work in Wasm EH because it currently does not assume
  // all RuntimeErrors are from traps; it decides whether a RuntimeError is from
  // a trap or not based on a hidden field within the object. So at the moment
  // we don't have a way of throwing a wasm trap from JS. TODO Make a JS API that
  // allows this in the wasm spec.

  // Suppress closure compiler warning here. Closure compiler's builtin extern
  // definition for WebAssembly.RuntimeError claims it takes no arguments even
  // though it can.
  // TODO(https://github.com/google/closure-compiler/pull/3913): Remove if/when upstream closure gets fixed.
  /** @suppress {checkTypes} */
  var e = new WebAssembly.RuntimeError(what);

  // Throw the error whether or not MODULARIZE is set because abort is used
  // in code paths apart from instantiation where an exception is expected
  // to be thrown when abort is called.
  throw e;
}

// include: memoryprofiler.js
// end include: memoryprofiler.js
// include: URIUtils.js
// Prefix of data URIs emitted by SINGLE_FILE and related options.
var dataURIPrefix = 'data:application/octet-stream;base64,';

/**
 * Indicates whether filename is a base64 data URI.
 * @noinline
 */
var isDataURI = (filename) => filename.startsWith(dataURIPrefix);

/**
 * Indicates whether filename is delivered via file protocol (as opposed to http/https)
 * @noinline
 */
var isFileURI = (filename) => filename.startsWith('file://');
// end include: URIUtils.js
function createExportWrapper(name, nargs) {
  return (...args) => {
    assert(runtimeInitialized, `native function \`${name}\` called before runtime initialization`);
    var f = wasmExports[name];
    assert(f, `exported native function \`${name}\` not found`);
    // Only assert for too many arguments. Too few can be valid since the missing arguments will be zero filled.
    assert(args.length <= nargs, `native function \`${name}\` called with ${args.length} args but expects ${nargs}`);
    return f(...args);
  };
}

// include: runtime_exceptions.js
// Base Emscripten EH error class
class EmscriptenEH extends Error {}

class EmscriptenSjLj extends EmscriptenEH {}

class CppException extends EmscriptenEH {
  constructor(excPtr) {
    super(excPtr);
    this.excPtr = excPtr;
    const excInfo = getExceptionMessage(excPtr);
    this.name = excInfo[0];
    this.message = excInfo[1];
  }
}
// end include: runtime_exceptions.js
function findWasmBinary() {
    var f = 'index.wasm';
    if (!isDataURI(f)) {
      return locateFile(f);
    }
    return f;
}

var wasmBinaryFile;

function getBinarySync(file) {
  if (file == wasmBinaryFile && wasmBinary) {
    return new Uint8Array(wasmBinary);
  }
  if (readBinary) {
    return readBinary(file);
  }
  throw 'both async and sync fetching of the wasm failed';
}

function getBinaryPromise(binaryFile) {
  // If we don't have the binary yet, load it asynchronously using readAsync.
  if (!wasmBinary
      ) {
    // Fetch the binary using readAsync
    return readAsync(binaryFile).then(
      (response) => new Uint8Array(/** @type{!ArrayBuffer} */(response)),
      // Fall back to getBinarySync if readAsync fails
      () => getBinarySync(binaryFile)
    );
  }

  // Otherwise, getBinarySync should be able to get it synchronously
  return Promise.resolve().then(() => getBinarySync(binaryFile));
}

function instantiateArrayBuffer(binaryFile, imports, receiver) {
  return getBinaryPromise(binaryFile).then((binary) => {
    return WebAssembly.instantiate(binary, imports);
  }).then(receiver, (reason) => {
    err(`failed to asynchronously prepare wasm: ${reason}`);

    // Warn on some common problems.
    if (isFileURI(wasmBinaryFile)) {
      err(`warning: Loading from a file URI (${wasmBinaryFile}) is not supported in most browsers. See https://emscripten.org/docs/getting_started/FAQ.html#how-do-i-run-a-local-webserver-for-testing-why-does-my-program-stall-in-downloading-or-preparing`);
    }
    abort(reason);
  });
}

function instantiateAsync(binary, binaryFile, imports, callback) {
  if (!binary &&
      typeof WebAssembly.instantiateStreaming == 'function' &&
      !isDataURI(binaryFile) &&
      typeof fetch == 'function') {
    return fetch(binaryFile, { credentials: 'same-origin' }).then((response) => {
      // Suppress closure warning here since the upstream definition for
      // instantiateStreaming only allows Promise<Repsponse> rather than
      // an actual Response.
      // TODO(https://github.com/google/closure-compiler/pull/3913): Remove if/when upstream closure is fixed.
      /** @suppress {checkTypes} */
      var result = WebAssembly.instantiateStreaming(response, imports);

      return result.then(
        callback,
        function(reason) {
          // We expect the most common failure cause to be a bad MIME type for the binary,
          // in which case falling back to ArrayBuffer instantiation should work.
          err(`wasm streaming compile failed: ${reason}`);
          err('falling back to ArrayBuffer instantiation');
          return instantiateArrayBuffer(binaryFile, imports, callback);
        });
    });
  }
  return instantiateArrayBuffer(binaryFile, imports, callback);
}

function getWasmImports() {
  // instrumenting imports is used in asyncify in two ways: to add assertions
  // that check for proper import use, and for ASYNCIFY=2 we use them to set up
  // the Promise API on the import side.
  Asyncify.instrumentWasmImports(wasmImports);
  // prepare imports
  return {
    'env': wasmImports,
    'wasi_snapshot_preview1': wasmImports,
  }
}

// Create the wasm instance.
// Receives the wasm imports, returns the exports.
function createWasm() {
  var info = getWasmImports();
  // Load the wasm module and create an instance of using native support in the JS engine.
  // handle a generated wasm instance, receiving its exports and
  // performing other necessary setup
  /** @param {WebAssembly.Module=} module*/
  function receiveInstance(instance, module) {
    wasmExports = instance.exports;

    wasmExports = Asyncify.instrumentWasmExports(wasmExports);

    

    wasmMemory = wasmExports['memory'];
    
    assert(wasmMemory, 'memory not found in wasm exports');
    updateMemoryViews();

    wasmTable = wasmExports['__indirect_function_table'];
    
    assert(wasmTable, 'table not found in wasm exports');

    addOnInit(wasmExports['__wasm_call_ctors']);

    removeRunDependency('wasm-instantiate');
    return wasmExports;
  }
  // wait for the pthread pool (if any)
  addRunDependency('wasm-instantiate');

  // Prefer streaming instantiation if available.
  // Async compilation can be confusing when an error on the page overwrites Module
  // (for example, if the order of elements is wrong, and the one defining Module is
  // later), so we save Module and check it later.
  var trueModule = Module;
  function receiveInstantiationResult(result) {
    // 'result' is a ResultObject object which has both the module and instance.
    // receiveInstance() will swap in the exports (to Module.asm) so they can be called
    assert(Module === trueModule, 'the Module object should not be replaced during async compilation - perhaps the order of HTML elements is wrong?');
    trueModule = null;
    // TODO: Due to Closure regression https://github.com/google/closure-compiler/issues/3193, the above line no longer optimizes out down to the following line.
    // When the regression is fixed, can restore the above PTHREADS-enabled path.
    receiveInstance(result['instance']);
  }

  // User shell pages can write their own Module.instantiateWasm = function(imports, successCallback) callback
  // to manually instantiate the Wasm module themselves. This allows pages to
  // run the instantiation parallel to any other async startup actions they are
  // performing.
  // Also pthreads and wasm workers initialize the wasm instance through this
  // path.
  if (Module['instantiateWasm']) {
    try {
      return Module['instantiateWasm'](info, receiveInstance);
    } catch(e) {
      err(`Module.instantiateWasm callback failed with error: ${e}`);
        return false;
    }
  }

  if (!wasmBinaryFile) wasmBinaryFile = findWasmBinary();

  instantiateAsync(wasmBinary, wasmBinaryFile, info, receiveInstantiationResult);
  return {}; // no exports yet; we'll fill them in later
}

// Globals used by JS i64 conversions (see makeSetValue)
var tempDouble;
var tempI64;

// include: runtime_debug.js
function legacyModuleProp(prop, newName, incoming=true) {
  if (!Object.getOwnPropertyDescriptor(Module, prop)) {
    Object.defineProperty(Module, prop, {
      configurable: true,
      get() {
        let extra = incoming ? ' (the initial value can be provided on Module, but after startup the value is only looked for on a local variable of that name)' : '';
        abort(`\`Module.${prop}\` has been replaced by \`${newName}\`` + extra);

      }
    });
  }
}

function ignoredModuleProp(prop) {
  if (Object.getOwnPropertyDescriptor(Module, prop)) {
    abort(`\`Module.${prop}\` was supplied but \`${prop}\` not included in INCOMING_MODULE_JS_API`);
  }
}

// forcing the filesystem exports a few things by default
function isExportedByForceFilesystem(name) {
  return name === 'FS_createPath' ||
         name === 'FS_createDataFile' ||
         name === 'FS_createPreloadedFile' ||
         name === 'FS_unlink' ||
         name === 'addRunDependency' ||
         // The old FS has some functionality that WasmFS lacks.
         name === 'FS_createLazyFile' ||
         name === 'FS_createDevice' ||
         name === 'removeRunDependency';
}

function missingGlobal(sym, msg) {
  if (typeof globalThis != 'undefined') {
    Object.defineProperty(globalThis, sym, {
      configurable: true,
      get() {
        warnOnce(`\`${sym}\` is not longer defined by emscripten. ${msg}`);
        return undefined;
      }
    });
  }
}

missingGlobal('buffer', 'Please use HEAP8.buffer or wasmMemory.buffer');
missingGlobal('asm', 'Please use wasmExports instead');

function missingLibrarySymbol(sym) {
  if (typeof globalThis != 'undefined' && !Object.getOwnPropertyDescriptor(globalThis, sym)) {
    Object.defineProperty(globalThis, sym, {
      configurable: true,
      get() {
        // Can't `abort()` here because it would break code that does runtime
        // checks.  e.g. `if (typeof SDL === 'undefined')`.
        var msg = `\`${sym}\` is a library symbol and not included by default; add it to your library.js __deps or to DEFAULT_LIBRARY_FUNCS_TO_INCLUDE on the command line`;
        // DEFAULT_LIBRARY_FUNCS_TO_INCLUDE requires the name as it appears in
        // library.js, which means $name for a JS name with no prefix, or name
        // for a JS name like _name.
        var librarySymbol = sym;
        if (!librarySymbol.startsWith('_')) {
          librarySymbol = '$' + sym;
        }
        msg += ` (e.g. -sDEFAULT_LIBRARY_FUNCS_TO_INCLUDE='${librarySymbol}')`;
        if (isExportedByForceFilesystem(sym)) {
          msg += '. Alternatively, forcing filesystem support (-sFORCE_FILESYSTEM) can export this for you';
        }
        warnOnce(msg);
        return undefined;
      }
    });
  }
  // Any symbol that is not included from the JS library is also (by definition)
  // not exported on the Module object.
  unexportedRuntimeSymbol(sym);
}

function unexportedRuntimeSymbol(sym) {
  if (!Object.getOwnPropertyDescriptor(Module, sym)) {
    Object.defineProperty(Module, sym, {
      configurable: true,
      get() {
        var msg = `'${sym}' was not exported. add it to EXPORTED_RUNTIME_METHODS (see the Emscripten FAQ)`;
        if (isExportedByForceFilesystem(sym)) {
          msg += '. Alternatively, forcing filesystem support (-sFORCE_FILESYSTEM) can export this for you';
        }
        abort(msg);
      }
    });
  }
}

// Used by XXXXX_DEBUG settings to output debug messages.
function dbg(...args) {
  // TODO(sbc): Make this configurable somehow.  Its not always convenient for
  // logging to show up as warnings.
  console.warn(...args);
}
// end include: runtime_debug.js
// === Body ===

var ASM_CONSTS = {
  279024: () => { return document.hidden ? 1 : 0; },  
 279060: () => { if (typeof window.pingusSaveNow === 'function') window.pingusSaveNow(); },  
 279136: () => { if (typeof window.pingusMarkReady === 'function') window.pingusMarkReady(); },  
 279216: ($0) => { var s = SDL.surfaces[$0]; return s && typeof s.alpha === 'number' ? s.alpha : 255; }
};

// end include: preamble.js


  /** @constructor */
  function ExitStatus(status) {
      this.name = 'ExitStatus';
      this.message = `Program terminated with exit(${status})`;
      this.status = status;
    }

  var callRuntimeCallbacks = (callbacks) => {
      while (callbacks.length > 0) {
        // Pass the module as the first argument.
        callbacks.shift()(Module);
      }
    };

  
    /**
     * @param {number} ptr
     * @param {string} type
     */
  function getValue(ptr, type = 'i8') {
    if (type.endsWith('*')) type = '*';
    switch (type) {
      case 'i1': return HEAP8[ptr];
      case 'i8': return HEAP8[ptr];
      case 'i16': return HEAP16[((ptr)>>1)];
      case 'i32': return HEAP32[((ptr)>>2)];
      case 'i64': abort('to do getValue(i64) use WASM_BIGINT');
      case 'float': return HEAPF32[((ptr)>>2)];
      case 'double': return HEAPF64[((ptr)>>3)];
      case '*': return HEAPU32[((ptr)>>2)];
      default: abort(`invalid type for getValue: ${type}`);
    }
  }

  var noExitRuntime = Module['noExitRuntime'] || true;

  var ptrToString = (ptr) => {
      assert(typeof ptr === 'number');
      // With CAN_ADDRESS_2GB or MEMORY64, pointers are already unsigned.
      ptr >>>= 0;
      return '0x' + ptr.toString(16).padStart(8, '0');
    };

  
    /**
     * @param {number} ptr
     * @param {number} value
     * @param {string} type
     */
  function setValue(ptr, value, type = 'i8') {
    if (type.endsWith('*')) type = '*';
    switch (type) {
      case 'i1': HEAP8[ptr] = value; break;
      case 'i8': HEAP8[ptr] = value; break;
      case 'i16': HEAP16[((ptr)>>1)] = value; break;
      case 'i32': HEAP32[((ptr)>>2)] = value; break;
      case 'i64': abort('to do setValue(i64) use WASM_BIGINT');
      case 'float': HEAPF32[((ptr)>>2)] = value; break;
      case 'double': HEAPF64[((ptr)>>3)] = value; break;
      case '*': HEAPU32[((ptr)>>2)] = value; break;
      default: abort(`invalid type for setValue: ${type}`);
    }
  }

  var stackRestore = (val) => __emscripten_stack_restore(val);

  var stackSave = () => _emscripten_stack_get_current();

  var warnOnce = (text) => {
      warnOnce.shown ||= {};
      if (!warnOnce.shown[text]) {
        warnOnce.shown[text] = 1;
        err(text);
      }
    };

  var PATH = {
  isAbs:(path) => path.charAt(0) === '/',
  splitPath:(filename) => {
        var splitPathRe = /^(\/?|)([\s\S]*?)((?:\.{1,2}|[^\/]+?|)(\.[^.\/]*|))(?:[\/]*)$/;
        return splitPathRe.exec(filename).slice(1);
      },
  normalizeArray:(parts, allowAboveRoot) => {
        // if the path tries to go above the root, `up` ends up > 0
        var up = 0;
        for (var i = parts.length - 1; i >= 0; i--) {
          var last = parts[i];
          if (last === '.') {
            parts.splice(i, 1);
          } else if (last === '..') {
            parts.splice(i, 1);
            up++;
          } else if (up) {
            parts.splice(i, 1);
            up--;
          }
        }
        // if the path is allowed to go above the root, restore leading ..s
        if (allowAboveRoot) {
          for (; up; up--) {
            parts.unshift('..');
          }
        }
        return parts;
      },
  normalize:(path) => {
        var isAbsolute = PATH.isAbs(path),
            trailingSlash = path.substr(-1) === '/';
        // Normalize the path
        path = PATH.normalizeArray(path.split('/').filter((p) => !!p), !isAbsolute).join('/');
        if (!path && !isAbsolute) {
          path = '.';
        }
        if (path && trailingSlash) {
          path += '/';
        }
        return (isAbsolute ? '/' : '') + path;
      },
  dirname:(path) => {
        var result = PATH.splitPath(path),
            root = result[0],
            dir = result[1];
        if (!root && !dir) {
          // No dirname whatsoever
          return '.';
        }
        if (dir) {
          // It has a dirname, strip trailing slash
          dir = dir.substr(0, dir.length - 1);
        }
        return root + dir;
      },
  basename:(path) => {
        // EMSCRIPTEN return '/'' for '/', not an empty string
        if (path === '/') return '/';
        path = PATH.normalize(path);
        path = path.replace(/\/$/, "");
        var lastSlash = path.lastIndexOf('/');
        if (lastSlash === -1) return path;
        return path.substr(lastSlash+1);
      },
  join:(...paths) => PATH.normalize(paths.join('/')),
  join2:(l, r) => PATH.normalize(l + '/' + r),
  };
  
  var _emscripten_set_main_loop_timing = (mode, value) => {
      Browser.mainLoop.timingMode = mode;
      Browser.mainLoop.timingValue = value;
  
      if (!Browser.mainLoop.func) {
        err('emscripten_set_main_loop_timing: Cannot set timing mode for main loop since a main loop does not exist! Call emscripten_set_main_loop first to set one up.');
        return 1; // Return non-zero on failure, can't set timing mode when there is no main loop.
      }
  
      if (!Browser.mainLoop.running) {
        
        Browser.mainLoop.running = true;
      }
      if (mode == 0) {
        Browser.mainLoop.scheduler = function Browser_mainLoop_scheduler_setTimeout() {
          var timeUntilNextTick = Math.max(0, Browser.mainLoop.tickStartTime + value - _emscripten_get_now())|0;
          setTimeout(Browser.mainLoop.runner, timeUntilNextTick); // doing this each time means that on exception, we stop
        };
        Browser.mainLoop.method = 'timeout';
      } else if (mode == 1) {
        Browser.mainLoop.scheduler = function Browser_mainLoop_scheduler_rAF() {
          Browser.requestAnimationFrame(Browser.mainLoop.runner);
        };
        Browser.mainLoop.method = 'rAF';
      } else if (mode == 2) {
        if (typeof Browser.setImmediate == 'undefined') {
          if (typeof setImmediate == 'undefined') {
            // Emulate setImmediate. (note: not a complete polyfill, we don't emulate clearImmediate() to keep code size to minimum, since not needed)
            var setImmediates = [];
            var emscriptenMainLoopMessageId = 'setimmediate';
            /** @param {Event} event */
            var Browser_setImmediate_messageHandler = (event) => {
              // When called in current thread or Worker, the main loop ID is structured slightly different to accommodate for --proxy-to-worker runtime listening to Worker events,
              // so check for both cases.
              if (event.data === emscriptenMainLoopMessageId || event.data.target === emscriptenMainLoopMessageId) {
                event.stopPropagation();
                setImmediates.shift()();
              }
            };
            addEventListener("message", Browser_setImmediate_messageHandler, true);
            Browser.setImmediate = /** @type{function(function(): ?, ...?): number} */(function Browser_emulated_setImmediate(func) {
              setImmediates.push(func);
              if (ENVIRONMENT_IS_WORKER) {
                Module['setImmediates'] ??= [];
                Module['setImmediates'].push(func);
                postMessage({target: emscriptenMainLoopMessageId}); // In --proxy-to-worker, route the message via proxyClient.js
              } else postMessage(emscriptenMainLoopMessageId, "*"); // On the main thread, can just send the message to itself.
            });
          } else {
            Browser.setImmediate = setImmediate;
          }
        }
        Browser.mainLoop.scheduler = function Browser_mainLoop_scheduler_setImmediate() {
          Browser.setImmediate(Browser.mainLoop.runner);
        };
        Browser.mainLoop.method = 'immediate';
      }
      return 0;
    };
  
  var _emscripten_get_now;
      // Modern environment where performance.now() is supported:
      // N.B. a shorter form "_emscripten_get_now = performance.now;" is
      // unfortunately not allowed even in current browsers (e.g. FF Nightly 75).
      _emscripten_get_now = () => performance.now();
  ;
  
  
    /**
     * @param {number=} arg
     * @param {boolean=} noSetTiming
     */
  var setMainLoop = (browserIterationFunc, fps, simulateInfiniteLoop, arg, noSetTiming) => {
      assert(!Browser.mainLoop.func, 'emscripten_set_main_loop: there can only be one main loop function at once: call emscripten_cancel_main_loop to cancel the previous one before setting a new one with different parameters.');
      Browser.mainLoop.func = browserIterationFunc;
      Browser.mainLoop.arg = arg;
  
      // Closure compiler bug(?): Closure does not see that the assignment
      //   var thisMainLoopId = Browser.mainLoop.currentlyRunningMainloop
      // is a value copy of a number (even with the JSDoc @type annotation)
      // but optimizeis the code as if the assignment was a reference assignment,
      // which results in Browser.mainLoop.pause() not working. Hence use a
      // workaround to make Closure believe this is a value copy that should occur:
      // (TODO: Minimize this down to a small test case and report - was unable
      // to reproduce in a small written test case)
      /** @type{number} */
      var thisMainLoopId = (() => Browser.mainLoop.currentlyRunningMainloop)();
      function checkIsRunning() {
        if (thisMainLoopId < Browser.mainLoop.currentlyRunningMainloop) {
          
          return false;
        }
        return true;
      }
  
      // We create the loop runner here but it is not actually running until
      // _emscripten_set_main_loop_timing is called (which might happen a
      // later time).  This member signifies that the current runner has not
      // yet been started so that we can call runtimeKeepalivePush when it
      // gets it timing set for the first time.
      Browser.mainLoop.running = false;
      Browser.mainLoop.runner = function Browser_mainLoop_runner() {
        if (ABORT) return;
        if (Browser.mainLoop.queue.length > 0) {
          var start = Date.now();
          var blocker = Browser.mainLoop.queue.shift();
          blocker.func(blocker.arg);
          if (Browser.mainLoop.remainingBlockers) {
            var remaining = Browser.mainLoop.remainingBlockers;
            var next = remaining%1 == 0 ? remaining-1 : Math.floor(remaining);
            if (blocker.counted) {
              Browser.mainLoop.remainingBlockers = next;
            } else {
              // not counted, but move the progress along a tiny bit
              next = next + 0.5; // do not steal all the next one's progress
              Browser.mainLoop.remainingBlockers = (8*remaining + next)/9;
            }
          }
          Browser.mainLoop.updateStatus();
  
          // catches pause/resume main loop from blocker execution
          if (!checkIsRunning()) return;
  
          setTimeout(Browser.mainLoop.runner, 0);
          return;
        }
  
        // catch pauses from non-main loop sources
        if (!checkIsRunning()) return;
  
        // Implement very basic swap interval control
        Browser.mainLoop.currentFrameNumber = Browser.mainLoop.currentFrameNumber + 1 | 0;
        if (Browser.mainLoop.timingMode == 1 && Browser.mainLoop.timingValue > 1 && Browser.mainLoop.currentFrameNumber % Browser.mainLoop.timingValue != 0) {
          // Not the scheduled time to render this frame - skip.
          Browser.mainLoop.scheduler();
          return;
        } else if (Browser.mainLoop.timingMode == 0) {
          Browser.mainLoop.tickStartTime = _emscripten_get_now();
        }
  
        // Signal GL rendering layer that processing of a new frame is about to start. This helps it optimize
        // VBO double-buffering and reduce GPU stalls.
  
        if (Browser.mainLoop.method === 'timeout' && Module.ctx) {
          warnOnce('Looks like you are rendering without using requestAnimationFrame for the main loop. You should use 0 for the frame rate in emscripten_set_main_loop in order to use requestAnimationFrame, as that can greatly improve your frame rates!');
          Browser.mainLoop.method = ''; // just warn once per call to set main loop
        }
  
        Browser.mainLoop.runIter(browserIterationFunc);
  
        checkStackCookie();
  
        // catch pauses from the main loop itself
        if (!checkIsRunning()) return;
  
        // Queue new audio data. This is important to be right after the main loop invocation, so that we will immediately be able
        // to queue the newest produced audio samples.
        // TODO: Consider adding pre- and post- rAF callbacks so that GL.newRenderingFrameStarted() and SDL.audio.queueNewAudioData()
        //       do not need to be hardcoded into this function, but can be more generic.
        if (typeof SDL == 'object') SDL.audio?.queueNewAudioData?.();
  
        Browser.mainLoop.scheduler();
      }
  
      if (!noSetTiming) {
        if (fps && fps > 0) {
          _emscripten_set_main_loop_timing(0, 1000.0 / fps);
        } else {
          // Do rAF by rendering each frame (no decimating)
          _emscripten_set_main_loop_timing(1, 1);
        }
  
        Browser.mainLoop.scheduler();
      }
  
      if (simulateInfiniteLoop) {
        throw 'unwind';
      }
    };
  
  var handleException = (e) => {
      // Certain exception types we do not treat as errors since they are used for
      // internal control flow.
      // 1. ExitStatus, which is thrown by exit()
      // 2. "unwind", which is thrown by emscripten_unwind_to_js_event_loop() and others
      //    that wish to return to JS event loop.
      if (e instanceof ExitStatus || e == 'unwind') {
        return EXITSTATUS;
      }
      checkStackCookie();
      if (e instanceof WebAssembly.RuntimeError) {
        if (_emscripten_stack_get_current() <= 0) {
          err('Stack overflow detected.  You can try increasing -sSTACK_SIZE (currently set to 65536)');
        }
      }
      quit_(1, e);
    };
  
  
  var runtimeKeepaliveCounter = 0;
  var keepRuntimeAlive = () => noExitRuntime || runtimeKeepaliveCounter > 0;
  var _proc_exit = (code) => {
      EXITSTATUS = code;
      if (!keepRuntimeAlive()) {
        Module['onExit']?.(code);
        ABORT = true;
      }
      quit_(code, new ExitStatus(code));
    };
  
  /** @suppress {duplicate } */
  /** @param {boolean|number=} implicit */
  var exitJS = (status, implicit) => {
      EXITSTATUS = status;
  
      checkUnflushedContent();
  
      // if exit() was called explicitly, warn the user if the runtime isn't actually being shut down
      if (keepRuntimeAlive() && !implicit) {
        var msg = `program exited (with status: ${status}), but keepRuntimeAlive() is set (counter=${runtimeKeepaliveCounter}) due to an async operation, so halting execution but not exiting the runtime or preventing further async execution (you can use emscripten_force_exit, if you want to force a true shutdown)`;
        err(msg);
      }
  
      _proc_exit(status);
    };
  var _exit = exitJS;
  
  
  var maybeExit = () => {
      if (!keepRuntimeAlive()) {
        try {
          _exit(EXITSTATUS);
        } catch (e) {
          handleException(e);
        }
      }
    };
  var callUserCallback = (func) => {
      if (ABORT) {
        err('user callback triggered after runtime exited or application aborted.  Ignoring.');
        return;
      }
      try {
        func();
        maybeExit();
      } catch (e) {
        handleException(e);
      }
    };
  
  /** @param {number=} timeout */
  var safeSetTimeout = (func, timeout) => {
      
      return setTimeout(() => {
        
        callUserCallback(func);
      }, timeout);
    };
  
  
  
  var preloadPlugins = Module['preloadPlugins'] || [];
  
  var Browser = {
  mainLoop:{
  running:false,
  scheduler:null,
  method:"",
  currentlyRunningMainloop:0,
  func:null,
  arg:0,
  timingMode:0,
  timingValue:0,
  currentFrameNumber:0,
  queue:[],
  pause() {
          Browser.mainLoop.scheduler = null;
          // Incrementing this signals the previous main loop that it's now become old, and it must return.
          Browser.mainLoop.currentlyRunningMainloop++;
        },
  resume() {
          Browser.mainLoop.currentlyRunningMainloop++;
          var timingMode = Browser.mainLoop.timingMode;
          var timingValue = Browser.mainLoop.timingValue;
          var func = Browser.mainLoop.func;
          Browser.mainLoop.func = null;
          // do not set timing and call scheduler, we will do it on the next lines
          setMainLoop(func, 0, false, Browser.mainLoop.arg, true);
          _emscripten_set_main_loop_timing(timingMode, timingValue);
          Browser.mainLoop.scheduler();
        },
  updateStatus() {
          if (Module['setStatus']) {
            var message = Module['statusMessage'] || 'Please wait...';
            var remaining = Browser.mainLoop.remainingBlockers;
            var expected = Browser.mainLoop.expectedBlockers;
            if (remaining) {
              if (remaining < expected) {
                Module['setStatus'](`{message} ({expected - remaining}/{expected})`);
              } else {
                Module['setStatus'](message);
              }
            } else {
              Module['setStatus']('');
            }
          }
        },
  runIter(func) {
          if (ABORT) return;
          if (Module['preMainLoop']) {
            var preRet = Module['preMainLoop']();
            if (preRet === false) {
              return; // |return false| skips a frame
            }
          }
          callUserCallback(func);
          Module['postMainLoop']?.();
        },
  },
  isFullscreen:false,
  pointerLock:false,
  moduleContextCreatedCallbacks:[],
  workers:[],
  init() {
        if (Browser.initted) return;
        Browser.initted = true;
  
        // Support for plugins that can process preloaded files. You can add more of these to
        // your app by creating and appending to preloadPlugins.
        //
        // Each plugin is asked if it can handle a file based on the file's name. If it can,
        // it is given the file's raw data. When it is done, it calls a callback with the file's
        // (possibly modified) data. For example, a plugin might decompress a file, or it
        // might create some side data structure for use later (like an Image element, etc.).
  
        var imagePlugin = {};
        imagePlugin['canHandle'] = function imagePlugin_canHandle(name) {
          return !Module.noImageDecoding && /\.(jpg|jpeg|png|bmp)$/i.test(name);
        };
        imagePlugin['handle'] = function imagePlugin_handle(byteArray, name, onload, onerror) {
          var b = new Blob([byteArray], { type: Browser.getMimetype(name) });
          if (b.size !== byteArray.length) { // Safari bug #118630
            // Safari's Blob can only take an ArrayBuffer
            b = new Blob([(new Uint8Array(byteArray)).buffer], { type: Browser.getMimetype(name) });
          }
          var url = URL.createObjectURL(b);
          assert(typeof url == 'string', 'createObjectURL must return a url as a string');
          var img = new Image();
          img.onload = () => {
            assert(img.complete, `Image ${name} could not be decoded`);
            var canvas = /** @type {!HTMLCanvasElement} */ (document.createElement('canvas'));
            canvas.width = img.width;
            canvas.height = img.height;
            var ctx = canvas.getContext('2d');
            ctx.drawImage(img, 0, 0);
            preloadedImages[name] = canvas;
            URL.revokeObjectURL(url);
            onload?.(byteArray);
          };
          img.onerror = (event) => {
            err(`Image ${url} could not be decoded`);
            onerror?.();
          };
          img.src = url;
        };
        preloadPlugins.push(imagePlugin);
  
        var audioPlugin = {};
        audioPlugin['canHandle'] = function audioPlugin_canHandle(name) {
          return !Module.noAudioDecoding && name.substr(-4) in { '.ogg': 1, '.wav': 1, '.mp3': 1 };
        };
        audioPlugin['handle'] = function audioPlugin_handle(byteArray, name, onload, onerror) {
          var done = false;
          function finish(audio) {
            if (done) return;
            done = true;
            preloadedAudios[name] = audio;
            onload?.(byteArray);
          }
          function fail() {
            if (done) return;
            done = true;
            preloadedAudios[name] = new Audio(); // empty shim
            onerror?.();
          }
          var b = new Blob([byteArray], { type: Browser.getMimetype(name) });
          var url = URL.createObjectURL(b); // XXX we never revoke this!
          assert(typeof url == 'string', 'createObjectURL must return a url as a string');
          var audio = new Audio();
          audio.addEventListener('canplaythrough', () => finish(audio), false); // use addEventListener due to chromium bug 124926
          audio.onerror = function audio_onerror(event) {
            if (done) return;
            err(`warning: browser could not fully decode audio ${name}, trying slower base64 approach`);
            function encode64(data) {
              var BASE = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
              var PAD = '=';
              var ret = '';
              var leftchar = 0;
              var leftbits = 0;
              for (var i = 0; i < data.length; i++) {
                leftchar = (leftchar << 8) | data[i];
                leftbits += 8;
                while (leftbits >= 6) {
                  var curr = (leftchar >> (leftbits-6)) & 0x3f;
                  leftbits -= 6;
                  ret += BASE[curr];
                }
              }
              if (leftbits == 2) {
                ret += BASE[(leftchar&3) << 4];
                ret += PAD + PAD;
              } else if (leftbits == 4) {
                ret += BASE[(leftchar&0xf) << 2];
                ret += PAD;
              }
              return ret;
            }
            audio.src = 'data:audio/x-' + name.substr(-3) + ';base64,' + encode64(byteArray);
            finish(audio); // we don't wait for confirmation this worked - but it's worth trying
          };
          audio.src = url;
          // workaround for chrome bug 124926 - we do not always get oncanplaythrough or onerror
          safeSetTimeout(() => {
            finish(audio); // try to use it even though it is not necessarily ready to play
          }, 10000);
        };
        preloadPlugins.push(audioPlugin);
  
        // Canvas event setup
  
        function pointerLockChange() {
          Browser.pointerLock = document['pointerLockElement'] === Module['canvas'] ||
                                document['mozPointerLockElement'] === Module['canvas'] ||
                                document['webkitPointerLockElement'] === Module['canvas'] ||
                                document['msPointerLockElement'] === Module['canvas'];
        }
        var canvas = Module['canvas'];
        if (canvas) {
          // forced aspect ratio can be enabled by defining 'forcedAspectRatio' on Module
          // Module['forcedAspectRatio'] = 4 / 3;
  
          canvas.requestPointerLock = canvas['requestPointerLock'] ||
                                      canvas['mozRequestPointerLock'] ||
                                      canvas['webkitRequestPointerLock'] ||
                                      canvas['msRequestPointerLock'] ||
                                      (() => {});
          canvas.exitPointerLock = document['exitPointerLock'] ||
                                   document['mozExitPointerLock'] ||
                                   document['webkitExitPointerLock'] ||
                                   document['msExitPointerLock'] ||
                                   (() => {}); // no-op if function does not exist
          canvas.exitPointerLock = canvas.exitPointerLock.bind(document);
  
          document.addEventListener('pointerlockchange', pointerLockChange, false);
          document.addEventListener('mozpointerlockchange', pointerLockChange, false);
          document.addEventListener('webkitpointerlockchange', pointerLockChange, false);
          document.addEventListener('mspointerlockchange', pointerLockChange, false);
  
          if (Module['elementPointerLock']) {
            canvas.addEventListener("click", (ev) => {
              if (!Browser.pointerLock && Module['canvas'].requestPointerLock) {
                Module['canvas'].requestPointerLock();
                ev.preventDefault();
              }
            }, false);
          }
        }
      },
  createContext(/** @type {HTMLCanvasElement} */ canvas, useWebGL, setInModule, webGLContextAttributes) {
        if (useWebGL && Module.ctx && canvas == Module.canvas) return Module.ctx; // no need to recreate GL context if it's already been created for this canvas.
  
        var ctx;
        var contextHandle;
        if (useWebGL) {
          // For GLES2/desktop GL compatibility, adjust a few defaults to be different to WebGL defaults, so that they align better with the desktop defaults.
          var contextAttributes = {
            antialias: false,
            alpha: false,
            majorVersion: 1,
          };
  
          if (webGLContextAttributes) {
            for (var attribute in webGLContextAttributes) {
              contextAttributes[attribute] = webGLContextAttributes[attribute];
            }
          }
  
          // This check of existence of GL is here to satisfy Closure compiler, which yells if variable GL is referenced below but GL object is not
          // actually compiled in because application is not doing any GL operations. TODO: Ideally if GL is not being used, this function
          // Browser.createContext() should not even be emitted.
          if (typeof GL != 'undefined') {
            contextHandle = GL.createContext(canvas, contextAttributes);
            if (contextHandle) {
              ctx = GL.getContext(contextHandle).GLctx;
            }
          }
        } else {
          ctx = canvas.getContext('2d');
        }
  
        if (!ctx) return null;
  
        if (setInModule) {
          if (!useWebGL) assert(typeof GLctx == 'undefined', 'cannot set in module if GLctx is used, but we are a non-GL context that would replace it');
          Module.ctx = ctx;
          if (useWebGL) GL.makeContextCurrent(contextHandle);
          Module.useWebGL = useWebGL;
          Browser.moduleContextCreatedCallbacks.forEach((callback) => callback());
          Browser.init();
        }
        return ctx;
      },
  destroyContext(canvas, useWebGL, setInModule) {},
  fullscreenHandlersInstalled:false,
  lockPointer:undefined,
  resizeCanvas:undefined,
  requestFullscreen(lockPointer, resizeCanvas) {
        Browser.lockPointer = lockPointer;
        Browser.resizeCanvas = resizeCanvas;
        if (typeof Browser.lockPointer == 'undefined') Browser.lockPointer = true;
        if (typeof Browser.resizeCanvas == 'undefined') Browser.resizeCanvas = false;
  
        var canvas = Module['canvas'];
        function fullscreenChange() {
          Browser.isFullscreen = false;
          var canvasContainer = canvas.parentNode;
          if ((document['fullscreenElement'] || document['mozFullScreenElement'] ||
               document['msFullscreenElement'] || document['webkitFullscreenElement'] ||
               document['webkitCurrentFullScreenElement']) === canvasContainer) {
            canvas.exitFullscreen = Browser.exitFullscreen;
            if (Browser.lockPointer) canvas.requestPointerLock();
            Browser.isFullscreen = true;
            if (Browser.resizeCanvas) {
              Browser.setFullscreenCanvasSize();
            } else {
              Browser.updateCanvasDimensions(canvas);
            }
          } else {
            // remove the full screen specific parent of the canvas again to restore the HTML structure from before going full screen
            canvasContainer.parentNode.insertBefore(canvas, canvasContainer);
            canvasContainer.parentNode.removeChild(canvasContainer);
  
            if (Browser.resizeCanvas) {
              Browser.setWindowedCanvasSize();
            } else {
              Browser.updateCanvasDimensions(canvas);
            }
          }
          Module['onFullScreen']?.(Browser.isFullscreen);
          Module['onFullscreen']?.(Browser.isFullscreen);
        }
  
        if (!Browser.fullscreenHandlersInstalled) {
          Browser.fullscreenHandlersInstalled = true;
          document.addEventListener('fullscreenchange', fullscreenChange, false);
          document.addEventListener('mozfullscreenchange', fullscreenChange, false);
          document.addEventListener('webkitfullscreenchange', fullscreenChange, false);
          document.addEventListener('MSFullscreenChange', fullscreenChange, false);
        }
  
        // create a new parent to ensure the canvas has no siblings. this allows browsers to optimize full screen performance when its parent is the full screen root
        var canvasContainer = document.createElement("div");
        canvas.parentNode.insertBefore(canvasContainer, canvas);
        canvasContainer.appendChild(canvas);
  
        // use parent of canvas as full screen root to allow aspect ratio correction (Firefox stretches the root to screen size)
        canvasContainer.requestFullscreen = canvasContainer['requestFullscreen'] ||
                                            canvasContainer['mozRequestFullScreen'] ||
                                            canvasContainer['msRequestFullscreen'] ||
                                           (canvasContainer['webkitRequestFullscreen'] ? () => canvasContainer['webkitRequestFullscreen'](Element['ALLOW_KEYBOARD_INPUT']) : null) ||
                                           (canvasContainer['webkitRequestFullScreen'] ? () => canvasContainer['webkitRequestFullScreen'](Element['ALLOW_KEYBOARD_INPUT']) : null);
  
        canvasContainer.requestFullscreen();
      },
  requestFullScreen() {
        abort('Module.requestFullScreen has been replaced by Module.requestFullscreen (without a capital S)');
      },
  exitFullscreen() {
        // This is workaround for chrome. Trying to exit from fullscreen
        // not in fullscreen state will cause "TypeError: Document not active"
        // in chrome. See https://github.com/emscripten-core/emscripten/pull/8236
        if (!Browser.isFullscreen) {
          return false;
        }
  
        var CFS = document['exitFullscreen'] ||
                  document['cancelFullScreen'] ||
                  document['mozCancelFullScreen'] ||
                  document['msExitFullscreen'] ||
                  document['webkitCancelFullScreen'] ||
            (() => {});
        CFS.apply(document, []);
        return true;
      },
  nextRAF:0,
  fakeRequestAnimationFrame(func) {
        // try to keep 60fps between calls to here
        var now = Date.now();
        if (Browser.nextRAF === 0) {
          Browser.nextRAF = now + 1000/60;
        } else {
          while (now + 2 >= Browser.nextRAF) { // fudge a little, to avoid timer jitter causing us to do lots of delay:0
            Browser.nextRAF += 1000/60;
          }
        }
        var delay = Math.max(Browser.nextRAF - now, 0);
        setTimeout(func, delay);
      },
  requestAnimationFrame(func) {
        if (typeof requestAnimationFrame == 'function') {
          requestAnimationFrame(func);
          return;
        }
        var RAF = Browser.fakeRequestAnimationFrame;
        RAF(func);
      },
  safeSetTimeout(func, timeout) {
        // Legacy function, this is used by the SDL2 port so we need to keep it
        // around at least until that is updated.
        // See https://github.com/libsdl-org/SDL/pull/6304
        return safeSetTimeout(func, timeout);
      },
  safeRequestAnimationFrame(func) {
        
        return Browser.requestAnimationFrame(() => {
          
          callUserCallback(func);
        });
      },
  getMimetype(name) {
        return {
          'jpg': 'image/jpeg',
          'jpeg': 'image/jpeg',
          'png': 'image/png',
          'bmp': 'image/bmp',
          'ogg': 'audio/ogg',
          'wav': 'audio/wav',
          'mp3': 'audio/mpeg'
        }[name.substr(name.lastIndexOf('.')+1)];
      },
  getUserMedia(func) {
        window.getUserMedia ||= navigator['getUserMedia'] ||
                                navigator['mozGetUserMedia'];
        window.getUserMedia(func);
      },
  getMovementX(event) {
        return event['movementX'] ||
               event['mozMovementX'] ||
               event['webkitMovementX'] ||
               0;
      },
  getMovementY(event) {
        return event['movementY'] ||
               event['mozMovementY'] ||
               event['webkitMovementY'] ||
               0;
      },
  getMouseWheelDelta(event) {
        var delta = 0;
        switch (event.type) {
          case 'DOMMouseScroll':
            // 3 lines make up a step
            delta = event.detail / 3;
            break;
          case 'mousewheel':
            // 120 units make up a step
            delta = event.wheelDelta / 120;
            break;
          case 'wheel':
            delta = event.deltaY
            switch (event.deltaMode) {
              case 0:
                // DOM_DELTA_PIXEL: 100 pixels make up a step
                delta /= 100;
                break;
              case 1:
                // DOM_DELTA_LINE: 3 lines make up a step
                delta /= 3;
                break;
              case 2:
                // DOM_DELTA_PAGE: A page makes up 80 steps
                delta *= 80;
                break;
              default:
                throw 'unrecognized mouse wheel delta mode: ' + event.deltaMode;
            }
            break;
          default:
            throw 'unrecognized mouse wheel event: ' + event.type;
        }
        return delta;
      },
  mouseX:0,
  mouseY:0,
  mouseMovementX:0,
  mouseMovementY:0,
  touches:{
  },
  lastTouches:{
  },
  calculateMouseCoords(pageX, pageY) {
        // Calculate the movement based on the changes
        // in the coordinates.
        var rect = Module["canvas"].getBoundingClientRect();
        var cw = Module["canvas"].width;
        var ch = Module["canvas"].height;
  
        // Neither .scrollX or .pageXOffset are defined in a spec, but
        // we prefer .scrollX because it is currently in a spec draft.
        // (see: http://www.w3.org/TR/2013/WD-cssom-view-20131217/)
        var scrollX = ((typeof window.scrollX != 'undefined') ? window.scrollX : window.pageXOffset);
        var scrollY = ((typeof window.scrollY != 'undefined') ? window.scrollY : window.pageYOffset);
        // If this assert lands, it's likely because the browser doesn't support scrollX or pageXOffset
        // and we have no viable fallback.
        assert((typeof scrollX != 'undefined') && (typeof scrollY != 'undefined'), 'Unable to retrieve scroll position, mouse positions likely broken.');
        var adjustedX = pageX - (scrollX + rect.left);
        var adjustedY = pageY - (scrollY + rect.top);
  
        // the canvas might be CSS-scaled compared to its backbuffer;
        // SDL-using content will want mouse coordinates in terms
        // of backbuffer units.
        adjustedX = adjustedX * (cw / rect.width);
        adjustedY = adjustedY * (ch / rect.height);
  
        return { x: adjustedX, y: adjustedY };
      },
  setMouseCoords(pageX, pageY) {
        const {x, y} = Browser.calculateMouseCoords(pageX, pageY);
        Browser.mouseMovementX = x - Browser.mouseX;
        Browser.mouseMovementY = y - Browser.mouseY;
        Browser.mouseX = x;
        Browser.mouseY = y;
      },
  calculateMouseEvent(event) { // event should be mousemove, mousedown or mouseup
        if (Browser.pointerLock) {
          // When the pointer is locked, calculate the coordinates
          // based on the movement of the mouse.
          // Workaround for Firefox bug 764498
          if (event.type != 'mousemove' &&
              ('mozMovementX' in event)) {
            Browser.mouseMovementX = Browser.mouseMovementY = 0;
          } else {
            Browser.mouseMovementX = Browser.getMovementX(event);
            Browser.mouseMovementY = Browser.getMovementY(event);
          }
  
          // add the mouse delta to the current absolute mouse position
          Browser.mouseX += Browser.mouseMovementX;
          Browser.mouseY += Browser.mouseMovementY;
        } else {
          if (event.type === 'touchstart' || event.type === 'touchend' || event.type === 'touchmove') {
            var touch = event.touch;
            if (touch === undefined) {
              return; // the "touch" property is only defined in SDL
  
            }
            var coords = Browser.calculateMouseCoords(touch.pageX, touch.pageY);
  
            if (event.type === 'touchstart') {
              Browser.lastTouches[touch.identifier] = coords;
              Browser.touches[touch.identifier] = coords;
            } else if (event.type === 'touchend' || event.type === 'touchmove') {
              var last = Browser.touches[touch.identifier];
              last ||= coords;
              Browser.lastTouches[touch.identifier] = last;
              Browser.touches[touch.identifier] = coords;
            }
            return;
          }
  
          Browser.setMouseCoords(event.pageX, event.pageY);
        }
      },
  resizeListeners:[],
  updateResizeListeners() {
        var canvas = Module['canvas'];
        Browser.resizeListeners.forEach((listener) => listener(canvas.width, canvas.height));
      },
  setCanvasSize(width, height, noUpdates) {
        var canvas = Module['canvas'];
        Browser.updateCanvasDimensions(canvas, width, height);
        if (!noUpdates) Browser.updateResizeListeners();
      },
  windowedWidth:0,
  windowedHeight:0,
  setFullscreenCanvasSize() {
        // check if SDL is available
        if (typeof SDL != "undefined") {
          var flags = HEAPU32[((SDL.screen)>>2)];
          flags = flags | 0x00800000; // set SDL_FULLSCREEN flag
          HEAP32[((SDL.screen)>>2)] = flags;
        }
        Browser.updateCanvasDimensions(Module['canvas']);
        Browser.updateResizeListeners();
      },
  setWindowedCanvasSize() {
        // check if SDL is available
        if (typeof SDL != "undefined") {
          var flags = HEAPU32[((SDL.screen)>>2)];
          flags = flags & ~0x00800000; // clear SDL_FULLSCREEN flag
          HEAP32[((SDL.screen)>>2)] = flags;
        }
        Browser.updateCanvasDimensions(Module['canvas']);
        Browser.updateResizeListeners();
      },
  updateCanvasDimensions(canvas, wNative, hNative) {
        if (wNative && hNative) {
          canvas.widthNative = wNative;
          canvas.heightNative = hNative;
        } else {
          wNative = canvas.widthNative;
          hNative = canvas.heightNative;
        }
        var w = wNative;
        var h = hNative;
        if (Module['forcedAspectRatio'] && Module['forcedAspectRatio'] > 0) {
          if (w/h < Module['forcedAspectRatio']) {
            w = Math.round(h * Module['forcedAspectRatio']);
          } else {
            h = Math.round(w / Module['forcedAspectRatio']);
          }
        }
        if (((document['fullscreenElement'] || document['mozFullScreenElement'] ||
             document['msFullscreenElement'] || document['webkitFullscreenElement'] ||
             document['webkitCurrentFullScreenElement']) === canvas.parentNode) && (typeof screen != 'undefined')) {
           var factor = Math.min(screen.width / w, screen.height / h);
           w = Math.round(w * factor);
           h = Math.round(h * factor);
        }
        if (Browser.resizeCanvas) {
          if (canvas.width  != w) canvas.width  = w;
          if (canvas.height != h) canvas.height = h;
          if (typeof canvas.style != 'undefined') {
            canvas.style.removeProperty( "width");
            canvas.style.removeProperty("height");
          }
        } else {
          if (canvas.width  != wNative) canvas.width  = wNative;
          if (canvas.height != hNative) canvas.height = hNative;
          if (typeof canvas.style != 'undefined') {
            if (w != wNative || h != hNative) {
              canvas.style.setProperty( "width", w + "px", "important");
              canvas.style.setProperty("height", h + "px", "important");
            } else {
              canvas.style.removeProperty( "width");
              canvas.style.removeProperty("height");
            }
          }
        }
      },
  };
  
  var _SDL_GetTicks = () => (Date.now() - SDL.startTime)|0;
  
  
  var lengthBytesUTF8 = (str) => {
      var len = 0;
      for (var i = 0; i < str.length; ++i) {
        // Gotcha: charCodeAt returns a 16-bit word that is a UTF-16 encoded code
        // unit, not a Unicode code point of the character! So decode
        // UTF16->UTF32->UTF8.
        // See http://unicode.org/faq/utf_bom.html#utf16-3
        var c = str.charCodeAt(i); // possibly a lead surrogate
        if (c <= 0x7F) {
          len++;
        } else if (c <= 0x7FF) {
          len += 2;
        } else if (c >= 0xD800 && c <= 0xDFFF) {
          len += 4; ++i;
        } else {
          len += 3;
        }
      }
      return len;
    };
  
  var stringToUTF8Array = (str, heap, outIdx, maxBytesToWrite) => {
      assert(typeof str === 'string', `stringToUTF8Array expects a string (got ${typeof str})`);
      // Parameter maxBytesToWrite is not optional. Negative values, 0, null,
      // undefined and false each don't write out any bytes.
      if (!(maxBytesToWrite > 0))
        return 0;
  
      var startIdx = outIdx;
      var endIdx = outIdx + maxBytesToWrite - 1; // -1 for string null terminator.
      for (var i = 0; i < str.length; ++i) {
        // Gotcha: charCodeAt returns a 16-bit word that is a UTF-16 encoded code
        // unit, not a Unicode code point of the character! So decode
        // UTF16->UTF32->UTF8.
        // See http://unicode.org/faq/utf_bom.html#utf16-3
        // For UTF8 byte structure, see http://en.wikipedia.org/wiki/UTF-8#Description
        // and https://www.ietf.org/rfc/rfc2279.txt
        // and https://tools.ietf.org/html/rfc3629
        var u = str.charCodeAt(i); // possibly a lead surrogate
        if (u >= 0xD800 && u <= 0xDFFF) {
          var u1 = str.charCodeAt(++i);
          u = 0x10000 + ((u & 0x3FF) << 10) | (u1 & 0x3FF);
        }
        if (u <= 0x7F) {
          if (outIdx >= endIdx) break;
          heap[outIdx++] = u;
        } else if (u <= 0x7FF) {
          if (outIdx + 1 >= endIdx) break;
          heap[outIdx++] = 0xC0 | (u >> 6);
          heap[outIdx++] = 0x80 | (u & 63);
        } else if (u <= 0xFFFF) {
          if (outIdx + 2 >= endIdx) break;
          heap[outIdx++] = 0xE0 | (u >> 12);
          heap[outIdx++] = 0x80 | ((u >> 6) & 63);
          heap[outIdx++] = 0x80 | (u & 63);
        } else {
          if (outIdx + 3 >= endIdx) break;
          if (u > 0x10FFFF) warnOnce('Invalid Unicode code point ' + ptrToString(u) + ' encountered when serializing a JS string to a UTF-8 string in wasm memory! (Valid unicode code points should be in range 0-0x10FFFF).');
          heap[outIdx++] = 0xF0 | (u >> 18);
          heap[outIdx++] = 0x80 | ((u >> 12) & 63);
          heap[outIdx++] = 0x80 | ((u >> 6) & 63);
          heap[outIdx++] = 0x80 | (u & 63);
        }
      }
      // Null-terminate the pointer to the buffer.
      heap[outIdx] = 0;
      return outIdx - startIdx;
    };
  /** @type {function(string, boolean=, number=)} */
  function intArrayFromString(stringy, dontAddNull, length) {
    var len = length > 0 ? length : lengthBytesUTF8(stringy)+1;
    var u8array = new Array(len);
    var numBytesWritten = stringToUTF8Array(stringy, u8array, 0, u8array.length);
    if (dontAddNull) u8array.length = numBytesWritten;
    return u8array;
  }
  
  
  
  var SDL = {
  defaults:{
  width:320,
  height:200,
  copyOnLock:true,
  discardOnLock:false,
  opaqueFrontBuffer:true,
  },
  version:null,
  surfaces:{
  },
  canvasPool:[],
  events:[],
  fonts:[null],
  audios:[null],
  rwops:[null],
  music:{
  audio:null,
  volume:1,
  },
  mixerFrequency:22050,
  mixerFormat:32784,
  mixerNumChannels:2,
  mixerChunkSize:1024,
  channelMinimumNumber:0,
  GL:false,
  glAttributes:{
  0:3,
  1:3,
  2:2,
  3:0,
  4:0,
  5:1,
  6:16,
  7:0,
  8:0,
  9:0,
  10:0,
  11:0,
  12:0,
  13:0,
  14:0,
  15:1,
  16:0,
  17:0,
  18:0,
  },
  keyboardState:null,
  keyboardMap:{
  },
  canRequestFullscreen:false,
  isRequestingFullscreen:false,
  textInput:false,
  unicode:false,
  ttfContext:null,
  audio:null,
  startTime:null,
  initFlags:0,
  buttonState:0,
  modState:0,
  DOMButtons:[0,0,0],
  DOMEventToSDLEvent:{
  },
  TOUCH_DEFAULT_ID:0,
  eventHandler:null,
  eventHandlerContext:null,
  eventHandlerTemp:0,
  keyCodes:{
  16:1249,
  17:1248,
  18:1250,
  20:1081,
  33:1099,
  34:1102,
  35:1101,
  36:1098,
  37:1104,
  38:1106,
  39:1103,
  40:1105,
  44:316,
  45:1097,
  46:127,
  91:1251,
  93:1125,
  96:1122,
  97:1113,
  98:1114,
  99:1115,
  100:1116,
  101:1117,
  102:1118,
  103:1119,
  104:1120,
  105:1121,
  106:1109,
  107:1111,
  109:1110,
  110:1123,
  111:1108,
  112:1082,
  113:1083,
  114:1084,
  115:1085,
  116:1086,
  117:1087,
  118:1088,
  119:1089,
  120:1090,
  121:1091,
  122:1092,
  123:1093,
  124:1128,
  125:1129,
  126:1130,
  127:1131,
  128:1132,
  129:1133,
  130:1134,
  131:1135,
  132:1136,
  133:1137,
  134:1138,
  135:1139,
  144:1107,
  160:94,
  161:33,
  162:34,
  163:35,
  164:36,
  165:37,
  166:38,
  167:95,
  168:40,
  169:41,
  170:42,
  171:43,
  172:124,
  173:45,
  174:123,
  175:125,
  176:126,
  181:127,
  182:129,
  183:128,
  188:44,
  190:46,
  191:47,
  192:96,
  219:91,
  220:92,
  221:93,
  222:39,
  224:1251,
  },
  scanCodes:{
  8:42,
  9:43,
  13:40,
  27:41,
  32:44,
  35:204,
  39:53,
  44:54,
  46:55,
  47:56,
  48:39,
  49:30,
  50:31,
  51:32,
  52:33,
  53:34,
  54:35,
  55:36,
  56:37,
  57:38,
  58:203,
  59:51,
  61:46,
  91:47,
  92:49,
  93:48,
  96:52,
  97:4,
  98:5,
  99:6,
  100:7,
  101:8,
  102:9,
  103:10,
  104:11,
  105:12,
  106:13,
  107:14,
  108:15,
  109:16,
  110:17,
  111:18,
  112:19,
  113:20,
  114:21,
  115:22,
  116:23,
  117:24,
  118:25,
  119:26,
  120:27,
  121:28,
  122:29,
  127:76,
  305:224,
  308:226,
  316:70,
  },
  loadRect(rect) {
        return {
          x: HEAP32[((rect + 0)>>2)],
          y: HEAP32[((rect + 4)>>2)],
          w: HEAP32[((rect + 8)>>2)],
          h: HEAP32[((rect + 12)>>2)]
        };
      },
  updateRect(rect, r) {
        HEAP32[((rect)>>2)] = r.x;
        HEAP32[(((rect)+(4))>>2)] = r.y;
        HEAP32[(((rect)+(8))>>2)] = r.w;
        HEAP32[(((rect)+(12))>>2)] = r.h;
      },
  intersectionOfRects(first, second) {
        var leftX = Math.max(first.x, second.x);
        var leftY = Math.max(first.y, second.y);
        var rightX = Math.min(first.x + first.w, second.x + second.w);
        var rightY = Math.min(first.y + first.h, second.y + second.h);
  
        return {
          x: leftX,
          y: leftY,
          w: Math.max(leftX, rightX) - leftX,
          h: Math.max(leftY, rightY) - leftY
        }
      },
  checkPixelFormat(fmt) {
        // Canvas screens are always RGBA.
        var format = HEAP32[((fmt)>>2)];
        if (format != -2042224636) {
          warnOnce('Unsupported pixel format!');
        }
      },
  loadColorToCSSRGB(color) {
        var rgba = HEAP32[((color)>>2)];
        return 'rgb(' + (rgba&255) + ',' + ((rgba >> 8)&255) + ',' + ((rgba >> 16)&255) + ')';
      },
  loadColorToCSSRGBA(color) {
        var rgba = HEAP32[((color)>>2)];
        return 'rgba(' + (rgba&255) + ',' + ((rgba >> 8)&255) + ',' + ((rgba >> 16)&255) + ',' + (((rgba >> 24)&255)/255) + ')';
      },
  translateColorToCSSRGBA:(rgba) =>
        'rgba(' + (rgba&0xff) + ',' + (rgba>>8 & 0xff) + ',' + (rgba>>16 & 0xff) + ',' + (rgba>>>24)/0xff + ')',
  translateRGBAToCSSRGBA:(r, g, b, a) =>
        'rgba(' + (r&0xff) + ',' + (g&0xff) + ',' + (b&0xff) + ',' + (a&0xff)/255 + ')',
  translateRGBAToColor:(r, g, b, a) => r | g << 8 | b << 16 | a << 24,
  makeSurface(width, height, flags, usePageCanvas, source, rmask, gmask, bmask, amask) {
        var is_SDL_HWSURFACE = flags & 0x00000001;
        var is_SDL_HWPALETTE = flags & 0x00200000;
        var is_SDL_OPENGL = flags & 0x04000000;
  
        var surf = _malloc(60);
        var pixelFormat = _malloc(44);
        //surface with SDL_HWPALETTE flag is 8bpp surface (1 byte)
        var bpp = is_SDL_HWPALETTE ? 1 : 4;
        var buffer = 0;
  
        // preemptively initialize this for software surfaces,
        // otherwise it will be lazily initialized inside of SDL_LockSurface
        if (!is_SDL_HWSURFACE && !is_SDL_OPENGL) {
          buffer = _malloc(width * height * 4);
        }
  
        HEAP32[((surf)>>2)] = flags;
        HEAPU32[(((surf)+(4))>>2)] = pixelFormat;
        HEAP32[(((surf)+(8))>>2)] = width;
        HEAP32[(((surf)+(12))>>2)] = height;
        HEAP32[(((surf)+(16))>>2)] = width * bpp;  // assuming RGBA or indexed for now,
                                                                                          // since that is what ImageData gives us in browsers
        HEAPU32[(((surf)+(20))>>2)] = buffer;
  
        HEAP32[(((surf)+(36))>>2)] = 0;
        HEAP32[(((surf)+(40))>>2)] = 0;
        HEAP32[(((surf)+(44))>>2)] = Module["canvas"].width;
        HEAP32[(((surf)+(48))>>2)] = Module["canvas"].height;
  
        HEAP32[(((surf)+(56))>>2)] = 1;
  
        HEAP32[((pixelFormat)>>2)] = -2042224636;
        HEAP32[(((pixelFormat)+(4))>>2)] = 0;// TODO
        HEAP8[(pixelFormat)+(8)] = bpp * 8;
        HEAP8[(pixelFormat)+(9)] = bpp;
  
        HEAP32[(((pixelFormat)+(12))>>2)] = rmask || 0x000000ff;
        HEAP32[(((pixelFormat)+(16))>>2)] = gmask || 0x0000ff00;
        HEAP32[(((pixelFormat)+(20))>>2)] = bmask || 0x00ff0000;
        HEAP32[(((pixelFormat)+(24))>>2)] = amask || 0xff000000;
  
        // Decide if we want to use WebGL or not
        SDL.GL = SDL.GL || is_SDL_OPENGL;
        var canvas;
        if (!usePageCanvas) {
          if (SDL.canvasPool.length > 0) {
            canvas = SDL.canvasPool.pop();
          } else {
            canvas = document.createElement('canvas');
          }
          canvas.width = width;
          canvas.height = height;
        } else {
          canvas = Module['canvas'];
        }
  
        var webGLContextAttributes = {
          antialias: ((SDL.glAttributes[13 /*SDL_GL_MULTISAMPLEBUFFERS*/] != 0) && (SDL.glAttributes[14 /*SDL_GL_MULTISAMPLESAMPLES*/] > 1)),
          depth: (SDL.glAttributes[6 /*SDL_GL_DEPTH_SIZE*/] > 0),
          stencil: (SDL.glAttributes[7 /*SDL_GL_STENCIL_SIZE*/] > 0),
          alpha: (SDL.glAttributes[3 /*SDL_GL_ALPHA_SIZE*/] > 0)
        };
  
        var ctx = Browser.createContext(canvas, is_SDL_OPENGL, usePageCanvas, webGLContextAttributes);
  
        SDL.surfaces[surf] = {
          width,
          height,
          canvas,
          ctx,
          surf,
          buffer,
          pixelFormat,
          alpha: 255,
          flags,
          locked: 0,
          usePageCanvas,
          source,
  
          isFlagSet: (flag) => flags & flag
        };
  
        return surf;
      },
  copyIndexedColorData(surfData, rX, rY, rW, rH) {
        // HWPALETTE works with palette
        // set by SDL_SetColors
        if (!surfData.colors) {
          return;
        }
  
        var fullWidth  = Module['canvas'].width;
        var fullHeight = Module['canvas'].height;
  
        var startX  = rX || 0;
        var startY  = rY || 0;
        var endX    = (rW || (fullWidth - startX)) + startX;
        var endY    = (rH || (fullHeight - startY)) + startY;
  
        var buffer  = surfData.buffer;
  
        if (!surfData.image.data32) {
          surfData.image.data32 = new Uint32Array(surfData.image.data.buffer);
        }
        var data32   = surfData.image.data32;
  
        var colors32 = surfData.colors32;
  
        for (var y = startY; y < endY; ++y) {
          var base = y * fullWidth;
          for (var x = startX; x < endX; ++x) {
            data32[base + x] = colors32[HEAPU8[buffer + base + x]];
          }
        }
      },
  freeSurface(surf) {
        var refcountPointer = surf + 56;
        var refcount = HEAP32[((refcountPointer)>>2)];
        if (refcount > 1) {
          HEAP32[((refcountPointer)>>2)] = refcount - 1;
          return;
        }
  
        var info = SDL.surfaces[surf];
        if (!info.usePageCanvas && info.canvas) SDL.canvasPool.push(info.canvas);
        if (info.buffer) _free(info.buffer);
        _free(info.pixelFormat);
        _free(surf);
        SDL.surfaces[surf] = null;
  
        if (surf === SDL.screen) {
          SDL.screen = null;
        }
      },
  blitSurface(src, srcrect, dst, dstrect, scale) {
        var srcData = SDL.surfaces[src];
        var dstData = SDL.surfaces[dst];
        var sr, dr;
        if (srcrect) {
          sr = SDL.loadRect(srcrect);
        } else {
          sr = { x: 0, y: 0, w: srcData.width, h: srcData.height };
        }
        if (dstrect) {
          dr = SDL.loadRect(dstrect);
        } else {
          dr = { x: 0, y: 0, w: srcData.width, h: srcData.height };
        }
        if (dstData.clipRect) {
          var widthScale = (!scale || sr.w === 0) ? 1 : sr.w / dr.w;
          var heightScale = (!scale || sr.h === 0) ? 1 : sr.h / dr.h;
  
          dr = SDL.intersectionOfRects(dstData.clipRect, dr);
  
          sr.w = dr.w * widthScale;
          sr.h = dr.h * heightScale;
  
          if (dstrect) {
            SDL.updateRect(dstrect, dr);
          }
        }
        var blitw, blith;
        if (scale) {
          blitw = dr.w; blith = dr.h;
        } else {
          blitw = sr.w; blith = sr.h;
        }
        if (sr.w === 0 || sr.h === 0 || blitw === 0 || blith === 0) {
          return 0;
        }
        var oldAlpha = dstData.ctx.globalAlpha;
        dstData.ctx.globalAlpha = srcData.alpha/255;
        dstData.ctx.drawImage(srcData.canvas, sr.x, sr.y, sr.w, sr.h, dr.x, dr.y, blitw, blith);
        dstData.ctx.globalAlpha = oldAlpha;
        if (dst != SDL.screen) {
          // XXX As in IMG_Load, for compatibility we write out |pixels|
          warnOnce('WARNING: copying canvas data to memory for compatibility');
          _SDL_LockSurface(dst);
          dstData.locked--; // The surface is not actually locked in this hack
        }
        return 0;
      },
  downFingers:{
  },
  savedKeydown:null,
  receiveEvent(event) {
        function unpressAllPressedKeys() {
          // Un-press all pressed keys: TODO
          for (var code in SDL.keyboardMap) {
            SDL.events.push({
              type: 'keyup',
              keyCode: SDL.keyboardMap[code]
            });
          }
        };
        switch (event.type) {
          case 'touchstart': case 'touchmove': {
            event.preventDefault();
  
            var touches = [];
  
            // Clear out any touchstart events that we've already processed
            if (event.type === 'touchstart') {
              for (var i = 0; i < event.touches.length; i++) {
                var touch = event.touches[i];
                if (SDL.downFingers[touch.identifier] != true) {
                  SDL.downFingers[touch.identifier] = true;
                  touches.push(touch);
                }
              }
            } else {
              touches = event.touches;
            }
  
            var firstTouch = touches[0];
            if (firstTouch) {
              if (event.type == 'touchstart') {
                SDL.DOMButtons[0] = 1;
              }
              var mouseEventType;
              switch (event.type) {
                case 'touchstart': mouseEventType = 'mousedown'; break;
                case 'touchmove': mouseEventType = 'mousemove'; break;
              }
              var mouseEvent = {
                type: mouseEventType,
                button: 0,
                pageX: firstTouch.clientX,
                pageY: firstTouch.clientY
              };
              SDL.events.push(mouseEvent);
            }
  
            for (var i = 0; i < touches.length; i++) {
              var touch = touches[i];
              SDL.events.push({
                type: event.type,
                touch
              });
            };
            break;
          }
          case 'touchend': {
            event.preventDefault();
  
            // Remove the entry in the SDL.downFingers hash
            // because the finger is no longer down.
            for (var i = 0; i < event.changedTouches.length; i++) {
              var touch = event.changedTouches[i];
              if (SDL.downFingers[touch.identifier] === true) {
                delete SDL.downFingers[touch.identifier];
              }
            }
  
            var mouseEvent = {
              type: 'mouseup',
              button: 0,
              pageX: event.changedTouches[0].clientX,
              pageY: event.changedTouches[0].clientY
            };
            SDL.DOMButtons[0] = 0;
            SDL.events.push(mouseEvent);
  
            for (var i = 0; i < event.changedTouches.length; i++) {
              var touch = event.changedTouches[i];
              SDL.events.push({
                type: 'touchend',
                touch
              });
            };
            break;
          }
          case 'DOMMouseScroll': case 'mousewheel': case 'wheel':
            // Flip the wheel direction to translate from browser wheel direction
            // (+:down) to SDL direction (+:up)
            var delta = -Browser.getMouseWheelDelta(event);
            // Quantize to integer so that minimum scroll is at least +/- 1.
            delta = (delta == 0) ? 0 : (delta > 0 ? Math.max(delta, 1) : Math.min(delta, -1));
  
            // Simulate old-style SDL events representing mouse wheel input as buttons
            // Subtract one since JS->C marshalling is defined to add one back.
            var button = delta > 0 ? 3 /*SDL_BUTTON_WHEELUP-1*/ : 4 /*SDL_BUTTON_WHEELDOWN-1*/;
            SDL.events.push({ type: 'mousedown', button, pageX: event.pageX, pageY: event.pageY });
            SDL.events.push({ type: 'mouseup', button, pageX: event.pageX, pageY: event.pageY });
  
            // Pass a delta motion event.
            SDL.events.push({ type: 'wheel', deltaX: 0, deltaY: delta });
            // If we don't prevent this, then 'wheel' event will be sent again by
            // the browser as 'DOMMouseScroll' and we will receive this same event
            // the second time.
            event.preventDefault();
            break;
          case 'mousemove':
            if (SDL.DOMButtons[0] === 1) {
              SDL.events.push({
                type: 'touchmove',
                touch: {
                  identifier: 0,
                  deviceID: -1,
                  pageX: event.pageX,
                  pageY: event.pageY
                }
              });
            }
            if (Browser.pointerLock) {
              // workaround for firefox bug 750111
              if ('mozMovementX' in event) {
                event['movementX'] = event['mozMovementX'];
                event['movementY'] = event['mozMovementY'];
              }
              // workaround for Firefox bug 782777
              if (event['movementX'] == 0 && event['movementY'] == 0) {
                // ignore a mousemove event if it doesn't contain any movement info
                // (without pointer lock, we infer movement from pageX/pageY, so this check is unnecessary)
                event.preventDefault();
                return;
              }
            }
            // fall through
          case 'keydown': case 'keyup': case 'keypress': case 'mousedown': case 'mouseup':
            // If we preventDefault on keydown events, the subsequent keypress events
            // won't fire. However, it's fine (and in some cases necessary) to
            // preventDefault for keys that don't generate a character. Otherwise,
            // preventDefault is the right thing to do in general.
            if (event.type !== 'keydown' || (!SDL.unicode && !SDL.textInput) || (event.keyCode === 8 /* backspace */ || event.keyCode === 9 /* tab */)) {
              event.preventDefault();
            }
  
            if (event.type == 'mousedown') {
              SDL.DOMButtons[event.button] = 1;
              SDL.events.push({
                type: 'touchstart',
                touch: {
                  identifier: 0,
                  deviceID: -1,
                  pageX: event.pageX,
                  pageY: event.pageY
                }
              });
            } else if (event.type == 'mouseup') {
              // ignore extra ups, can happen if we leave the canvas while pressing down, then return,
              // since we add a mouseup in that case
              if (!SDL.DOMButtons[event.button]) {
                return;
              }
  
              SDL.events.push({
                type: 'touchend',
                touch: {
                  identifier: 0,
                  deviceID: -1,
                  pageX: event.pageX,
                  pageY: event.pageY
                }
              });
              SDL.DOMButtons[event.button] = 0;
            }
  
            // We can only request fullscreen as the result of user input.
            // Due to this limitation, we toggle a boolean on keydown which
            // SDL_WM_ToggleFullScreen will check and subsequently set another
            // flag indicating for us to request fullscreen on the following
            // keyup. This isn't perfect, but it enables SDL_WM_ToggleFullScreen
            // to work as the result of a keypress (which is an extremely
            // common use case).
            if (event.type === 'keydown' || event.type === 'mousedown') {
              SDL.canRequestFullscreen = true;
            } else if (event.type === 'keyup' || event.type === 'mouseup') {
              if (SDL.isRequestingFullscreen) {
                Module['requestFullscreen'](/*lockPointer=*/true, /*resizeCanvas=*/true);
                SDL.isRequestingFullscreen = false;
              }
              SDL.canRequestFullscreen = false;
            }
  
            // SDL expects a unicode character to be passed to its keydown events.
            // Unfortunately, the browser APIs only provide a charCode property on
            // keypress events, so we must backfill in keydown events with their
            // subsequent keypress event's charCode.
            if (event.type === 'keypress' && SDL.savedKeydown) {
              // charCode is read-only
              SDL.savedKeydown.keypressCharCode = event.charCode;
              SDL.savedKeydown = null;
            } else if (event.type === 'keydown') {
              SDL.savedKeydown = event;
            }
  
            // Don't push keypress events unless SDL_StartTextInput has been called.
            if (event.type !== 'keypress' || SDL.textInput) {
              SDL.events.push(event);
            }
            break;
          case 'mouseout':
            // Un-press all pressed mouse buttons, because we might miss the release outside of the canvas
            for (var i = 0; i < 3; i++) {
              if (SDL.DOMButtons[i]) {
                SDL.events.push({
                  type: 'mouseup',
                  button: i,
                  pageX: event.pageX,
                  pageY: event.pageY
                });
                SDL.DOMButtons[i] = 0;
              }
            }
            event.preventDefault();
            break;
          case 'focus':
            SDL.events.push(event);
            event.preventDefault();
            break;
          case 'blur':
            SDL.events.push(event);
            unpressAllPressedKeys();
            event.preventDefault();
            break;
          case 'visibilitychange':
            SDL.events.push({
              type: 'visibilitychange',
              visible: !document.hidden
            });
            unpressAllPressedKeys();
            event.preventDefault();
            break;
          case 'unload':
            if (Browser.mainLoop.runner) {
              SDL.events.push(event);
              // Force-run a main event loop, since otherwise this event will never be caught!
              Browser.mainLoop.runner();
            }
            return;
          case 'resize':
            SDL.events.push(event);
            // manually triggered resize event doesn't have a preventDefault member
            if (event.preventDefault) {
              event.preventDefault();
            }
            break;
        }
        if (SDL.events.length >= 10000) {
          err('SDL event queue full, dropping events');
          SDL.events = SDL.events.slice(0, 10000);
        }
        // If we have a handler installed, this will push the events to the app
        // instead of the app polling for them.
        SDL.flushEventsToHandler();
        return;
      },
  lookupKeyCodeForEvent(event) {
        var code = event.keyCode;
        if (code >= 65 && code <= 90) {
          code += 32; // make lowercase for SDL
        } else {
          code = SDL.keyCodes[event.keyCode] || event.keyCode;
          // If this is one of the modifier keys (224 | 1<<10 - 227 | 1<<10), and the event specifies that it is
          // a right key, add 4 to get the right key SDL key code.
          if (event.location === 2 /*KeyboardEvent.DOM_KEY_LOCATION_RIGHT*/ && code >= (224 | 1<<10) && code <= (227 | 1<<10)) {
            code += 4;
          }
        }
        return code;
      },
  handleEvent(event) {
        if (event.handled) return;
        event.handled = true;
  
        switch (event.type) {
          case 'touchstart': case 'touchend': case 'touchmove': {
            Browser.calculateMouseEvent(event);
            break;
          }
          case 'keydown': case 'keyup': {
            var down = event.type === 'keydown';
            var code = SDL.lookupKeyCodeForEvent(event);
            // Assigning a boolean to HEAP8, that's alright but Closure would like to warn about it.
            // TODO(https://github.com/emscripten-core/emscripten/issues/16311):
            // This is kind of ugly hack.  Perhaps we can find a better way?
            /** @suppress{checkTypes} */
            HEAP8[(SDL.keyboardState)+(code)] = down;
            // TODO: lmeta, rmeta, numlock, capslock, KMOD_MODE, KMOD_RESERVED
            SDL.modState = (HEAP8[(SDL.keyboardState)+(1248)] ? 0x0040 : 0) | // KMOD_LCTRL
              (HEAP8[(SDL.keyboardState)+(1249)] ? 0x0001 : 0) | // KMOD_LSHIFT
              (HEAP8[(SDL.keyboardState)+(1250)] ? 0x0100 : 0) | // KMOD_LALT
              (HEAP8[(SDL.keyboardState)+(1252)] ? 0x0080 : 0) | // KMOD_RCTRL
              (HEAP8[(SDL.keyboardState)+(1253)] ? 0x0002 : 0) | // KMOD_RSHIFT
              (HEAP8[(SDL.keyboardState)+(1254)] ? 0x0200 : 0); //  KMOD_RALT
            if (down) {
              SDL.keyboardMap[code] = event.keyCode; // save the DOM input, which we can use to unpress it during blur
            } else {
              delete SDL.keyboardMap[code];
            }
  
            break;
          }
          case 'mousedown': case 'mouseup':
            if (event.type == 'mousedown') {
              // SDL_BUTTON(x) is defined as (1 << ((x)-1)).  SDL buttons are 1-3,
              // and DOM buttons are 0-2, so this means that the below formula is
              // correct.
              SDL.buttonState |= 1 << event.button;
            } else if (event.type == 'mouseup') {
              SDL.buttonState &= ~(1 << event.button);
            }
            // fall through
          case 'mousemove': {
            Browser.calculateMouseEvent(event);
            break;
          }
        }
      },
  flushEventsToHandler() {
        if (!SDL.eventHandler) return;
  
        while (SDL.pollEvent(SDL.eventHandlerTemp)) {
          ((a1, a2) => dynCall_iii(SDL.eventHandler, a1, a2))(SDL.eventHandlerContext, SDL.eventHandlerTemp);
        }
      },
  pollEvent(ptr) {
        if (SDL.initFlags & 0x200 && SDL.joystickEventState) {
          // If SDL_INIT_JOYSTICK was supplied AND the joystick system is configured
          // to automatically query for events, query for joystick events.
          SDL.queryJoysticks();
        }
        if (ptr) {
          while (SDL.events.length > 0) {
            if (SDL.makeCEvent(SDL.events.shift(), ptr) !== false) return 1;
          }
          return 0;
        }
        // XXX: somewhat risky in that we do not check if the event is real or not
        // (makeCEvent returns false) if no pointer supplied
        return SDL.events.length > 0;
      },
  makeCEvent(event, ptr) {
        if (typeof event == 'number') {
          // This is a pointer to a copy of a native C event that was SDL_PushEvent'ed
          _memcpy(ptr, event, 28);
          _free(event); // the copy is no longer needed
          return;
        }
  
        SDL.handleEvent(event);
  
        switch (event.type) {
          case 'keydown': case 'keyup': {
            var down = event.type === 'keydown';
            //dbg('Received key event: ' + event.keyCode);
            var key = SDL.lookupKeyCodeForEvent(event);
            var scan;
            if (key >= 1024) {
              scan = key - 1024;
            } else {
              scan = SDL.scanCodes[key] || key;
            }
  
            HEAP32[((ptr)>>2)] = SDL.DOMEventToSDLEvent[event.type];
            HEAP8[(ptr)+(8)] = down ? 1 : 0;
            HEAP8[(ptr)+(9)] = 0; // TODO
            HEAP32[(((ptr)+(12))>>2)] = scan;
            HEAP32[(((ptr)+(16))>>2)] = key;
            HEAP16[(((ptr)+(20))>>1)] = SDL.modState;
            // some non-character keys (e.g. backspace and tab) won't have keypressCharCode set, fill in with the keyCode.
            HEAP32[(((ptr)+(24))>>2)] = event.keypressCharCode || key;
  
            break;
          }
          case 'keypress': {
            HEAP32[((ptr)>>2)] = SDL.DOMEventToSDLEvent[event.type];
            // Not filling in windowID for now
            var cStr = intArrayFromString(String.fromCharCode(event.charCode));
            for (var i = 0; i < cStr.length; ++i) {
              HEAP8[(ptr)+(8 + i)] = cStr[i];
            }
            break;
          }
          case 'mousedown': case 'mouseup': case 'mousemove': {
            if (event.type != 'mousemove') {
              var down = event.type === 'mousedown';
              HEAP32[((ptr)>>2)] = SDL.DOMEventToSDLEvent[event.type];
              HEAP32[(((ptr)+(4))>>2)] = 0;
              HEAP32[(((ptr)+(8))>>2)] = 0;
              HEAP32[(((ptr)+(12))>>2)] = 0;
              HEAP8[(ptr)+(16)] = event.button+1; // DOM buttons are 0-2, SDL 1-3
              HEAP8[(ptr)+(17)] = down ? 1 : 0;
              HEAP32[(((ptr)+(20))>>2)] = Browser.mouseX;
              HEAP32[(((ptr)+(24))>>2)] = Browser.mouseY;
            } else {
              HEAP32[((ptr)>>2)] = SDL.DOMEventToSDLEvent[event.type];
              HEAP32[(((ptr)+(4))>>2)] = 0;
              HEAP32[(((ptr)+(8))>>2)] = 0;
              HEAP32[(((ptr)+(12))>>2)] = 0;
              HEAP32[(((ptr)+(16))>>2)] = SDL.buttonState;
              HEAP32[(((ptr)+(20))>>2)] = Browser.mouseX;
              HEAP32[(((ptr)+(24))>>2)] = Browser.mouseY;
              HEAP32[(((ptr)+(28))>>2)] = Browser.mouseMovementX;
              HEAP32[(((ptr)+(32))>>2)] = Browser.mouseMovementY;
            }
            break;
          }
          case 'wheel': {
            HEAP32[((ptr)>>2)] = SDL.DOMEventToSDLEvent[event.type];
            HEAP32[(((ptr)+(16))>>2)] = event.deltaX;
            HEAP32[(((ptr)+(20))>>2)] = event.deltaY;
            break;
          }
          case 'touchstart': case 'touchend': case 'touchmove': {
            var touch = event.touch;
            if (!Browser.touches[touch.identifier]) break;
            var w = Module['canvas'].width;
            var h = Module['canvas'].height;
            var x = Browser.touches[touch.identifier].x / w;
            var y = Browser.touches[touch.identifier].y / h;
            var lx = Browser.lastTouches[touch.identifier].x / w;
            var ly = Browser.lastTouches[touch.identifier].y / h;
            var dx = x - lx;
            var dy = y - ly;
            if (touch['deviceID'] === undefined) touch.deviceID = SDL.TOUCH_DEFAULT_ID;
            if (dx === 0 && dy === 0 && event.type === 'touchmove') return false; // don't send these if nothing happened
            HEAP32[((ptr)>>2)] = SDL.DOMEventToSDLEvent[event.type];
            HEAP32[(((ptr)+(4))>>2)] = _SDL_GetTicks();
            (tempI64 = [touch.deviceID>>>0,(tempDouble = touch.deviceID,(+(Math.abs(tempDouble))) >= 1.0 ? (tempDouble > 0.0 ? (+(Math.floor((tempDouble)/4294967296.0)))>>>0 : (~~((+(Math.ceil((tempDouble - +(((~~(tempDouble)))>>>0))/4294967296.0)))))>>>0) : 0)], HEAP32[(((ptr)+(8))>>2)] = tempI64[0],HEAP32[(((ptr)+(12))>>2)] = tempI64[1]);
            (tempI64 = [touch.identifier>>>0,(tempDouble = touch.identifier,(+(Math.abs(tempDouble))) >= 1.0 ? (tempDouble > 0.0 ? (+(Math.floor((tempDouble)/4294967296.0)))>>>0 : (~~((+(Math.ceil((tempDouble - +(((~~(tempDouble)))>>>0))/4294967296.0)))))>>>0) : 0)], HEAP32[(((ptr)+(16))>>2)] = tempI64[0],HEAP32[(((ptr)+(20))>>2)] = tempI64[1]);
            HEAPF32[(((ptr)+(24))>>2)] = x;
            HEAPF32[(((ptr)+(28))>>2)] = y;
            HEAPF32[(((ptr)+(32))>>2)] = dx;
            HEAPF32[(((ptr)+(36))>>2)] = dy;
            if (touch.force !== undefined) {
              HEAPF32[(((ptr)+(40))>>2)] = touch.force;
            } else { // No pressure data, send a digital 0/1 pressure.
              HEAPF32[(((ptr)+(40))>>2)] = event.type == "touchend" ? 0 : 1;
            }
            break;
          }
          case 'unload': {
            HEAP32[((ptr)>>2)] = SDL.DOMEventToSDLEvent[event.type];
            break;
          }
          case 'resize': {
            HEAP32[((ptr)>>2)] = SDL.DOMEventToSDLEvent[event.type];
            HEAP32[(((ptr)+(4))>>2)] = event.w;
            HEAP32[(((ptr)+(8))>>2)] = event.h;
            break;
          }
          case 'joystick_button_up': case 'joystick_button_down': {
            var state = event.type === 'joystick_button_up' ? 0 : 1;
            HEAP32[((ptr)>>2)] = SDL.DOMEventToSDLEvent[event.type];
            HEAP8[(ptr)+(4)] = event.index;
            HEAP8[(ptr)+(5)] = event.button;
            HEAP8[(ptr)+(6)] = state;
            break;
          }
          case 'joystick_axis_motion': {
            HEAP32[((ptr)>>2)] = SDL.DOMEventToSDLEvent[event.type];
            HEAP8[(ptr)+(4)] = event.index;
            HEAP8[(ptr)+(5)] = event.axis;
            HEAP32[(((ptr)+(8))>>2)] = SDL.joystickAxisValueConversion(event.value);
            break;
          }
          case 'focus': {
            var SDL_WINDOWEVENT_FOCUS_GAINED = 12 /* SDL_WINDOWEVENT_FOCUS_GAINED */;
            HEAP32[((ptr)>>2)] = SDL.DOMEventToSDLEvent[event.type];
            HEAP32[(((ptr)+(4))>>2)] = 0;
            HEAP8[(ptr)+(8)] = SDL_WINDOWEVENT_FOCUS_GAINED;
            break;
          }
          case 'blur': {
            var SDL_WINDOWEVENT_FOCUS_LOST = 13 /* SDL_WINDOWEVENT_FOCUS_LOST */;
            HEAP32[((ptr)>>2)] = SDL.DOMEventToSDLEvent[event.type];
            HEAP32[(((ptr)+(4))>>2)] = 0;
            HEAP8[(ptr)+(8)] = SDL_WINDOWEVENT_FOCUS_LOST;
            break;
          }
          case 'visibilitychange': {
            var SDL_WINDOWEVENT_SHOWN  = 1 /* SDL_WINDOWEVENT_SHOWN */;
            var SDL_WINDOWEVENT_HIDDEN = 2 /* SDL_WINDOWEVENT_HIDDEN */;
            var visibilityEventID = event.visible ? SDL_WINDOWEVENT_SHOWN : SDL_WINDOWEVENT_HIDDEN;
            HEAP32[((ptr)>>2)] = SDL.DOMEventToSDLEvent[event.type];
            HEAP32[(((ptr)+(4))>>2)] = 0;
            HEAP8[(ptr)+(8)] = visibilityEventID;
            break;
          }
          default: throw 'Unhandled SDL event: ' + event.type;
        }
      },
  makeFontString(height, fontName) {
        if (fontName.charAt(0) != "'" && fontName.charAt(0) != '"') {
          // https://developer.mozilla.org/ru/docs/Web/CSS/font-family
          // Font family names containing whitespace should be quoted.
          // BTW, quote all font names is easier than searching spaces
          fontName = '"' + fontName + '"';
        }
        return height + 'px ' + fontName + ', serif';
      },
  estimateTextWidth(fontData, text) {
        var h = fontData.size;
        var fontString = SDL.makeFontString(h, fontData.name);
        var tempCtx = SDL.ttfContext;
        assert(tempCtx, 'TTF_Init must have been called');
        tempCtx.font = fontString;
        var ret = tempCtx.measureText(text).width | 0;
        return ret;
      },
  allocateChannels(num) { // called from Mix_AllocateChannels and init
        if (SDL.numChannels && SDL.numChannels >= num && num != 0) return;
        SDL.numChannels = num;
        SDL.channels = [];
        for (var i = 0; i < num; i++) {
          SDL.channels[i] = {
            audio: null,
            volume: 1.0
          };
        }
      },
  setGetVolume(info, volume) {
        if (!info) return 0;
        var ret = info.volume * 128; // MIX_MAX_VOLUME
        if (volume != -1) {
          info.volume = Math.min(Math.max(volume, 0), 128) / 128;
          if (info.audio) {
            try {
              info.audio.volume = info.volume; // For <audio> element
              if (info.audio.webAudioGainNode) info.audio.webAudioGainNode['gain']['value'] = info.volume; // For WebAudio playback
            } catch(e) {
              err(`setGetVolume failed to set audio volume: ${e}`);
            }
          }
        }
        return ret;
      },
  setPannerPosition(info, x, y, z) {
        if (!info) return;
        if (info.audio) {
          if (info.audio.webAudioPannerNode) {
            info.audio.webAudioPannerNode['setPosition'](x, y, z);
          }
        }
      },
  playWebAudio(audio) {
        if (!audio) return;
        if (audio.webAudioNode) return; // This instance is already playing, don't start again.
        if (!SDL.webAudioAvailable()) return;
        try {
          var webAudio = audio.resource.webAudio;
          audio.paused = false;
          if (!webAudio.decodedBuffer) {
            if (webAudio.onDecodeComplete === undefined) abort("Cannot play back audio object that was not loaded");
            webAudio.onDecodeComplete.push(() => { if (!audio.paused) SDL.playWebAudio(audio); });
            return;
          }
          audio.webAudioNode = SDL.audioContext['createBufferSource']();
          audio.webAudioNode['buffer'] = webAudio.decodedBuffer;
          audio.webAudioNode['loop'] = audio.loop;
          audio.webAudioNode['onended'] = audio['onended']; // For <media> element compatibility, route the onended signal to the instance.
  
          audio.webAudioPannerNode = SDL.audioContext['createPanner']();
          // avoid Chrome bug
          // If posz = 0, the sound will come from only the right.
          // By posz = -0.5 (slightly ahead), the sound will come from right and left correctly.
          audio.webAudioPannerNode["setPosition"](0, 0, -.5);
          audio.webAudioPannerNode['panningModel'] = 'equalpower';
  
          // Add an intermediate gain node to control volume.
          audio.webAudioGainNode = SDL.audioContext['createGain']();
          audio.webAudioGainNode['gain']['value'] = audio.volume;
  
          audio.webAudioNode['connect'](audio.webAudioPannerNode);
          audio.webAudioPannerNode['connect'](audio.webAudioGainNode);
          audio.webAudioGainNode['connect'](SDL.audioContext['destination']);
  
          audio.webAudioNode['start'](0, audio.currentPosition);
          audio.startTime = SDL.audioContext['currentTime'] - audio.currentPosition;
        } catch(e) {
          err(`playWebAudio failed: ${e}`);
        }
      },
  pauseWebAudio(audio) {
        if (!audio) return;
        if (audio.webAudioNode) {
          try {
            // Remember where we left off, so that if/when we resume, we can restart the playback at a proper place.
            audio.currentPosition = (SDL.audioContext['currentTime'] - audio.startTime) % audio.resource.webAudio.decodedBuffer.duration;
            // Important: When we reach here, the audio playback is stopped by the user. But when calling .stop() below, the Web Audio
            // graph will send the onended signal, but we don't want to process that, since pausing should not clear/destroy the audio
            // channel.
            audio.webAudioNode['onended'] = undefined;
            audio.webAudioNode.stop(0); // 0 is a default parameter, but WebKit is confused by it #3861
            audio.webAudioNode = undefined;
          } catch(e) {
            err(`pauseWebAudio failed: ${e}`);
          }
        }
        audio.paused = true;
      },
  openAudioContext() {
        // Initialize Web Audio API if we haven't done so yet. Note: Only initialize Web Audio context ever once on the web page,
        // since initializing multiple times fails on Chrome saying 'audio resources have been exhausted'.
        if (!SDL.audioContext) {
          if (typeof AudioContext != 'undefined') SDL.audioContext = new AudioContext();
          else if (typeof webkitAudioContext != 'undefined') SDL.audioContext = new webkitAudioContext();
        }
      },
  webAudioAvailable:() => !!SDL.audioContext,
  fillWebAudioBufferFromHeap(heapPtr, sizeSamplesPerChannel, dstAudioBuffer) {
        // The input audio data is interleaved across the channels, i.e. [L, R, L, R, L, R, ...] and is either 8-bit, 16-bit or float as
        // supported by the SDL API. The output audio wave data for Web Audio API must be in planar buffers of [-1,1]-normalized Float32 data,
        // so perform a buffer conversion for the data.
        var audio = SDL.audio;
        var numChannels = audio.channels;
        for (var c = 0; c < numChannels; ++c) {
          var channelData = dstAudioBuffer['getChannelData'](c);
          if (channelData.length != sizeSamplesPerChannel) {
            throw 'Web Audio output buffer length mismatch! Destination size: ' + channelData.length + ' samples vs expected ' + sizeSamplesPerChannel + ' samples!';
          }
          if (audio.format == 32784) {
            for (var j = 0; j < sizeSamplesPerChannel; ++j) {
              channelData[j] = (HEAP16[(((heapPtr)+((j*numChannels + c)*2))>>1)]) / 0x8000;
            }
          } else if (audio.format == 8) {
            for (var j = 0; j < sizeSamplesPerChannel; ++j) {
              var v = (HEAP8[(heapPtr)+(j*numChannels + c)]);
              channelData[j] = ((v >= 0) ? v-128 : v+128) /128;
            }
          } else if (audio.format == 33056) {
            for (var j = 0; j < sizeSamplesPerChannel; ++j) {
              channelData[j] = (HEAPF32[(((heapPtr)+((j*numChannels + c)*4))>>2)]);
            }
          } else {
            throw 'Invalid SDL audio format ' + audio.format + '!';
          }
        }
      },
  debugSurface(surfData) {
        dbg('dumping surface ' + [surfData.surf, surfData.source, surfData.width, surfData.height]);
        var image = surfData.ctx.getImageData(0, 0, surfData.width, surfData.height);
        var data = image.data;
        var num = Math.min(surfData.width, surfData.height);
        for (var i = 0; i < num; i++) {
          dbg('   diagonal ' + i + ':' + [data[i*surfData.width*4 + i*4 + 0], data[i*surfData.width*4 + i*4 + 1], data[i*surfData.width*4 + i*4 + 2], data[i*surfData.width*4 + i*4 + 3]]);
        }
      },
  joystickEventState:1,
  lastJoystickState:{
  },
  joystickNamePool:{
  },
  recordJoystickState(joystick, state) {
        // Standardize button state.
        var buttons = new Array(state.buttons.length);
        for (var i = 0; i < state.buttons.length; i++) {
          buttons[i] = SDL.getJoystickButtonState(state.buttons[i]);
        }
  
        SDL.lastJoystickState[joystick] = {
          buttons,
          axes: state.axes.slice(0),
          timestamp: state.timestamp,
          index: state.index,
          id: state.id
        };
      },
  getJoystickButtonState(button) {
        if (typeof button == 'object') {
          // Current gamepad API editor's draft (Firefox Nightly)
          // https://dvcs.w3.org/hg/gamepad/raw-file/default/gamepad.html#idl-def-GamepadButton
          return button['pressed'];
        }
        // Current gamepad API working draft (Firefox / Chrome Stable)
        // http://www.w3.org/TR/2012/WD-gamepad-20120529/#gamepad-interface
        return button > 0;
      },
  queryJoysticks() {
        for (var joystick in SDL.lastJoystickState) {
          var state = SDL.getGamepad(joystick - 1);
          var prevState = SDL.lastJoystickState[joystick];
          // If joystick was removed, state returns null.
          if (typeof state == 'undefined') return;
          if (state === null) return;
          // Check only if the timestamp has differed.
          // NOTE: Timestamp is not available in Firefox.
          // NOTE: Timestamp is currently not properly set for the GearVR controller
          //       on Samsung Internet: it is always zero.
          if (typeof state.timestamp != 'number' || state.timestamp != prevState.timestamp || !state.timestamp) {
            var i;
            for (i = 0; i < state.buttons.length; i++) {
              var buttonState = SDL.getJoystickButtonState(state.buttons[i]);
              // NOTE: The previous state already has a boolean representation of
              //       its button, so no need to standardize its button state here.
              if (buttonState !== prevState.buttons[i]) {
                // Insert button-press event.
                SDL.events.push({
                  type: buttonState ? 'joystick_button_down' : 'joystick_button_up',
                  joystick,
                  index: joystick - 1,
                  button: i
                });
              }
            }
            for (i = 0; i < state.axes.length; i++) {
              if (state.axes[i] !== prevState.axes[i]) {
                // Insert axes-change event.
                SDL.events.push({
                  type: 'joystick_axis_motion',
                  joystick,
                  index: joystick - 1,
                  axis: i,
                  value: state.axes[i]
                });
              }
            }
  
            SDL.recordJoystickState(joystick, state);
          }
        }
      },
  joystickAxisValueConversion(value) {
        // Make sure value is properly clamped
        value = Math.min(1, Math.max(value, -1));
        // Ensures that 0 is 0, 1 is 32767, and -1 is 32768.
        return Math.ceil(((value+1) * 32767.5) - 32768);
      },
  getGamepads() {
        var fcn = navigator.getGamepads || navigator.webkitGamepads || navigator.mozGamepads || navigator.gamepads || navigator.webkitGetGamepads;
        if (fcn !== undefined) {
          // The function must be applied on the navigator object.
          return fcn.apply(navigator);
        }
        return [];
      },
  getGamepad(deviceIndex) {
        var gamepads = SDL.getGamepads();
        if (gamepads.length > deviceIndex && deviceIndex >= 0) {
          return gamepads[deviceIndex];
        }
        return null;
      },
  };
  var _SDL_LockSurface = (surf) => {
      var surfData = SDL.surfaces[surf];
  
      surfData.locked++;
      if (surfData.locked > 1) return 0;
  
      if (!surfData.buffer) {
        surfData.buffer = _malloc(surfData.width * surfData.height * 4);
        HEAPU32[(((surf)+(20))>>2)] = surfData.buffer;
      }
  
      // Mark in C/C++-accessible SDL structure
      // SDL_Surface has the following fields: Uint32 flags, SDL_PixelFormat *format; int w, h; Uint16 pitch; void *pixels; ...
      // So we have fields all of the same size, and 5 of them before us.
      // TODO: Use macros like in library.js
      HEAPU32[(((surf)+(20))>>2)] = surfData.buffer;
  
      if (surf == SDL.screen && Module.screenIsReadOnly && surfData.image) return 0;
  
      if (SDL.defaults.discardOnLock) {
        if (!surfData.image) {
          surfData.image = surfData.ctx.createImageData(surfData.width, surfData.height);
        }
        if (!SDL.defaults.opaqueFrontBuffer) return;
      } else {
        surfData.image = surfData.ctx.getImageData(0, 0, surfData.width, surfData.height);
      }
  
      // Emulate desktop behavior and kill alpha values on the locked surface. (very costly!) Set SDL.defaults.opaqueFrontBuffer = false
      // if you don't want this.
      if (surf == SDL.screen && SDL.defaults.opaqueFrontBuffer) {
        var data = surfData.image.data;
        var num = data.length;
        for (var i = 0; i < num/4; i++) {
          data[i*4+3] = 255; // opacity, as canvases blend alpha
        }
      }
  
      if (SDL.defaults.copyOnLock && !SDL.defaults.discardOnLock) {
        // Copy pixel data to somewhere accessible to 'C/C++'
        if (surfData.isFlagSet(0x00200000 /* SDL_HWPALETTE */)) {
          // If this is needed then
          // we should compact the data from 32bpp to 8bpp index.
          // I think best way to implement this is use
          // additional colorMap hash (color->index).
          // Something like this:
          //
          // var size = surfData.width * surfData.height;
          // var data = '';
          // for (var i = 0; i<size; i++) {
          //   var color = SDL.translateRGBAToColor(
          //     surfData.image.data[i*4   ],
          //     surfData.image.data[i*4 +1],
          //     surfData.image.data[i*4 +2],
          //     255);
          //   var index = surfData.colorMap[color];
          //   HEAP8[(surfData.buffer)+(i)] = index;
          // }
          throw 'CopyOnLock is not supported for SDL_LockSurface with SDL_HWPALETTE flag set' + new Error().stack;
        } else {
          HEAPU8.set(surfData.image.data, surfData.buffer);
        }
      }
  
      return 0;
    };
  
  var _SDL_FreeRW = (rwopsID) => {
      SDL.rwops[rwopsID] = null;
      while (SDL.rwops.length > 0 && SDL.rwops[SDL.rwops.length-1] === null) {
        SDL.rwops.pop();
      }
    };
  
  
  var initRandomFill = () => {
      if (typeof crypto == 'object' && typeof crypto['getRandomValues'] == 'function') {
        // for modern web browsers
        return (view) => crypto.getRandomValues(view);
      } else
      // we couldn't find a proper implementation, as Math.random() is not suitable for /dev/random, see emscripten-core/emscripten/pull/7096
      abort('no cryptographic support found for randomDevice. consider polyfilling it if you want to use something insecure like Math.random(), e.g. put this in a --pre-js: var crypto = { getRandomValues: (array) => { for (var i = 0; i < array.length; i++) array[i] = (Math.random()*256)|0 } };');
    };
  var randomFill = (view) => {
      // Lazily init on the first invocation.
      return (randomFill = initRandomFill())(view);
    };
  
  
  
  
  var UTF8Decoder = typeof TextDecoder != 'undefined' ? new TextDecoder() : undefined;
  
    /**
     * Given a pointer 'idx' to a null-terminated UTF8-encoded string in the given
     * array that contains uint8 values, returns a copy of that string as a
     * Javascript String object.
     * heapOrArray is either a regular array, or a JavaScript typed array view.
     * @param {number} idx
     * @param {number=} maxBytesToRead
     * @return {string}
     */
  var UTF8ArrayToString = (heapOrArray, idx, maxBytesToRead) => {
      var endIdx = idx + maxBytesToRead;
      var endPtr = idx;
      // TextDecoder needs to know the byte length in advance, it doesn't stop on
      // null terminator by itself.  Also, use the length info to avoid running tiny
      // strings through TextDecoder, since .subarray() allocates garbage.
      // (As a tiny code save trick, compare endPtr against endIdx using a negation,
      // so that undefined means Infinity)
      while (heapOrArray[endPtr] && !(endPtr >= endIdx)) ++endPtr;
  
      if (endPtr - idx > 16 && heapOrArray.buffer && UTF8Decoder) {
        return UTF8Decoder.decode(heapOrArray.subarray(idx, endPtr));
      }
      var str = '';
      // If building with TextDecoder, we have already computed the string length
      // above, so test loop end condition against that
      while (idx < endPtr) {
        // For UTF8 byte structure, see:
        // http://en.wikipedia.org/wiki/UTF-8#Description
        // https://www.ietf.org/rfc/rfc2279.txt
        // https://tools.ietf.org/html/rfc3629
        var u0 = heapOrArray[idx++];
        if (!(u0 & 0x80)) { str += String.fromCharCode(u0); continue; }
        var u1 = heapOrArray[idx++] & 63;
        if ((u0 & 0xE0) == 0xC0) { str += String.fromCharCode(((u0 & 31) << 6) | u1); continue; }
        var u2 = heapOrArray[idx++] & 63;
        if ((u0 & 0xF0) == 0xE0) {
          u0 = ((u0 & 15) << 12) | (u1 << 6) | u2;
        } else {
          if ((u0 & 0xF8) != 0xF0) warnOnce('Invalid UTF-8 leading byte ' + ptrToString(u0) + ' encountered when deserializing a UTF-8 string in wasm memory to a JS string!');
          u0 = ((u0 & 7) << 18) | (u1 << 12) | (u2 << 6) | (heapOrArray[idx++] & 63);
        }
  
        if (u0 < 0x10000) {
          str += String.fromCharCode(u0);
        } else {
          var ch = u0 - 0x10000;
          str += String.fromCharCode(0xD800 | (ch >> 10), 0xDC00 | (ch & 0x3FF));
        }
      }
      return str;
    };
  
  var FS_stdin_getChar_buffer = [];
  
  var FS_stdin_getChar = () => {
      if (!FS_stdin_getChar_buffer.length) {
        var result = null;
        if (typeof window != 'undefined' &&
          typeof window.prompt == 'function') {
          // Browser.
          result = window.prompt('Input: ');  // returns null on cancel
          if (result !== null) {
            result += '\n';
          }
        } else
        {}
        if (!result) {
          return null;
        }
        FS_stdin_getChar_buffer = intArrayFromString(result, true);
      }
      return FS_stdin_getChar_buffer.shift();
    };
  var TTY = {
  ttys:[],
  init() {
        // https://github.com/emscripten-core/emscripten/pull/1555
        // if (ENVIRONMENT_IS_NODE) {
        //   // currently, FS.init does not distinguish if process.stdin is a file or TTY
        //   // device, it always assumes it's a TTY device. because of this, we're forcing
        //   // process.stdin to UTF8 encoding to at least make stdin reading compatible
        //   // with text files until FS.init can be refactored.
        //   process.stdin.setEncoding('utf8');
        // }
      },
  shutdown() {
        // https://github.com/emscripten-core/emscripten/pull/1555
        // if (ENVIRONMENT_IS_NODE) {
        //   // inolen: any idea as to why node -e 'process.stdin.read()' wouldn't exit immediately (with process.stdin being a tty)?
        //   // isaacs: because now it's reading from the stream, you've expressed interest in it, so that read() kicks off a _read() which creates a ReadReq operation
        //   // inolen: I thought read() in that case was a synchronous operation that just grabbed some amount of buffered data if it exists?
        //   // isaacs: it is. but it also triggers a _read() call, which calls readStart() on the handle
        //   // isaacs: do process.stdin.pause() and i'd think it'd probably close the pending call
        //   process.stdin.pause();
        // }
      },
  register(dev, ops) {
        TTY.ttys[dev] = { input: [], output: [], ops: ops };
        FS.registerDevice(dev, TTY.stream_ops);
      },
  stream_ops:{
  open(stream) {
          var tty = TTY.ttys[stream.node.rdev];
          if (!tty) {
            throw new FS.ErrnoError(43);
          }
          stream.tty = tty;
          stream.seekable = false;
        },
  close(stream) {
          // flush any pending line data
          stream.tty.ops.fsync(stream.tty);
        },
  fsync(stream) {
          stream.tty.ops.fsync(stream.tty);
        },
  read(stream, buffer, offset, length, pos /* ignored */) {
          if (!stream.tty || !stream.tty.ops.get_char) {
            throw new FS.ErrnoError(60);
          }
          var bytesRead = 0;
          for (var i = 0; i < length; i++) {
            var result;
            try {
              result = stream.tty.ops.get_char(stream.tty);
            } catch (e) {
              throw new FS.ErrnoError(29);
            }
            if (result === undefined && bytesRead === 0) {
              throw new FS.ErrnoError(6);
            }
            if (result === null || result === undefined) break;
            bytesRead++;
            buffer[offset+i] = result;
          }
          if (bytesRead) {
            stream.node.timestamp = Date.now();
          }
          return bytesRead;
        },
  write(stream, buffer, offset, length, pos) {
          if (!stream.tty || !stream.tty.ops.put_char) {
            throw new FS.ErrnoError(60);
          }
          try {
            for (var i = 0; i < length; i++) {
              stream.tty.ops.put_char(stream.tty, buffer[offset+i]);
            }
          } catch (e) {
            throw new FS.ErrnoError(29);
          }
          if (length) {
            stream.node.timestamp = Date.now();
          }
          return i;
        },
  },
  default_tty_ops:{
  get_char(tty) {
          return FS_stdin_getChar();
        },
  put_char(tty, val) {
          if (val === null || val === 10) {
            out(UTF8ArrayToString(tty.output, 0));
            tty.output = [];
          } else {
            if (val != 0) tty.output.push(val); // val == 0 would cut text output off in the middle.
          }
        },
  fsync(tty) {
          if (tty.output && tty.output.length > 0) {
            out(UTF8ArrayToString(tty.output, 0));
            tty.output = [];
          }
        },
  ioctl_tcgets(tty) {
          // typical setting
          return {
            c_iflag: 25856,
            c_oflag: 5,
            c_cflag: 191,
            c_lflag: 35387,
            c_cc: [
              0x03, 0x1c, 0x7f, 0x15, 0x04, 0x00, 0x01, 0x00, 0x11, 0x13, 0x1a, 0x00,
              0x12, 0x0f, 0x17, 0x16, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
              0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            ]
          };
        },
  ioctl_tcsets(tty, optional_actions, data) {
          // currently just ignore
          return 0;
        },
  ioctl_tiocgwinsz(tty) {
          return [24, 80];
        },
  },
  default_tty1_ops:{
  put_char(tty, val) {
          if (val === null || val === 10) {
            err(UTF8ArrayToString(tty.output, 0));
            tty.output = [];
          } else {
            if (val != 0) tty.output.push(val);
          }
        },
  fsync(tty) {
          if (tty.output && tty.output.length > 0) {
            err(UTF8ArrayToString(tty.output, 0));
            tty.output = [];
          }
        },
  },
  };
  
  
  var zeroMemory = (address, size) => {
      HEAPU8.fill(0, address, address + size);
      return address;
    };
  
  var alignMemory = (size, alignment) => {
      assert(alignment, "alignment argument is required");
      return Math.ceil(size / alignment) * alignment;
    };
  var mmapAlloc = (size) => {
      abort('internal error: mmapAlloc called but `emscripten_builtin_memalign` native symbol not exported');
    };
  var MEMFS = {
  ops_table:null,
  mount(mount) {
        return MEMFS.createNode(null, '/', 16384 | 511 /* 0777 */, 0);
      },
  createNode(parent, name, mode, dev) {
        if (FS.isBlkdev(mode) || FS.isFIFO(mode)) {
          // no supported
          throw new FS.ErrnoError(63);
        }
        MEMFS.ops_table ||= {
          dir: {
            node: {
              getattr: MEMFS.node_ops.getattr,
              setattr: MEMFS.node_ops.setattr,
              lookup: MEMFS.node_ops.lookup,
              mknod: MEMFS.node_ops.mknod,
              rename: MEMFS.node_ops.rename,
              unlink: MEMFS.node_ops.unlink,
              rmdir: MEMFS.node_ops.rmdir,
              readdir: MEMFS.node_ops.readdir,
              symlink: MEMFS.node_ops.symlink
            },
            stream: {
              llseek: MEMFS.stream_ops.llseek
            }
          },
          file: {
            node: {
              getattr: MEMFS.node_ops.getattr,
              setattr: MEMFS.node_ops.setattr
            },
            stream: {
              llseek: MEMFS.stream_ops.llseek,
              read: MEMFS.stream_ops.read,
              write: MEMFS.stream_ops.write,
              allocate: MEMFS.stream_ops.allocate,
              mmap: MEMFS.stream_ops.mmap,
              msync: MEMFS.stream_ops.msync
            }
          },
          link: {
            node: {
              getattr: MEMFS.node_ops.getattr,
              setattr: MEMFS.node_ops.setattr,
              readlink: MEMFS.node_ops.readlink
            },
            stream: {}
          },
          chrdev: {
            node: {
              getattr: MEMFS.node_ops.getattr,
              setattr: MEMFS.node_ops.setattr
            },
            stream: FS.chrdev_stream_ops
          }
        };
        var node = FS.createNode(parent, name, mode, dev);
        if (FS.isDir(node.mode)) {
          node.node_ops = MEMFS.ops_table.dir.node;
          node.stream_ops = MEMFS.ops_table.dir.stream;
          node.contents = {};
        } else if (FS.isFile(node.mode)) {
          node.node_ops = MEMFS.ops_table.file.node;
          node.stream_ops = MEMFS.ops_table.file.stream;
          node.usedBytes = 0; // The actual number of bytes used in the typed array, as opposed to contents.length which gives the whole capacity.
          // When the byte data of the file is populated, this will point to either a typed array, or a normal JS array. Typed arrays are preferred
          // for performance, and used by default. However, typed arrays are not resizable like normal JS arrays are, so there is a small disk size
          // penalty involved for appending file writes that continuously grow a file similar to std::vector capacity vs used -scheme.
          node.contents = null; 
        } else if (FS.isLink(node.mode)) {
          node.node_ops = MEMFS.ops_table.link.node;
          node.stream_ops = MEMFS.ops_table.link.stream;
        } else if (FS.isChrdev(node.mode)) {
          node.node_ops = MEMFS.ops_table.chrdev.node;
          node.stream_ops = MEMFS.ops_table.chrdev.stream;
        }
        node.timestamp = Date.now();
        // add the new node to the parent
        if (parent) {
          parent.contents[name] = node;
          parent.timestamp = node.timestamp;
        }
        return node;
      },
  getFileDataAsTypedArray(node) {
        if (!node.contents) return new Uint8Array(0);
        if (node.contents.subarray) return node.contents.subarray(0, node.usedBytes); // Make sure to not return excess unused bytes.
        return new Uint8Array(node.contents);
      },
  expandFileStorage(node, newCapacity) {
        var prevCapacity = node.contents ? node.contents.length : 0;
        if (prevCapacity >= newCapacity) return; // No need to expand, the storage was already large enough.
        // Don't expand strictly to the given requested limit if it's only a very small increase, but instead geometrically grow capacity.
        // For small filesizes (<1MB), perform size*2 geometric increase, but for large sizes, do a much more conservative size*1.125 increase to
        // avoid overshooting the allocation cap by a very large margin.
        var CAPACITY_DOUBLING_MAX = 1024 * 1024;
        newCapacity = Math.max(newCapacity, (prevCapacity * (prevCapacity < CAPACITY_DOUBLING_MAX ? 2.0 : 1.125)) >>> 0);
        if (prevCapacity != 0) newCapacity = Math.max(newCapacity, 256); // At minimum allocate 256b for each file when expanding.
        var oldContents = node.contents;
        node.contents = new Uint8Array(newCapacity); // Allocate new storage.
        if (node.usedBytes > 0) node.contents.set(oldContents.subarray(0, node.usedBytes), 0); // Copy old data over to the new storage.
      },
  resizeFileStorage(node, newSize) {
        if (node.usedBytes == newSize) return;
        if (newSize == 0) {
          node.contents = null; // Fully decommit when requesting a resize to zero.
          node.usedBytes = 0;
        } else {
          var oldContents = node.contents;
          node.contents = new Uint8Array(newSize); // Allocate new storage.
          if (oldContents) {
            node.contents.set(oldContents.subarray(0, Math.min(newSize, node.usedBytes))); // Copy old data over to the new storage.
          }
          node.usedBytes = newSize;
        }
      },
  node_ops:{
  getattr(node) {
          var attr = {};
          // device numbers reuse inode numbers.
          attr.dev = FS.isChrdev(node.mode) ? node.id : 1;
          attr.ino = node.id;
          attr.mode = node.mode;
          attr.nlink = 1;
          attr.uid = 0;
          attr.gid = 0;
          attr.rdev = node.rdev;
          if (FS.isDir(node.mode)) {
            attr.size = 4096;
          } else if (FS.isFile(node.mode)) {
            attr.size = node.usedBytes;
          } else if (FS.isLink(node.mode)) {
            attr.size = node.link.length;
          } else {
            attr.size = 0;
          }
          attr.atime = new Date(node.timestamp);
          attr.mtime = new Date(node.timestamp);
          attr.ctime = new Date(node.timestamp);
          // NOTE: In our implementation, st_blocks = Math.ceil(st_size/st_blksize),
          //       but this is not required by the standard.
          attr.blksize = 4096;
          attr.blocks = Math.ceil(attr.size / attr.blksize);
          return attr;
        },
  setattr(node, attr) {
          if (attr.mode !== undefined) {
            node.mode = attr.mode;
          }
          if (attr.timestamp !== undefined) {
            node.timestamp = attr.timestamp;
          }
          if (attr.size !== undefined) {
            MEMFS.resizeFileStorage(node, attr.size);
          }
        },
  lookup(parent, name) {
          throw FS.genericErrors[44];
        },
  mknod(parent, name, mode, dev) {
          return MEMFS.createNode(parent, name, mode, dev);
        },
  rename(old_node, new_dir, new_name) {
          // if we're overwriting a directory at new_name, make sure it's empty.
          if (FS.isDir(old_node.mode)) {
            var new_node;
            try {
              new_node = FS.lookupNode(new_dir, new_name);
            } catch (e) {
            }
            if (new_node) {
              for (var i in new_node.contents) {
                throw new FS.ErrnoError(55);
              }
            }
          }
          // do the internal rewiring
          delete old_node.parent.contents[old_node.name];
          old_node.parent.timestamp = Date.now()
          old_node.name = new_name;
          new_dir.contents[new_name] = old_node;
          new_dir.timestamp = old_node.parent.timestamp;
        },
  unlink(parent, name) {
          delete parent.contents[name];
          parent.timestamp = Date.now();
        },
  rmdir(parent, name) {
          var node = FS.lookupNode(parent, name);
          for (var i in node.contents) {
            throw new FS.ErrnoError(55);
          }
          delete parent.contents[name];
          parent.timestamp = Date.now();
        },
  readdir(node) {
          var entries = ['.', '..'];
          for (var key of Object.keys(node.contents)) {
            entries.push(key);
          }
          return entries;
        },
  symlink(parent, newname, oldpath) {
          var node = MEMFS.createNode(parent, newname, 511 /* 0777 */ | 40960, 0);
          node.link = oldpath;
          return node;
        },
  readlink(node) {
          if (!FS.isLink(node.mode)) {
            throw new FS.ErrnoError(28);
          }
          return node.link;
        },
  },
  stream_ops:{
  read(stream, buffer, offset, length, position) {
          var contents = stream.node.contents;
          if (position >= stream.node.usedBytes) return 0;
          var size = Math.min(stream.node.usedBytes - position, length);
          assert(size >= 0);
          if (size > 8 && contents.subarray) { // non-trivial, and typed array
            buffer.set(contents.subarray(position, position + size), offset);
          } else {
            for (var i = 0; i < size; i++) buffer[offset + i] = contents[position + i];
          }
          return size;
        },
  write(stream, buffer, offset, length, position, canOwn) {
          // The data buffer should be a typed array view
          assert(!(buffer instanceof ArrayBuffer));
          // If the buffer is located in main memory (HEAP), and if
          // memory can grow, we can't hold on to references of the
          // memory buffer, as they may get invalidated. That means we
          // need to do copy its contents.
          if (buffer.buffer === HEAP8.buffer) {
            canOwn = false;
          }
  
          if (!length) return 0;
          var node = stream.node;
          node.timestamp = Date.now();
  
          if (buffer.subarray && (!node.contents || node.contents.subarray)) { // This write is from a typed array to a typed array?
            if (canOwn) {
              assert(position === 0, 'canOwn must imply no weird position inside the file');
              node.contents = buffer.subarray(offset, offset + length);
              node.usedBytes = length;
              return length;
            } else if (node.usedBytes === 0 && position === 0) { // If this is a simple first write to an empty file, do a fast set since we don't need to care about old data.
              node.contents = buffer.slice(offset, offset + length);
              node.usedBytes = length;
              return length;
            } else if (position + length <= node.usedBytes) { // Writing to an already allocated and used subrange of the file?
              node.contents.set(buffer.subarray(offset, offset + length), position);
              return length;
            }
          }
  
          // Appending to an existing file and we need to reallocate, or source data did not come as a typed array.
          MEMFS.expandFileStorage(node, position+length);
          if (node.contents.subarray && buffer.subarray) {
            // Use typed array write which is available.
            node.contents.set(buffer.subarray(offset, offset + length), position);
          } else {
            for (var i = 0; i < length; i++) {
             node.contents[position + i] = buffer[offset + i]; // Or fall back to manual write if not.
            }
          }
          node.usedBytes = Math.max(node.usedBytes, position + length);
          return length;
        },
  llseek(stream, offset, whence) {
          var position = offset;
          if (whence === 1) {
            position += stream.position;
          } else if (whence === 2) {
            if (FS.isFile(stream.node.mode)) {
              position += stream.node.usedBytes;
            }
          }
          if (position < 0) {
            throw new FS.ErrnoError(28);
          }
          return position;
        },
  allocate(stream, offset, length) {
          MEMFS.expandFileStorage(stream.node, offset + length);
          stream.node.usedBytes = Math.max(stream.node.usedBytes, offset + length);
        },
  mmap(stream, length, position, prot, flags) {
          if (!FS.isFile(stream.node.mode)) {
            throw new FS.ErrnoError(43);
          }
          var ptr;
          var allocated;
          var contents = stream.node.contents;
          // Only make a new copy when MAP_PRIVATE is specified.
          if (!(flags & 2) && contents.buffer === HEAP8.buffer) {
            // We can't emulate MAP_SHARED when the file is not backed by the
            // buffer we're mapping to (e.g. the HEAP buffer).
            allocated = false;
            ptr = contents.byteOffset;
          } else {
            // Try to avoid unnecessary slices.
            if (position > 0 || position + length < contents.length) {
              if (contents.subarray) {
                contents = contents.subarray(position, position + length);
              } else {
                contents = Array.prototype.slice.call(contents, position, position + length);
              }
            }
            allocated = true;
            ptr = mmapAlloc(length);
            if (!ptr) {
              throw new FS.ErrnoError(48);
            }
            HEAP8.set(contents, ptr);
          }
          return { ptr, allocated };
        },
  msync(stream, buffer, offset, length, mmapFlags) {
          MEMFS.stream_ops.write(stream, buffer, 0, length, offset, false);
          // should we check if bytesWritten and length are the same?
          return 0;
        },
  },
  };
  
  /** @param {boolean=} noRunDep */
  var asyncLoad = (url, onload, onerror, noRunDep) => {
      var dep = !noRunDep ? getUniqueRunDependency(`al ${url}`) : '';
      readAsync(url).then(
        (arrayBuffer) => {
          assert(arrayBuffer, `Loading data file "${url}" failed (no arrayBuffer).`);
          onload(new Uint8Array(arrayBuffer));
          if (dep) removeRunDependency(dep);
        },
        (err) => {
          if (onerror) {
            onerror();
          } else {
            throw `Loading data file "${url}" failed.`;
          }
        }
      );
      if (dep) addRunDependency(dep);
    };
  
  
  var FS_createDataFile = (parent, name, fileData, canRead, canWrite, canOwn) => {
      FS.createDataFile(parent, name, fileData, canRead, canWrite, canOwn);
    };
  
  var FS_handledByPreloadPlugin = (byteArray, fullname, finish, onerror) => {
      // Ensure plugins are ready.
      if (typeof Browser != 'undefined') Browser.init();
  
      var handled = false;
      preloadPlugins.forEach((plugin) => {
        if (handled) return;
        if (plugin['canHandle'](fullname)) {
          plugin['handle'](byteArray, fullname, finish, onerror);
          handled = true;
        }
      });
      return handled;
    };
  var FS_createPreloadedFile = (parent, name, url, canRead, canWrite, onload, onerror, dontCreateFile, canOwn, preFinish) => {
      // TODO we should allow people to just pass in a complete filename instead
      // of parent and name being that we just join them anyways
      var fullname = name ? PATH_FS.resolve(PATH.join2(parent, name)) : parent;
      var dep = getUniqueRunDependency(`cp ${fullname}`); // might have several active requests for the same fullname
      function processData(byteArray) {
        function finish(byteArray) {
          preFinish?.();
          if (!dontCreateFile) {
            FS_createDataFile(parent, name, byteArray, canRead, canWrite, canOwn);
          }
          onload?.();
          removeRunDependency(dep);
        }
        if (FS_handledByPreloadPlugin(byteArray, fullname, finish, () => {
          onerror?.();
          removeRunDependency(dep);
        })) {
          return;
        }
        finish(byteArray);
      }
      addRunDependency(dep);
      if (typeof url == 'string') {
        asyncLoad(url, processData, onerror);
      } else {
        processData(url);
      }
    };
  
  var FS_modeStringToFlags = (str) => {
      var flagModes = {
        'r': 0,
        'r+': 2,
        'w': 512 | 64 | 1,
        'w+': 512 | 64 | 2,
        'a': 1024 | 64 | 1,
        'a+': 1024 | 64 | 2,
      };
      var flags = flagModes[str];
      if (typeof flags == 'undefined') {
        throw new Error(`Unknown file open mode: ${str}`);
      }
      return flags;
    };
  
  var FS_getMode = (canRead, canWrite) => {
      var mode = 0;
      if (canRead) mode |= 292 | 73;
      if (canWrite) mode |= 146;
      return mode;
    };
  
  
  
  
  
  
  var IDBFS = {
  dbs:{
  },
  indexedDB:() => {
        if (typeof indexedDB != 'undefined') return indexedDB;
        var ret = null;
        if (typeof window == 'object') ret = window.indexedDB || window.mozIndexedDB || window.webkitIndexedDB || window.msIndexedDB;
        assert(ret, 'IDBFS used, but indexedDB not supported');
        return ret;
      },
  DB_VERSION:21,
  DB_STORE_NAME:"FILE_DATA",
  queuePersist:(mount) => {
        function onPersistComplete() {
          if (mount.idbPersistState === 'again') startPersist(); // If a new sync request has appeared in between, kick off a new sync
          else mount.idbPersistState = 0; // Otherwise reset sync state back to idle to wait for a new sync later
        }
        function startPersist() {
          mount.idbPersistState = 'idb'; // Mark that we are currently running a sync operation
          IDBFS.syncfs(mount, /*populate:*/false, onPersistComplete);
        }
  
        if (!mount.idbPersistState) {
          // Programs typically write/copy/move multiple files in the in-memory
          // filesystem within a single app frame, so when a filesystem sync
          // command is triggered, do not start it immediately, but only after
          // the current frame is finished. This way all the modified files
          // inside the main loop tick will be batched up to the same sync.
          mount.idbPersistState = setTimeout(startPersist, 0);
        } else if (mount.idbPersistState === 'idb') {
          // There is an active IndexedDB sync operation in-flight, but we now
          // have accumulated more files to sync. We should therefore queue up
          // a new sync after the current one finishes so that all writes
          // will be properly persisted.
          mount.idbPersistState = 'again';
        }
      },
  mount:(mount) => {
        // reuse core MEMFS functionality
        var mnt = MEMFS.mount(mount);
        // If the automatic IDBFS persistence option has been selected, then automatically persist
        // all modifications to the filesystem as they occur.
        if (mount?.opts?.autoPersist) {
          mnt.idbPersistState = 0; // IndexedDB sync starts in idle state
          var memfs_node_ops = mnt.node_ops;
          mnt.node_ops = Object.assign({}, mnt.node_ops); // Clone node_ops to inject write tracking
          mnt.node_ops.mknod = (parent, name, mode, dev) => {
            var node = memfs_node_ops.mknod(parent, name, mode, dev);
            // Propagate injected node_ops to the newly created child node
            node.node_ops = mnt.node_ops;
            // Remember for each IDBFS node which IDBFS mount point they came from so we know which mount to persist on modification.
            node.idbfs_mount = mnt.mount;
            // Remember original MEMFS stream_ops for this node
            node.memfs_stream_ops = node.stream_ops;
            // Clone stream_ops to inject write tracking
            node.stream_ops = Object.assign({}, node.stream_ops);
  
            // Track all file writes
            node.stream_ops.write = (stream, buffer, offset, length, position, canOwn) => {
              // This file has been modified, we must persist IndexedDB when this file closes
              stream.node.isModified = true;
              return node.memfs_stream_ops.write(stream, buffer, offset, length, position, canOwn);
            };
  
            // Persist IndexedDB on file close
            node.stream_ops.close = (stream) => {
              var n = stream.node;
              if (n.isModified) {
                IDBFS.queuePersist(n.idbfs_mount);
                n.isModified = false;
              }
              if (n.memfs_stream_ops.close) return n.memfs_stream_ops.close(stream);
            };
  
            return node;
          };
          // Also kick off persisting the filesystem on other operations that modify the filesystem.
          mnt.node_ops.mkdir   = (...args) => (IDBFS.queuePersist(mnt.mount), memfs_node_ops.mkdir(...args));
          mnt.node_ops.rmdir   = (...args) => (IDBFS.queuePersist(mnt.mount), memfs_node_ops.rmdir(...args));
          mnt.node_ops.symlink = (...args) => (IDBFS.queuePersist(mnt.mount), memfs_node_ops.symlink(...args));
          mnt.node_ops.unlink  = (...args) => (IDBFS.queuePersist(mnt.mount), memfs_node_ops.unlink(...args));
          mnt.node_ops.rename  = (...args) => (IDBFS.queuePersist(mnt.mount), memfs_node_ops.rename(...args));
        }
        return mnt;
      },
  syncfs:(mount, populate, callback) => {
        IDBFS.getLocalSet(mount, (err, local) => {
          if (err) return callback(err);
  
          IDBFS.getRemoteSet(mount, (err, remote) => {
            if (err) return callback(err);
  
            var src = populate ? remote : local;
            var dst = populate ? local : remote;
  
            IDBFS.reconcile(src, dst, callback);
          });
        });
      },
  quit:() => {
        Object.values(IDBFS.dbs).forEach((value) => value.close());
        IDBFS.dbs = {};
      },
  getDB:(name, callback) => {
        // check the cache first
        var db = IDBFS.dbs[name];
        if (db) {
          return callback(null, db);
        }
  
        var req;
        try {
          req = IDBFS.indexedDB().open(name, IDBFS.DB_VERSION);
        } catch (e) {
          return callback(e);
        }
        if (!req) {
          return callback("Unable to connect to IndexedDB");
        }
        req.onupgradeneeded = (e) => {
          var db = /** @type {IDBDatabase} */ (e.target.result);
          var transaction = e.target.transaction;
  
          var fileStore;
  
          if (db.objectStoreNames.contains(IDBFS.DB_STORE_NAME)) {
            fileStore = transaction.objectStore(IDBFS.DB_STORE_NAME);
          } else {
            fileStore = db.createObjectStore(IDBFS.DB_STORE_NAME);
          }
  
          if (!fileStore.indexNames.contains('timestamp')) {
            fileStore.createIndex('timestamp', 'timestamp', { unique: false });
          }
        };
        req.onsuccess = () => {
          db = /** @type {IDBDatabase} */ (req.result);
  
          // add to the cache
          IDBFS.dbs[name] = db;
          callback(null, db);
        };
        req.onerror = (e) => {
          callback(e.target.error);
          e.preventDefault();
        };
      },
  getLocalSet:(mount, callback) => {
        var entries = {};
  
        function isRealDir(p) {
          return p !== '.' && p !== '..';
        };
        function toAbsolute(root) {
          return (p) => PATH.join2(root, p);
        };
  
        var check = FS.readdir(mount.mountpoint).filter(isRealDir).map(toAbsolute(mount.mountpoint));
  
        while (check.length) {
          var path = check.pop();
          var stat;
  
          try {
            stat = FS.stat(path);
          } catch (e) {
            return callback(e);
          }
  
          if (FS.isDir(stat.mode)) {
            check.push(...FS.readdir(path).filter(isRealDir).map(toAbsolute(path)));
          }
  
          entries[path] = { 'timestamp': stat.mtime };
        }
  
        return callback(null, { type: 'local', entries: entries });
      },
  getRemoteSet:(mount, callback) => {
        var entries = {};
  
        IDBFS.getDB(mount.mountpoint, (err, db) => {
          if (err) return callback(err);
  
          try {
            var transaction = db.transaction([IDBFS.DB_STORE_NAME], 'readonly');
            transaction.onerror = (e) => {
              callback(e.target.error);
              e.preventDefault();
            };
  
            var store = transaction.objectStore(IDBFS.DB_STORE_NAME);
            var index = store.index('timestamp');
  
            index.openKeyCursor().onsuccess = (event) => {
              var cursor = event.target.result;
  
              if (!cursor) {
                return callback(null, { type: 'remote', db, entries });
              }
  
              entries[cursor.primaryKey] = { 'timestamp': cursor.key };
  
              cursor.continue();
            };
          } catch (e) {
            return callback(e);
          }
        });
      },
  loadLocalEntry:(path, callback) => {
        var stat, node;
  
        try {
          var lookup = FS.lookupPath(path);
          node = lookup.node;
          stat = FS.stat(path);
        } catch (e) {
          return callback(e);
        }
  
        if (FS.isDir(stat.mode)) {
          return callback(null, { 'timestamp': stat.mtime, 'mode': stat.mode });
        } else if (FS.isFile(stat.mode)) {
          // Performance consideration: storing a normal JavaScript array to a IndexedDB is much slower than storing a typed array.
          // Therefore always convert the file contents to a typed array first before writing the data to IndexedDB.
          node.contents = MEMFS.getFileDataAsTypedArray(node);
          return callback(null, { 'timestamp': stat.mtime, 'mode': stat.mode, 'contents': node.contents });
        } else {
          return callback(new Error('node type not supported'));
        }
      },
  storeLocalEntry:(path, entry, callback) => {
        try {
          if (FS.isDir(entry['mode'])) {
            FS.mkdirTree(path, entry['mode']);
          } else if (FS.isFile(entry['mode'])) {
            FS.writeFile(path, entry['contents'], { canOwn: true });
          } else {
            return callback(new Error('node type not supported'));
          }
  
          FS.chmod(path, entry['mode']);
          FS.utime(path, entry['timestamp'], entry['timestamp']);
        } catch (e) {
          return callback(e);
        }
  
        callback(null);
      },
  removeLocalEntry:(path, callback) => {
        try {
          var stat = FS.stat(path);
  
          if (FS.isDir(stat.mode)) {
            FS.rmdir(path);
          } else if (FS.isFile(stat.mode)) {
            FS.unlink(path);
          }
        } catch (e) {
          return callback(e);
        }
  
        callback(null);
      },
  loadRemoteEntry:(store, path, callback) => {
        var req = store.get(path);
        req.onsuccess = (event) => callback(null, event.target.result);
        req.onerror = (e) => {
          callback(e.target.error);
          e.preventDefault();
        };
      },
  storeRemoteEntry:(store, path, entry, callback) => {
        try {
          var req = store.put(entry, path);
        } catch (e) {
          callback(e);
          return;
        }
        req.onsuccess = (event) => callback();
        req.onerror = (e) => {
          callback(e.target.error);
          e.preventDefault();
        };
      },
  removeRemoteEntry:(store, path, callback) => {
        var req = store.delete(path);
        req.onsuccess = (event) => callback();
        req.onerror = (e) => {
          callback(e.target.error);
          e.preventDefault();
        };
      },
  reconcile:(src, dst, callback) => {
        var total = 0;
  
        var create = [];
        Object.keys(src.entries).forEach(function (key) {
          var e = src.entries[key];
          var e2 = dst.entries[key];
          if (!e2 || e['timestamp'].getTime() != e2['timestamp'].getTime()) {
            create.push(key);
            total++;
          }
        });
  
        var remove = [];
        Object.keys(dst.entries).forEach(function (key) {
          if (!src.entries[key]) {
            remove.push(key);
            total++;
          }
        });
  
        if (!total) {
          return callback(null);
        }
  
        var errored = false;
        var db = src.type === 'remote' ? src.db : dst.db;
        var transaction = db.transaction([IDBFS.DB_STORE_NAME], 'readwrite');
        var store = transaction.objectStore(IDBFS.DB_STORE_NAME);
  
        function done(err) {
          if (err && !errored) {
            errored = true;
            return callback(err);
          }
        };
  
        // transaction may abort if (for example) there is a QuotaExceededError
        transaction.onerror = transaction.onabort = (e) => {
          done(e.target.error);
          e.preventDefault();
        };
  
        transaction.oncomplete = (e) => {
          if (!errored) {
            callback(null);
          }
        };
  
        // sort paths in ascending order so directory entries are created
        // before the files inside them
        create.sort().forEach((path) => {
          if (dst.type === 'local') {
            IDBFS.loadRemoteEntry(store, path, (err, entry) => {
              if (err) return done(err);
              IDBFS.storeLocalEntry(path, entry, done);
            });
          } else {
            IDBFS.loadLocalEntry(path, (err, entry) => {
              if (err) return done(err);
              IDBFS.storeRemoteEntry(store, path, entry, done);
            });
          }
        });
  
        // sort paths in descending order so files are deleted before their
        // parent directories
        remove.sort().reverse().forEach((path) => {
          if (dst.type === 'local') {
            IDBFS.removeLocalEntry(path, done);
          } else {
            IDBFS.removeRemoteEntry(store, path, done);
          }
        });
      },
  };
  
  
  
    /**
     * Given a pointer 'ptr' to a null-terminated UTF8-encoded string in the
     * emscripten HEAP, returns a copy of that string as a Javascript String object.
     *
     * @param {number} ptr
     * @param {number=} maxBytesToRead - An optional length that specifies the
     *   maximum number of bytes to read. You can omit this parameter to scan the
     *   string until the first 0 byte. If maxBytesToRead is passed, and the string
     *   at [ptr, ptr+maxBytesToReadr[ contains a null byte in the middle, then the
     *   string will cut short at that byte index (i.e. maxBytesToRead will not
     *   produce a string of exact length [ptr, ptr+maxBytesToRead[) N.B. mixing
     *   frequent uses of UTF8ToString() with and without maxBytesToRead may throw
     *   JS JIT optimizations off, so it is worth to consider consistently using one
     * @return {string}
     */
  var UTF8ToString = (ptr, maxBytesToRead) => {
      assert(typeof ptr == 'number', `UTF8ToString expects a number (got ${typeof ptr})`);
      return ptr ? UTF8ArrayToString(HEAPU8, ptr, maxBytesToRead) : '';
    };
  
  var strError = (errno) => {
      return UTF8ToString(_strerror(errno));
    };
  
  var ERRNO_CODES = {
      'EPERM': 63,
      'ENOENT': 44,
      'ESRCH': 71,
      'EINTR': 27,
      'EIO': 29,
      'ENXIO': 60,
      'E2BIG': 1,
      'ENOEXEC': 45,
      'EBADF': 8,
      'ECHILD': 12,
      'EAGAIN': 6,
      'EWOULDBLOCK': 6,
      'ENOMEM': 48,
      'EACCES': 2,
      'EFAULT': 21,
      'ENOTBLK': 105,
      'EBUSY': 10,
      'EEXIST': 20,
      'EXDEV': 75,
      'ENODEV': 43,
      'ENOTDIR': 54,
      'EISDIR': 31,
      'EINVAL': 28,
      'ENFILE': 41,
      'EMFILE': 33,
      'ENOTTY': 59,
      'ETXTBSY': 74,
      'EFBIG': 22,
      'ENOSPC': 51,
      'ESPIPE': 70,
      'EROFS': 69,
      'EMLINK': 34,
      'EPIPE': 64,
      'EDOM': 18,
      'ERANGE': 68,
      'ENOMSG': 49,
      'EIDRM': 24,
      'ECHRNG': 106,
      'EL2NSYNC': 156,
      'EL3HLT': 107,
      'EL3RST': 108,
      'ELNRNG': 109,
      'EUNATCH': 110,
      'ENOCSI': 111,
      'EL2HLT': 112,
      'EDEADLK': 16,
      'ENOLCK': 46,
      'EBADE': 113,
      'EBADR': 114,
      'EXFULL': 115,
      'ENOANO': 104,
      'EBADRQC': 103,
      'EBADSLT': 102,
      'EDEADLOCK': 16,
      'EBFONT': 101,
      'ENOSTR': 100,
      'ENODATA': 116,
      'ETIME': 117,
      'ENOSR': 118,
      'ENONET': 119,
      'ENOPKG': 120,
      'EREMOTE': 121,
      'ENOLINK': 47,
      'EADV': 122,
      'ESRMNT': 123,
      'ECOMM': 124,
      'EPROTO': 65,
      'EMULTIHOP': 36,
      'EDOTDOT': 125,
      'EBADMSG': 9,
      'ENOTUNIQ': 126,
      'EBADFD': 127,
      'EREMCHG': 128,
      'ELIBACC': 129,
      'ELIBBAD': 130,
      'ELIBSCN': 131,
      'ELIBMAX': 132,
      'ELIBEXEC': 133,
      'ENOSYS': 52,
      'ENOTEMPTY': 55,
      'ENAMETOOLONG': 37,
      'ELOOP': 32,
      'EOPNOTSUPP': 138,
      'EPFNOSUPPORT': 139,
      'ECONNRESET': 15,
      'ENOBUFS': 42,
      'EAFNOSUPPORT': 5,
      'EPROTOTYPE': 67,
      'ENOTSOCK': 57,
      'ENOPROTOOPT': 50,
      'ESHUTDOWN': 140,
      'ECONNREFUSED': 14,
      'EADDRINUSE': 3,
      'ECONNABORTED': 13,
      'ENETUNREACH': 40,
      'ENETDOWN': 38,
      'ETIMEDOUT': 73,
      'EHOSTDOWN': 142,
      'EHOSTUNREACH': 23,
      'EINPROGRESS': 26,
      'EALREADY': 7,
      'EDESTADDRREQ': 17,
      'EMSGSIZE': 35,
      'EPROTONOSUPPORT': 66,
      'ESOCKTNOSUPPORT': 137,
      'EADDRNOTAVAIL': 4,
      'ENETRESET': 39,
      'EISCONN': 30,
      'ENOTCONN': 53,
      'ETOOMANYREFS': 141,
      'EUSERS': 136,
      'EDQUOT': 19,
      'ESTALE': 72,
      'ENOTSUP': 138,
      'ENOMEDIUM': 148,
      'EILSEQ': 25,
      'EOVERFLOW': 61,
      'ECANCELED': 11,
      'ENOTRECOVERABLE': 56,
      'EOWNERDEAD': 62,
      'ESTRPIPE': 135,
    };
  var FS = {
  root:null,
  mounts:[],
  devices:{
  },
  streams:[],
  nextInode:1,
  nameTable:null,
  currentPath:"/",
  initialized:false,
  ignorePermissions:true,
  ErrnoError:class extends Error {
        // We set the `name` property to be able to identify `FS.ErrnoError`
        // - the `name` is a standard ECMA-262 property of error objects. Kind of good to have it anyway.
        // - when using PROXYFS, an error can come from an underlying FS
        // as different FS objects have their own FS.ErrnoError each,
        // the test `err instanceof FS.ErrnoError` won't detect an error coming from another filesystem, causing bugs.
        // we'll use the reliable test `err.name == "ErrnoError"` instead
        constructor(errno) {
          super(runtimeInitialized ? strError(errno) : '');
          // TODO(sbc): Use the inline member declaration syntax once we
          // support it in acorn and closure.
          this.name = 'ErrnoError';
          this.errno = errno;
          for (var key in ERRNO_CODES) {
            if (ERRNO_CODES[key] === errno) {
              this.code = key;
              break;
            }
          }
        }
      },
  genericErrors:{
  },
  filesystems:null,
  syncFSRequests:0,
  FSStream:class {
        constructor() {
          // TODO(https://github.com/emscripten-core/emscripten/issues/21414):
          // Use inline field declarations.
          this.shared = {};
        }
        get object() {
          return this.node;
        }
        set object(val) {
          this.node = val;
        }
        get isRead() {
          return (this.flags & 2097155) !== 1;
        }
        get isWrite() {
          return (this.flags & 2097155) !== 0;
        }
        get isAppend() {
          return (this.flags & 1024);
        }
        get flags() {
          return this.shared.flags;
        }
        set flags(val) {
          this.shared.flags = val;
        }
        get position() {
          return this.shared.position;
        }
        set position(val) {
          this.shared.position = val;
        }
      },
  FSNode:class {
        constructor(parent, name, mode, rdev) {
          if (!parent) {
            parent = this;  // root node sets parent to itself
          }
          this.parent = parent;
          this.mount = parent.mount;
          this.mounted = null;
          this.id = FS.nextInode++;
          this.name = name;
          this.mode = mode;
          this.node_ops = {};
          this.stream_ops = {};
          this.rdev = rdev;
          this.readMode = 292/*292*/ | 73/*73*/;
          this.writeMode = 146/*146*/;
        }
        get read() {
          return (this.mode & this.readMode) === this.readMode;
        }
        set read(val) {
          val ? this.mode |= this.readMode : this.mode &= ~this.readMode;
        }
        get write() {
          return (this.mode & this.writeMode) === this.writeMode;
        }
        set write(val) {
          val ? this.mode |= this.writeMode : this.mode &= ~this.writeMode;
        }
        get isFolder() {
          return FS.isDir(this.mode);
        }
        get isDevice() {
          return FS.isChrdev(this.mode);
        }
      },
  lookupPath(path, opts = {}) {
        path = PATH_FS.resolve(path);
  
        if (!path) return { path: '', node: null };
  
        var defaults = {
          follow_mount: true,
          recurse_count: 0
        };
        opts = Object.assign(defaults, opts)
  
        if (opts.recurse_count > 8) {  // max recursive lookup of 8
          throw new FS.ErrnoError(32);
        }
  
        // split the absolute path
        var parts = path.split('/').filter((p) => !!p);
  
        // start at the root
        var current = FS.root;
        var current_path = '/';
  
        for (var i = 0; i < parts.length; i++) {
          var islast = (i === parts.length-1);
          if (islast && opts.parent) {
            // stop resolving
            break;
          }
  
          current = FS.lookupNode(current, parts[i]);
          current_path = PATH.join2(current_path, parts[i]);
  
          // jump to the mount's root node if this is a mountpoint
          if (FS.isMountpoint(current)) {
            if (!islast || (islast && opts.follow_mount)) {
              current = current.mounted.root;
            }
          }
  
          // by default, lookupPath will not follow a symlink if it is the final path component.
          // setting opts.follow = true will override this behavior.
          if (!islast || opts.follow) {
            var count = 0;
            while (FS.isLink(current.mode)) {
              var link = FS.readlink(current_path);
              current_path = PATH_FS.resolve(PATH.dirname(current_path), link);
  
              var lookup = FS.lookupPath(current_path, { recurse_count: opts.recurse_count + 1 });
              current = lookup.node;
  
              if (count++ > 40) {  // limit max consecutive symlinks to 40 (SYMLOOP_MAX).
                throw new FS.ErrnoError(32);
              }
            }
          }
        }
  
        return { path: current_path, node: current };
      },
  getPath(node) {
        var path;
        while (true) {
          if (FS.isRoot(node)) {
            var mount = node.mount.mountpoint;
            if (!path) return mount;
            return mount[mount.length-1] !== '/' ? `${mount}/${path}` : mount + path;
          }
          path = path ? `${node.name}/${path}` : node.name;
          node = node.parent;
        }
      },
  hashName(parentid, name) {
        var hash = 0;
  
        for (var i = 0; i < name.length; i++) {
          hash = ((hash << 5) - hash + name.charCodeAt(i)) | 0;
        }
        return ((parentid + hash) >>> 0) % FS.nameTable.length;
      },
  hashAddNode(node) {
        var hash = FS.hashName(node.parent.id, node.name);
        node.name_next = FS.nameTable[hash];
        FS.nameTable[hash] = node;
      },
  hashRemoveNode(node) {
        var hash = FS.hashName(node.parent.id, node.name);
        if (FS.nameTable[hash] === node) {
          FS.nameTable[hash] = node.name_next;
        } else {
          var current = FS.nameTable[hash];
          while (current) {
            if (current.name_next === node) {
              current.name_next = node.name_next;
              break;
            }
            current = current.name_next;
          }
        }
      },
  lookupNode(parent, name) {
        var errCode = FS.mayLookup(parent);
        if (errCode) {
          throw new FS.ErrnoError(errCode);
        }
        var hash = FS.hashName(parent.id, name);
        for (var node = FS.nameTable[hash]; node; node = node.name_next) {
          var nodeName = node.name;
          if (node.parent.id === parent.id && nodeName === name) {
            return node;
          }
        }
        // if we failed to find it in the cache, call into the VFS
        return FS.lookup(parent, name);
      },
  createNode(parent, name, mode, rdev) {
        assert(typeof parent == 'object')
        var node = new FS.FSNode(parent, name, mode, rdev);
  
        FS.hashAddNode(node);
  
        return node;
      },
  destroyNode(node) {
        FS.hashRemoveNode(node);
      },
  isRoot(node) {
        return node === node.parent;
      },
  isMountpoint(node) {
        return !!node.mounted;
      },
  isFile(mode) {
        return (mode & 61440) === 32768;
      },
  isDir(mode) {
        return (mode & 61440) === 16384;
      },
  isLink(mode) {
        return (mode & 61440) === 40960;
      },
  isChrdev(mode) {
        return (mode & 61440) === 8192;
      },
  isBlkdev(mode) {
        return (mode & 61440) === 24576;
      },
  isFIFO(mode) {
        return (mode & 61440) === 4096;
      },
  isSocket(mode) {
        return (mode & 49152) === 49152;
      },
  flagsToPermissionString(flag) {
        var perms = ['r', 'w', 'rw'][flag & 3];
        if ((flag & 512)) {
          perms += 'w';
        }
        return perms;
      },
  nodePermissions(node, perms) {
        if (FS.ignorePermissions) {
          return 0;
        }
        // return 0 if any user, group or owner bits are set.
        if (perms.includes('r') && !(node.mode & 292)) {
          return 2;
        } else if (perms.includes('w') && !(node.mode & 146)) {
          return 2;
        } else if (perms.includes('x') && !(node.mode & 73)) {
          return 2;
        }
        return 0;
      },
  mayLookup(dir) {
        if (!FS.isDir(dir.mode)) return 54;
        var errCode = FS.nodePermissions(dir, 'x');
        if (errCode) return errCode;
        if (!dir.node_ops.lookup) return 2;
        return 0;
      },
  mayCreate(dir, name) {
        try {
          var node = FS.lookupNode(dir, name);
          return 20;
        } catch (e) {
        }
        return FS.nodePermissions(dir, 'wx');
      },
  mayDelete(dir, name, isdir) {
        var node;
        try {
          node = FS.lookupNode(dir, name);
        } catch (e) {
          return e.errno;
        }
        var errCode = FS.nodePermissions(dir, 'wx');
        if (errCode) {
          return errCode;
        }
        if (isdir) {
          if (!FS.isDir(node.mode)) {
            return 54;
          }
          if (FS.isRoot(node) || FS.getPath(node) === FS.cwd()) {
            return 10;
          }
        } else {
          if (FS.isDir(node.mode)) {
            return 31;
          }
        }
        return 0;
      },
  mayOpen(node, flags) {
        if (!node) {
          return 44;
        }
        if (FS.isLink(node.mode)) {
          return 32;
        } else if (FS.isDir(node.mode)) {
          if (FS.flagsToPermissionString(flags) !== 'r' || // opening for write
              (flags & 512)) { // TODO: check for O_SEARCH? (== search for dir only)
            return 31;
          }
        }
        return FS.nodePermissions(node, FS.flagsToPermissionString(flags));
      },
  MAX_OPEN_FDS:4096,
  nextfd() {
        for (var fd = 0; fd <= FS.MAX_OPEN_FDS; fd++) {
          if (!FS.streams[fd]) {
            return fd;
          }
        }
        throw new FS.ErrnoError(33);
      },
  getStreamChecked(fd) {
        var stream = FS.getStream(fd);
        if (!stream) {
          throw new FS.ErrnoError(8);
        }
        return stream;
      },
  getStream:(fd) => FS.streams[fd],
  createStream(stream, fd = -1) {
        assert(fd >= -1);
  
        // clone it, so we can return an instance of FSStream
        stream = Object.assign(new FS.FSStream(), stream);
        if (fd == -1) {
          fd = FS.nextfd();
        }
        stream.fd = fd;
        FS.streams[fd] = stream;
        return stream;
      },
  closeStream(fd) {
        FS.streams[fd] = null;
      },
  dupStream(origStream, fd = -1) {
        var stream = FS.createStream(origStream, fd);
        stream.stream_ops?.dup?.(stream);
        return stream;
      },
  chrdev_stream_ops:{
  open(stream) {
          var device = FS.getDevice(stream.node.rdev);
          // override node's stream ops with the device's
          stream.stream_ops = device.stream_ops;
          // forward the open call
          stream.stream_ops.open?.(stream);
        },
  llseek() {
          throw new FS.ErrnoError(70);
        },
  },
  major:(dev) => ((dev) >> 8),
  minor:(dev) => ((dev) & 0xff),
  makedev:(ma, mi) => ((ma) << 8 | (mi)),
  registerDevice(dev, ops) {
        FS.devices[dev] = { stream_ops: ops };
      },
  getDevice:(dev) => FS.devices[dev],
  getMounts(mount) {
        var mounts = [];
        var check = [mount];
  
        while (check.length) {
          var m = check.pop();
  
          mounts.push(m);
  
          check.push(...m.mounts);
        }
  
        return mounts;
      },
  syncfs(populate, callback) {
        if (typeof populate == 'function') {
          callback = populate;
          populate = false;
        }
  
        FS.syncFSRequests++;
  
        if (FS.syncFSRequests > 1) {
          err(`warning: ${FS.syncFSRequests} FS.syncfs operations in flight at once, probably just doing extra work`);
        }
  
        var mounts = FS.getMounts(FS.root.mount);
        var completed = 0;
  
        function doCallback(errCode) {
          assert(FS.syncFSRequests > 0);
          FS.syncFSRequests--;
          return callback(errCode);
        }
  
        function done(errCode) {
          if (errCode) {
            if (!done.errored) {
              done.errored = true;
              return doCallback(errCode);
            }
            return;
          }
          if (++completed >= mounts.length) {
            doCallback(null);
          }
        };
  
        // sync all mounts
        mounts.forEach((mount) => {
          if (!mount.type.syncfs) {
            return done(null);
          }
          mount.type.syncfs(mount, populate, done);
        });
      },
  mount(type, opts, mountpoint) {
        if (typeof type == 'string') {
          // The filesystem was not included, and instead we have an error
          // message stored in the variable.
          throw type;
        }
        var root = mountpoint === '/';
        var pseudo = !mountpoint;
        var node;
  
        if (root && FS.root) {
          throw new FS.ErrnoError(10);
        } else if (!root && !pseudo) {
          var lookup = FS.lookupPath(mountpoint, { follow_mount: false });
  
          mountpoint = lookup.path;  // use the absolute path
          node = lookup.node;
  
          if (FS.isMountpoint(node)) {
            throw new FS.ErrnoError(10);
          }
  
          if (!FS.isDir(node.mode)) {
            throw new FS.ErrnoError(54);
          }
        }
  
        var mount = {
          type,
          opts,
          mountpoint,
          mounts: []
        };
  
        // create a root node for the fs
        var mountRoot = type.mount(mount);
        mountRoot.mount = mount;
        mount.root = mountRoot;
  
        if (root) {
          FS.root = mountRoot;
        } else if (node) {
          // set as a mountpoint
          node.mounted = mount;
  
          // add the new mount to the current mount's children
          if (node.mount) {
            node.mount.mounts.push(mount);
          }
        }
  
        return mountRoot;
      },
  unmount(mountpoint) {
        var lookup = FS.lookupPath(mountpoint, { follow_mount: false });
  
        if (!FS.isMountpoint(lookup.node)) {
          throw new FS.ErrnoError(28);
        }
  
        // destroy the nodes for this mount, and all its child mounts
        var node = lookup.node;
        var mount = node.mounted;
        var mounts = FS.getMounts(mount);
  
        Object.keys(FS.nameTable).forEach((hash) => {
          var current = FS.nameTable[hash];
  
          while (current) {
            var next = current.name_next;
  
            if (mounts.includes(current.mount)) {
              FS.destroyNode(current);
            }
  
            current = next;
          }
        });
  
        // no longer a mountpoint
        node.mounted = null;
  
        // remove this mount from the child mounts
        var idx = node.mount.mounts.indexOf(mount);
        assert(idx !== -1);
        node.mount.mounts.splice(idx, 1);
      },
  lookup(parent, name) {
        return parent.node_ops.lookup(parent, name);
      },
  mknod(path, mode, dev) {
        var lookup = FS.lookupPath(path, { parent: true });
        var parent = lookup.node;
        var name = PATH.basename(path);
        if (!name || name === '.' || name === '..') {
          throw new FS.ErrnoError(28);
        }
        var errCode = FS.mayCreate(parent, name);
        if (errCode) {
          throw new FS.ErrnoError(errCode);
        }
        if (!parent.node_ops.mknod) {
          throw new FS.ErrnoError(63);
        }
        return parent.node_ops.mknod(parent, name, mode, dev);
      },
  create(path, mode) {
        mode = mode !== undefined ? mode : 438 /* 0666 */;
        mode &= 4095;
        mode |= 32768;
        return FS.mknod(path, mode, 0);
      },
  mkdir(path, mode) {
        mode = mode !== undefined ? mode : 511 /* 0777 */;
        mode &= 511 | 512;
        mode |= 16384;
        return FS.mknod(path, mode, 0);
      },
  mkdirTree(path, mode) {
        var dirs = path.split('/');
        var d = '';
        for (var i = 0; i < dirs.length; ++i) {
          if (!dirs[i]) continue;
          d += '/' + dirs[i];
          try {
            FS.mkdir(d, mode);
          } catch(e) {
            if (e.errno != 20) throw e;
          }
        }
      },
  mkdev(path, mode, dev) {
        if (typeof dev == 'undefined') {
          dev = mode;
          mode = 438 /* 0666 */;
        }
        mode |= 8192;
        return FS.mknod(path, mode, dev);
      },
  symlink(oldpath, newpath) {
        if (!PATH_FS.resolve(oldpath)) {
          throw new FS.ErrnoError(44);
        }
        var lookup = FS.lookupPath(newpath, { parent: true });
        var parent = lookup.node;
        if (!parent) {
          throw new FS.ErrnoError(44);
        }
        var newname = PATH.basename(newpath);
        var errCode = FS.mayCreate(parent, newname);
        if (errCode) {
          throw new FS.ErrnoError(errCode);
        }
        if (!parent.node_ops.symlink) {
          throw new FS.ErrnoError(63);
        }
        return parent.node_ops.symlink(parent, newname, oldpath);
      },
  rename(old_path, new_path) {
        var old_dirname = PATH.dirname(old_path);
        var new_dirname = PATH.dirname(new_path);
        var old_name = PATH.basename(old_path);
        var new_name = PATH.basename(new_path);
        // parents must exist
        var lookup, old_dir, new_dir;
  
        // let the errors from non existent directories percolate up
        lookup = FS.lookupPath(old_path, { parent: true });
        old_dir = lookup.node;
        lookup = FS.lookupPath(new_path, { parent: true });
        new_dir = lookup.node;
  
        if (!old_dir || !new_dir) throw new FS.ErrnoError(44);
        // need to be part of the same mount
        if (old_dir.mount !== new_dir.mount) {
          throw new FS.ErrnoError(75);
        }
        // source must exist
        var old_node = FS.lookupNode(old_dir, old_name);
        // old path should not be an ancestor of the new path
        var relative = PATH_FS.relative(old_path, new_dirname);
        if (relative.charAt(0) !== '.') {
          throw new FS.ErrnoError(28);
        }
        // new path should not be an ancestor of the old path
        relative = PATH_FS.relative(new_path, old_dirname);
        if (relative.charAt(0) !== '.') {
          throw new FS.ErrnoError(55);
        }
        // see if the new path already exists
        var new_node;
        try {
          new_node = FS.lookupNode(new_dir, new_name);
        } catch (e) {
          // not fatal
        }
        // early out if nothing needs to change
        if (old_node === new_node) {
          return;
        }
        // we'll need to delete the old entry
        var isdir = FS.isDir(old_node.mode);
        var errCode = FS.mayDelete(old_dir, old_name, isdir);
        if (errCode) {
          throw new FS.ErrnoError(errCode);
        }
        // need delete permissions if we'll be overwriting.
        // need create permissions if new doesn't already exist.
        errCode = new_node ?
          FS.mayDelete(new_dir, new_name, isdir) :
          FS.mayCreate(new_dir, new_name);
        if (errCode) {
          throw new FS.ErrnoError(errCode);
        }
        if (!old_dir.node_ops.rename) {
          throw new FS.ErrnoError(63);
        }
        if (FS.isMountpoint(old_node) || (new_node && FS.isMountpoint(new_node))) {
          throw new FS.ErrnoError(10);
        }
        // if we are going to change the parent, check write permissions
        if (new_dir !== old_dir) {
          errCode = FS.nodePermissions(old_dir, 'w');
          if (errCode) {
            throw new FS.ErrnoError(errCode);
          }
        }
        // remove the node from the lookup hash
        FS.hashRemoveNode(old_node);
        // do the underlying fs rename
        try {
          old_dir.node_ops.rename(old_node, new_dir, new_name);
          // update old node (we do this here to avoid each backend 
          // needing to)
          old_node.parent = new_dir;
        } catch (e) {
          throw e;
        } finally {
          // add the node back to the hash (in case node_ops.rename
          // changed its name)
          FS.hashAddNode(old_node);
        }
      },
  rmdir(path) {
        var lookup = FS.lookupPath(path, { parent: true });
        var parent = lookup.node;
        var name = PATH.basename(path);
        var node = FS.lookupNode(parent, name);
        var errCode = FS.mayDelete(parent, name, true);
        if (errCode) {
          throw new FS.ErrnoError(errCode);
        }
        if (!parent.node_ops.rmdir) {
          throw new FS.ErrnoError(63);
        }
        if (FS.isMountpoint(node)) {
          throw new FS.ErrnoError(10);
        }
        parent.node_ops.rmdir(parent, name);
        FS.destroyNode(node);
      },
  readdir(path) {
        var lookup = FS.lookupPath(path, { follow: true });
        var node = lookup.node;
        if (!node.node_ops.readdir) {
          throw new FS.ErrnoError(54);
        }
        return node.node_ops.readdir(node);
      },
  unlink(path) {
        var lookup = FS.lookupPath(path, { parent: true });
        var parent = lookup.node;
        if (!parent) {
          throw new FS.ErrnoError(44);
        }
        var name = PATH.basename(path);
        var node = FS.lookupNode(parent, name);
        var errCode = FS.mayDelete(parent, name, false);
        if (errCode) {
          // According to POSIX, we should map EISDIR to EPERM, but
          // we instead do what Linux does (and we must, as we use
          // the musl linux libc).
          throw new FS.ErrnoError(errCode);
        }
        if (!parent.node_ops.unlink) {
          throw new FS.ErrnoError(63);
        }
        if (FS.isMountpoint(node)) {
          throw new FS.ErrnoError(10);
        }
        parent.node_ops.unlink(parent, name);
        FS.destroyNode(node);
      },
  readlink(path) {
        var lookup = FS.lookupPath(path);
        var link = lookup.node;
        if (!link) {
          throw new FS.ErrnoError(44);
        }
        if (!link.node_ops.readlink) {
          throw new FS.ErrnoError(28);
        }
        return PATH_FS.resolve(FS.getPath(link.parent), link.node_ops.readlink(link));
      },
  stat(path, dontFollow) {
        var lookup = FS.lookupPath(path, { follow: !dontFollow });
        var node = lookup.node;
        if (!node) {
          throw new FS.ErrnoError(44);
        }
        if (!node.node_ops.getattr) {
          throw new FS.ErrnoError(63);
        }
        return node.node_ops.getattr(node);
      },
  lstat(path) {
        return FS.stat(path, true);
      },
  chmod(path, mode, dontFollow) {
        var node;
        if (typeof path == 'string') {
          var lookup = FS.lookupPath(path, { follow: !dontFollow });
          node = lookup.node;
        } else {
          node = path;
        }
        if (!node.node_ops.setattr) {
          throw new FS.ErrnoError(63);
        }
        node.node_ops.setattr(node, {
          mode: (mode & 4095) | (node.mode & ~4095),
          timestamp: Date.now()
        });
      },
  lchmod(path, mode) {
        FS.chmod(path, mode, true);
      },
  fchmod(fd, mode) {
        var stream = FS.getStreamChecked(fd);
        FS.chmod(stream.node, mode);
      },
  chown(path, uid, gid, dontFollow) {
        var node;
        if (typeof path == 'string') {
          var lookup = FS.lookupPath(path, { follow: !dontFollow });
          node = lookup.node;
        } else {
          node = path;
        }
        if (!node.node_ops.setattr) {
          throw new FS.ErrnoError(63);
        }
        node.node_ops.setattr(node, {
          timestamp: Date.now()
          // we ignore the uid / gid for now
        });
      },
  lchown(path, uid, gid) {
        FS.chown(path, uid, gid, true);
      },
  fchown(fd, uid, gid) {
        var stream = FS.getStreamChecked(fd);
        FS.chown(stream.node, uid, gid);
      },
  truncate(path, len) {
        if (len < 0) {
          throw new FS.ErrnoError(28);
        }
        var node;
        if (typeof path == 'string') {
          var lookup = FS.lookupPath(path, { follow: true });
          node = lookup.node;
        } else {
          node = path;
        }
        if (!node.node_ops.setattr) {
          throw new FS.ErrnoError(63);
        }
        if (FS.isDir(node.mode)) {
          throw new FS.ErrnoError(31);
        }
        if (!FS.isFile(node.mode)) {
          throw new FS.ErrnoError(28);
        }
        var errCode = FS.nodePermissions(node, 'w');
        if (errCode) {
          throw new FS.ErrnoError(errCode);
        }
        node.node_ops.setattr(node, {
          size: len,
          timestamp: Date.now()
        });
      },
  ftruncate(fd, len) {
        var stream = FS.getStreamChecked(fd);
        if ((stream.flags & 2097155) === 0) {
          throw new FS.ErrnoError(28);
        }
        FS.truncate(stream.node, len);
      },
  utime(path, atime, mtime) {
        var lookup = FS.lookupPath(path, { follow: true });
        var node = lookup.node;
        node.node_ops.setattr(node, {
          timestamp: Math.max(atime, mtime)
        });
      },
  open(path, flags, mode) {
        if (path === "") {
          throw new FS.ErrnoError(44);
        }
        flags = typeof flags == 'string' ? FS_modeStringToFlags(flags) : flags;
        if ((flags & 64)) {
          mode = typeof mode == 'undefined' ? 438 /* 0666 */ : mode;
          mode = (mode & 4095) | 32768;
        } else {
          mode = 0;
        }
        var node;
        if (typeof path == 'object') {
          node = path;
        } else {
          path = PATH.normalize(path);
          try {
            var lookup = FS.lookupPath(path, {
              follow: !(flags & 131072)
            });
            node = lookup.node;
          } catch (e) {
            // ignore
          }
        }
        // perhaps we need to create the node
        var created = false;
        if ((flags & 64)) {
          if (node) {
            // if O_CREAT and O_EXCL are set, error out if the node already exists
            if ((flags & 128)) {
              throw new FS.ErrnoError(20);
            }
          } else {
            // node doesn't exist, try to create it
            node = FS.mknod(path, mode, 0);
            created = true;
          }
        }
        if (!node) {
          throw new FS.ErrnoError(44);
        }
        // can't truncate a device
        if (FS.isChrdev(node.mode)) {
          flags &= ~512;
        }
        // if asked only for a directory, then this must be one
        if ((flags & 65536) && !FS.isDir(node.mode)) {
          throw new FS.ErrnoError(54);
        }
        // check permissions, if this is not a file we just created now (it is ok to
        // create and write to a file with read-only permissions; it is read-only
        // for later use)
        if (!created) {
          var errCode = FS.mayOpen(node, flags);
          if (errCode) {
            throw new FS.ErrnoError(errCode);
          }
        }
        // do truncation if necessary
        if ((flags & 512) && !created) {
          FS.truncate(node, 0);
        }
        // we've already handled these, don't pass down to the underlying vfs
        flags &= ~(128 | 512 | 131072);
  
        // register the stream with the filesystem
        var stream = FS.createStream({
          node,
          path: FS.getPath(node),  // we want the absolute path to the node
          flags,
          seekable: true,
          position: 0,
          stream_ops: node.stream_ops,
          // used by the file family libc calls (fopen, fwrite, ferror, etc.)
          ungotten: [],
          error: false
        });
        // call the new stream's open function
        if (stream.stream_ops.open) {
          stream.stream_ops.open(stream);
        }
        if (Module['logReadFiles'] && !(flags & 1)) {
          if (!FS.readFiles) FS.readFiles = {};
          if (!(path in FS.readFiles)) {
            FS.readFiles[path] = 1;
          }
        }
        return stream;
      },
  close(stream) {
        if (FS.isClosed(stream)) {
          throw new FS.ErrnoError(8);
        }
        if (stream.getdents) stream.getdents = null; // free readdir state
        try {
          if (stream.stream_ops.close) {
            stream.stream_ops.close(stream);
          }
        } catch (e) {
          throw e;
        } finally {
          FS.closeStream(stream.fd);
        }
        stream.fd = null;
      },
  isClosed(stream) {
        return stream.fd === null;
      },
  llseek(stream, offset, whence) {
        if (FS.isClosed(stream)) {
          throw new FS.ErrnoError(8);
        }
        if (!stream.seekable || !stream.stream_ops.llseek) {
          throw new FS.ErrnoError(70);
        }
        if (whence != 0 && whence != 1 && whence != 2) {
          throw new FS.ErrnoError(28);
        }
        stream.position = stream.stream_ops.llseek(stream, offset, whence);
        stream.ungotten = [];
        return stream.position;
      },
  read(stream, buffer, offset, length, position) {
        assert(offset >= 0);
        if (length < 0 || position < 0) {
          throw new FS.ErrnoError(28);
        }
        if (FS.isClosed(stream)) {
          throw new FS.ErrnoError(8);
        }
        if ((stream.flags & 2097155) === 1) {
          throw new FS.ErrnoError(8);
        }
        if (FS.isDir(stream.node.mode)) {
          throw new FS.ErrnoError(31);
        }
        if (!stream.stream_ops.read) {
          throw new FS.ErrnoError(28);
        }
        var seeking = typeof position != 'undefined';
        if (!seeking) {
          position = stream.position;
        } else if (!stream.seekable) {
          throw new FS.ErrnoError(70);
        }
        var bytesRead = stream.stream_ops.read(stream, buffer, offset, length, position);
        if (!seeking) stream.position += bytesRead;
        return bytesRead;
      },
  write(stream, buffer, offset, length, position, canOwn) {
        assert(offset >= 0);
        if (length < 0 || position < 0) {
          throw new FS.ErrnoError(28);
        }
        if (FS.isClosed(stream)) {
          throw new FS.ErrnoError(8);
        }
        if ((stream.flags & 2097155) === 0) {
          throw new FS.ErrnoError(8);
        }
        if (FS.isDir(stream.node.mode)) {
          throw new FS.ErrnoError(31);
        }
        if (!stream.stream_ops.write) {
          throw new FS.ErrnoError(28);
        }
        if (stream.seekable && stream.flags & 1024) {
          // seek to the end before writing in append mode
          FS.llseek(stream, 0, 2);
        }
        var seeking = typeof position != 'undefined';
        if (!seeking) {
          position = stream.position;
        } else if (!stream.seekable) {
          throw new FS.ErrnoError(70);
        }
        var bytesWritten = stream.stream_ops.write(stream, buffer, offset, length, position, canOwn);
        if (!seeking) stream.position += bytesWritten;
        return bytesWritten;
      },
  allocate(stream, offset, length) {
        if (FS.isClosed(stream)) {
          throw new FS.ErrnoError(8);
        }
        if (offset < 0 || length <= 0) {
          throw new FS.ErrnoError(28);
        }
        if ((stream.flags & 2097155) === 0) {
          throw new FS.ErrnoError(8);
        }
        if (!FS.isFile(stream.node.mode) && !FS.isDir(stream.node.mode)) {
          throw new FS.ErrnoError(43);
        }
        if (!stream.stream_ops.allocate) {
          throw new FS.ErrnoError(138);
        }
        stream.stream_ops.allocate(stream, offset, length);
      },
  mmap(stream, length, position, prot, flags) {
        // User requests writing to file (prot & PROT_WRITE != 0).
        // Checking if we have permissions to write to the file unless
        // MAP_PRIVATE flag is set. According to POSIX spec it is possible
        // to write to file opened in read-only mode with MAP_PRIVATE flag,
        // as all modifications will be visible only in the memory of
        // the current process.
        if ((prot & 2) !== 0
            && (flags & 2) === 0
            && (stream.flags & 2097155) !== 2) {
          throw new FS.ErrnoError(2);
        }
        if ((stream.flags & 2097155) === 1) {
          throw new FS.ErrnoError(2);
        }
        if (!stream.stream_ops.mmap) {
          throw new FS.ErrnoError(43);
        }
        return stream.stream_ops.mmap(stream, length, position, prot, flags);
      },
  msync(stream, buffer, offset, length, mmapFlags) {
        assert(offset >= 0);
        if (!stream.stream_ops.msync) {
          return 0;
        }
        return stream.stream_ops.msync(stream, buffer, offset, length, mmapFlags);
      },
  ioctl(stream, cmd, arg) {
        if (!stream.stream_ops.ioctl) {
          throw new FS.ErrnoError(59);
        }
        return stream.stream_ops.ioctl(stream, cmd, arg);
      },
  readFile(path, opts = {}) {
        opts.flags = opts.flags || 0;
        opts.encoding = opts.encoding || 'binary';
        if (opts.encoding !== 'utf8' && opts.encoding !== 'binary') {
          throw new Error(`Invalid encoding type "${opts.encoding}"`);
        }
        var ret;
        var stream = FS.open(path, opts.flags);
        var stat = FS.stat(path);
        var length = stat.size;
        var buf = new Uint8Array(length);
        FS.read(stream, buf, 0, length, 0);
        if (opts.encoding === 'utf8') {
          ret = UTF8ArrayToString(buf, 0);
        } else if (opts.encoding === 'binary') {
          ret = buf;
        }
        FS.close(stream);
        return ret;
      },
  writeFile(path, data, opts = {}) {
        opts.flags = opts.flags || 577;
        var stream = FS.open(path, opts.flags, opts.mode);
        if (typeof data == 'string') {
          var buf = new Uint8Array(lengthBytesUTF8(data)+1);
          var actualNumBytes = stringToUTF8Array(data, buf, 0, buf.length);
          FS.write(stream, buf, 0, actualNumBytes, undefined, opts.canOwn);
        } else if (ArrayBuffer.isView(data)) {
          FS.write(stream, data, 0, data.byteLength, undefined, opts.canOwn);
        } else {
          throw new Error('Unsupported data type');
        }
        FS.close(stream);
      },
  cwd:() => FS.currentPath,
  chdir(path) {
        var lookup = FS.lookupPath(path, { follow: true });
        if (lookup.node === null) {
          throw new FS.ErrnoError(44);
        }
        if (!FS.isDir(lookup.node.mode)) {
          throw new FS.ErrnoError(54);
        }
        var errCode = FS.nodePermissions(lookup.node, 'x');
        if (errCode) {
          throw new FS.ErrnoError(errCode);
        }
        FS.currentPath = lookup.path;
      },
  createDefaultDirectories() {
        FS.mkdir('/tmp');
        FS.mkdir('/home');
        FS.mkdir('/home/web_user');
      },
  createDefaultDevices() {
        // create /dev
        FS.mkdir('/dev');
        // setup /dev/null
        FS.registerDevice(FS.makedev(1, 3), {
          read: () => 0,
          write: (stream, buffer, offset, length, pos) => length,
        });
        FS.mkdev('/dev/null', FS.makedev(1, 3));
        // setup /dev/tty and /dev/tty1
        // stderr needs to print output using err() rather than out()
        // so we register a second tty just for it.
        TTY.register(FS.makedev(5, 0), TTY.default_tty_ops);
        TTY.register(FS.makedev(6, 0), TTY.default_tty1_ops);
        FS.mkdev('/dev/tty', FS.makedev(5, 0));
        FS.mkdev('/dev/tty1', FS.makedev(6, 0));
        // setup /dev/[u]random
        // use a buffer to avoid overhead of individual crypto calls per byte
        var randomBuffer = new Uint8Array(1024), randomLeft = 0;
        var randomByte = () => {
          if (randomLeft === 0) {
            randomLeft = randomFill(randomBuffer).byteLength;
          }
          return randomBuffer[--randomLeft];
        };
        FS.createDevice('/dev', 'random', randomByte);
        FS.createDevice('/dev', 'urandom', randomByte);
        // we're not going to emulate the actual shm device,
        // just create the tmp dirs that reside in it commonly
        FS.mkdir('/dev/shm');
        FS.mkdir('/dev/shm/tmp');
      },
  createSpecialDirectories() {
        // create /proc/self/fd which allows /proc/self/fd/6 => readlink gives the
        // name of the stream for fd 6 (see test_unistd_ttyname)
        FS.mkdir('/proc');
        var proc_self = FS.mkdir('/proc/self');
        FS.mkdir('/proc/self/fd');
        FS.mount({
          mount() {
            var node = FS.createNode(proc_self, 'fd', 16384 | 511 /* 0777 */, 73);
            node.node_ops = {
              lookup(parent, name) {
                var fd = +name;
                var stream = FS.getStreamChecked(fd);
                var ret = {
                  parent: null,
                  mount: { mountpoint: 'fake' },
                  node_ops: { readlink: () => stream.path },
                };
                ret.parent = ret; // make it look like a simple root node
                return ret;
              }
            };
            return node;
          }
        }, {}, '/proc/self/fd');
      },
  createStandardStreams() {
        // TODO deprecate the old functionality of a single
        // input / output callback and that utilizes FS.createDevice
        // and instead require a unique set of stream ops
  
        // by default, we symlink the standard streams to the
        // default tty devices. however, if the standard streams
        // have been overwritten we create a unique device for
        // them instead.
        if (Module['stdin']) {
          FS.createDevice('/dev', 'stdin', Module['stdin']);
        } else {
          FS.symlink('/dev/tty', '/dev/stdin');
        }
        if (Module['stdout']) {
          FS.createDevice('/dev', 'stdout', null, Module['stdout']);
        } else {
          FS.symlink('/dev/tty', '/dev/stdout');
        }
        if (Module['stderr']) {
          FS.createDevice('/dev', 'stderr', null, Module['stderr']);
        } else {
          FS.symlink('/dev/tty1', '/dev/stderr');
        }
  
        // open default streams for the stdin, stdout and stderr devices
        var stdin = FS.open('/dev/stdin', 0);
        var stdout = FS.open('/dev/stdout', 1);
        var stderr = FS.open('/dev/stderr', 1);
        assert(stdin.fd === 0, `invalid handle for stdin (${stdin.fd})`);
        assert(stdout.fd === 1, `invalid handle for stdout (${stdout.fd})`);
        assert(stderr.fd === 2, `invalid handle for stderr (${stderr.fd})`);
      },
  staticInit() {
        // Some errors may happen quite a bit, to avoid overhead we reuse them (and suffer a lack of stack info)
        [44].forEach((code) => {
          FS.genericErrors[code] = new FS.ErrnoError(code);
          FS.genericErrors[code].stack = '<generic error, no stack>';
        });
  
        FS.nameTable = new Array(4096);
  
        FS.mount(MEMFS, {}, '/');
  
        FS.createDefaultDirectories();
        FS.createDefaultDevices();
        FS.createSpecialDirectories();
  
        FS.filesystems = {
          'MEMFS': MEMFS,
          'IDBFS': IDBFS,
        };
      },
  init(input, output, error) {
        assert(!FS.init.initialized, 'FS.init was previously called. If you want to initialize later with custom parameters, remove any earlier calls (note that one is automatically added to the generated code)');
        FS.init.initialized = true;
  
        // Allow Module.stdin etc. to provide defaults, if none explicitly passed to us here
        Module['stdin'] = input || Module['stdin'];
        Module['stdout'] = output || Module['stdout'];
        Module['stderr'] = error || Module['stderr'];
  
        FS.createStandardStreams();
      },
  quit() {
        FS.init.initialized = false;
        // force-flush all streams, so we get musl std streams printed out
        _fflush(0);
        // close all of our streams
        for (var i = 0; i < FS.streams.length; i++) {
          var stream = FS.streams[i];
          if (!stream) {
            continue;
          }
          FS.close(stream);
        }
      },
  findObject(path, dontResolveLastLink) {
        var ret = FS.analyzePath(path, dontResolveLastLink);
        if (!ret.exists) {
          return null;
        }
        return ret.object;
      },
  analyzePath(path, dontResolveLastLink) {
        // operate from within the context of the symlink's target
        try {
          var lookup = FS.lookupPath(path, { follow: !dontResolveLastLink });
          path = lookup.path;
        } catch (e) {
        }
        var ret = {
          isRoot: false, exists: false, error: 0, name: null, path: null, object: null,
          parentExists: false, parentPath: null, parentObject: null
        };
        try {
          var lookup = FS.lookupPath(path, { parent: true });
          ret.parentExists = true;
          ret.parentPath = lookup.path;
          ret.parentObject = lookup.node;
          ret.name = PATH.basename(path);
          lookup = FS.lookupPath(path, { follow: !dontResolveLastLink });
          ret.exists = true;
          ret.path = lookup.path;
          ret.object = lookup.node;
          ret.name = lookup.node.name;
          ret.isRoot = lookup.path === '/';
        } catch (e) {
          ret.error = e.errno;
        };
        return ret;
      },
  createPath(parent, path, canRead, canWrite) {
        parent = typeof parent == 'string' ? parent : FS.getPath(parent);
        var parts = path.split('/').reverse();
        while (parts.length) {
          var part = parts.pop();
          if (!part) continue;
          var current = PATH.join2(parent, part);
          try {
            FS.mkdir(current);
          } catch (e) {
            // ignore EEXIST
          }
          parent = current;
        }
        return current;
      },
  createFile(parent, name, properties, canRead, canWrite) {
        var path = PATH.join2(typeof parent == 'string' ? parent : FS.getPath(parent), name);
        var mode = FS_getMode(canRead, canWrite);
        return FS.create(path, mode);
      },
  createDataFile(parent, name, data, canRead, canWrite, canOwn) {
        var path = name;
        if (parent) {
          parent = typeof parent == 'string' ? parent : FS.getPath(parent);
          path = name ? PATH.join2(parent, name) : parent;
        }
        var mode = FS_getMode(canRead, canWrite);
        var node = FS.create(path, mode);
        if (data) {
          if (typeof data == 'string') {
            var arr = new Array(data.length);
            for (var i = 0, len = data.length; i < len; ++i) arr[i] = data.charCodeAt(i);
            data = arr;
          }
          // make sure we can write to the file
          FS.chmod(node, mode | 146);
          var stream = FS.open(node, 577);
          FS.write(stream, data, 0, data.length, 0, canOwn);
          FS.close(stream);
          FS.chmod(node, mode);
        }
      },
  createDevice(parent, name, input, output) {
        var path = PATH.join2(typeof parent == 'string' ? parent : FS.getPath(parent), name);
        var mode = FS_getMode(!!input, !!output);
        if (!FS.createDevice.major) FS.createDevice.major = 64;
        var dev = FS.makedev(FS.createDevice.major++, 0);
        // Create a fake device that a set of stream ops to emulate
        // the old behavior.
        FS.registerDevice(dev, {
          open(stream) {
            stream.seekable = false;
          },
          close(stream) {
            // flush any pending line data
            if (output?.buffer?.length) {
              output(10);
            }
          },
          read(stream, buffer, offset, length, pos /* ignored */) {
            var bytesRead = 0;
            for (var i = 0; i < length; i++) {
              var result;
              try {
                result = input();
              } catch (e) {
                throw new FS.ErrnoError(29);
              }
              if (result === undefined && bytesRead === 0) {
                throw new FS.ErrnoError(6);
              }
              if (result === null || result === undefined) break;
              bytesRead++;
              buffer[offset+i] = result;
            }
            if (bytesRead) {
              stream.node.timestamp = Date.now();
            }
            return bytesRead;
          },
          write(stream, buffer, offset, length, pos) {
            for (var i = 0; i < length; i++) {
              try {
                output(buffer[offset+i]);
              } catch (e) {
                throw new FS.ErrnoError(29);
              }
            }
            if (length) {
              stream.node.timestamp = Date.now();
            }
            return i;
          }
        });
        return FS.mkdev(path, mode, dev);
      },
  forceLoadFile(obj) {
        if (obj.isDevice || obj.isFolder || obj.link || obj.contents) return true;
        if (typeof XMLHttpRequest != 'undefined') {
          throw new Error("Lazy loading should have been performed (contents set) in createLazyFile, but it was not. Lazy loading only works in web workers. Use --embed-file or --preload-file in emcc on the main thread.");
        } else { // Command-line.
          try {
            obj.contents = readBinary(obj.url);
            obj.usedBytes = obj.contents.length;
          } catch (e) {
            throw new FS.ErrnoError(29);
          }
        }
      },
  createLazyFile(parent, name, url, canRead, canWrite) {
        // Lazy chunked Uint8Array (implements get and length from Uint8Array).
        // Actual getting is abstracted away for eventual reuse.
        class LazyUint8Array {
          constructor() {
            this.lengthKnown = false;
            this.chunks = []; // Loaded chunks. Index is the chunk number
          }
          get(idx) {
            if (idx > this.length-1 || idx < 0) {
              return undefined;
            }
            var chunkOffset = idx % this.chunkSize;
            var chunkNum = (idx / this.chunkSize)|0;
            return this.getter(chunkNum)[chunkOffset];
          }
          setDataGetter(getter) {
            this.getter = getter;
          }
          cacheLength() {
            // Find length
            var xhr = new XMLHttpRequest();
            xhr.open('HEAD', url, false);
            xhr.send(null);
            if (!(xhr.status >= 200 && xhr.status < 300 || xhr.status === 304)) throw new Error("Couldn't load " + url + ". Status: " + xhr.status);
            var datalength = Number(xhr.getResponseHeader("Content-length"));
            var header;
            var hasByteServing = (header = xhr.getResponseHeader("Accept-Ranges")) && header === "bytes";
            var usesGzip = (header = xhr.getResponseHeader("Content-Encoding")) && header === "gzip";
  
            var chunkSize = 1024*1024; // Chunk size in bytes
  
            if (!hasByteServing) chunkSize = datalength;
  
            // Function to get a range from the remote URL.
            var doXHR = (from, to) => {
              if (from > to) throw new Error("invalid range (" + from + ", " + to + ") or no bytes requested!");
              if (to > datalength-1) throw new Error("only " + datalength + " bytes available! programmer error!");
  
              // TODO: Use mozResponseArrayBuffer, responseStream, etc. if available.
              var xhr = new XMLHttpRequest();
              xhr.open('GET', url, false);
              if (datalength !== chunkSize) xhr.setRequestHeader("Range", "bytes=" + from + "-" + to);
  
              // Some hints to the browser that we want binary data.
              xhr.responseType = 'arraybuffer';
              if (xhr.overrideMimeType) {
                xhr.overrideMimeType('text/plain; charset=x-user-defined');
              }
  
              xhr.send(null);
              if (!(xhr.status >= 200 && xhr.status < 300 || xhr.status === 304)) throw new Error("Couldn't load " + url + ". Status: " + xhr.status);
              if (xhr.response !== undefined) {
                return new Uint8Array(/** @type{Array<number>} */(xhr.response || []));
              }
              return intArrayFromString(xhr.responseText || '', true);
            };
            var lazyArray = this;
            lazyArray.setDataGetter((chunkNum) => {
              var start = chunkNum * chunkSize;
              var end = (chunkNum+1) * chunkSize - 1; // including this byte
              end = Math.min(end, datalength-1); // if datalength-1 is selected, this is the last block
              if (typeof lazyArray.chunks[chunkNum] == 'undefined') {
                lazyArray.chunks[chunkNum] = doXHR(start, end);
              }
              if (typeof lazyArray.chunks[chunkNum] == 'undefined') throw new Error('doXHR failed!');
              return lazyArray.chunks[chunkNum];
            });
  
            if (usesGzip || !datalength) {
              // if the server uses gzip or doesn't supply the length, we have to download the whole file to get the (uncompressed) length
              chunkSize = datalength = 1; // this will force getter(0)/doXHR do download the whole file
              datalength = this.getter(0).length;
              chunkSize = datalength;
              out("LazyFiles on gzip forces download of the whole file when length is accessed");
            }
  
            this._length = datalength;
            this._chunkSize = chunkSize;
            this.lengthKnown = true;
          }
          get length() {
            if (!this.lengthKnown) {
              this.cacheLength();
            }
            return this._length;
          }
          get chunkSize() {
            if (!this.lengthKnown) {
              this.cacheLength();
            }
            return this._chunkSize;
          }
        }
  
        if (typeof XMLHttpRequest != 'undefined') {
          if (!ENVIRONMENT_IS_WORKER) throw 'Cannot do synchronous binary XHRs outside webworkers in modern browsers. Use --embed-file or --preload-file in emcc';
          var lazyArray = new LazyUint8Array();
          var properties = { isDevice: false, contents: lazyArray };
        } else {
          var properties = { isDevice: false, url: url };
        }
  
        var node = FS.createFile(parent, name, properties, canRead, canWrite);
        // This is a total hack, but I want to get this lazy file code out of the
        // core of MEMFS. If we want to keep this lazy file concept I feel it should
        // be its own thin LAZYFS proxying calls to MEMFS.
        if (properties.contents) {
          node.contents = properties.contents;
        } else if (properties.url) {
          node.contents = null;
          node.url = properties.url;
        }
        // Add a function that defers querying the file size until it is asked the first time.
        Object.defineProperties(node, {
          usedBytes: {
            get: function() { return this.contents.length; }
          }
        });
        // override each stream op with one that tries to force load the lazy file first
        var stream_ops = {};
        var keys = Object.keys(node.stream_ops);
        keys.forEach((key) => {
          var fn = node.stream_ops[key];
          stream_ops[key] = (...args) => {
            FS.forceLoadFile(node);
            return fn(...args);
          };
        });
        function writeChunks(stream, buffer, offset, length, position) {
          var contents = stream.node.contents;
          if (position >= contents.length)
            return 0;
          var size = Math.min(contents.length - position, length);
          assert(size >= 0);
          if (contents.slice) { // normal array
            for (var i = 0; i < size; i++) {
              buffer[offset + i] = contents[position + i];
            }
          } else {
            for (var i = 0; i < size; i++) { // LazyUint8Array from sync binary XHR
              buffer[offset + i] = contents.get(position + i);
            }
          }
          return size;
        }
        // use a custom read function
        stream_ops.read = (stream, buffer, offset, length, position) => {
          FS.forceLoadFile(node);
          return writeChunks(stream, buffer, offset, length, position)
        };
        // use a custom mmap function
        stream_ops.mmap = (stream, length, position, prot, flags) => {
          FS.forceLoadFile(node);
          var ptr = mmapAlloc(length);
          if (!ptr) {
            throw new FS.ErrnoError(48);
          }
          writeChunks(stream, HEAP8, ptr, length, position);
          return { ptr, allocated: true };
        };
        node.stream_ops = stream_ops;
        return node;
      },
  absolutePath() {
        abort('FS.absolutePath has been removed; use PATH_FS.resolve instead');
      },
  createFolder() {
        abort('FS.createFolder has been removed; use FS.mkdir instead');
      },
  createLink() {
        abort('FS.createLink has been removed; use FS.symlink instead');
      },
  joinPath() {
        abort('FS.joinPath has been removed; use PATH.join instead');
      },
  mmapAlloc() {
        abort('FS.mmapAlloc has been replaced by the top level function mmapAlloc');
      },
  standardizePath() {
        abort('FS.standardizePath has been removed; use PATH.normalize instead');
      },
  };
  var PATH_FS = {
  resolve:(...args) => {
        var resolvedPath = '',
          resolvedAbsolute = false;
        for (var i = args.length - 1; i >= -1 && !resolvedAbsolute; i--) {
          var path = (i >= 0) ? args[i] : FS.cwd();
          // Skip empty and invalid entries
          if (typeof path != 'string') {
            throw new TypeError('Arguments to path.resolve must be strings');
          } else if (!path) {
            return ''; // an invalid portion invalidates the whole thing
          }
          resolvedPath = path + '/' + resolvedPath;
          resolvedAbsolute = PATH.isAbs(path);
        }
        // At this point the path should be resolved to a full absolute path, but
        // handle relative paths to be safe (might happen when process.cwd() fails)
        resolvedPath = PATH.normalizeArray(resolvedPath.split('/').filter((p) => !!p), !resolvedAbsolute).join('/');
        return ((resolvedAbsolute ? '/' : '') + resolvedPath) || '.';
      },
  relative:(from, to) => {
        from = PATH_FS.resolve(from).substr(1);
        to = PATH_FS.resolve(to).substr(1);
        function trim(arr) {
          var start = 0;
          for (; start < arr.length; start++) {
            if (arr[start] !== '') break;
          }
          var end = arr.length - 1;
          for (; end >= 0; end--) {
            if (arr[end] !== '') break;
          }
          if (start > end) return [];
          return arr.slice(start, end - start + 1);
        }
        var fromParts = trim(from.split('/'));
        var toParts = trim(to.split('/'));
        var length = Math.min(fromParts.length, toParts.length);
        var samePartsLength = length;
        for (var i = 0; i < length; i++) {
          if (fromParts[i] !== toParts[i]) {
            samePartsLength = i;
            break;
          }
        }
        var outputParts = [];
        for (var i = samePartsLength; i < fromParts.length; i++) {
          outputParts.push('..');
        }
        outputParts = outputParts.concat(toParts.slice(samePartsLength));
        return outputParts.join('/');
      },
  };
  
  
  
  
  var stringToUTF8 = (str, outPtr, maxBytesToWrite) => {
      assert(typeof maxBytesToWrite == 'number', 'stringToUTF8(str, outPtr, maxBytesToWrite) is missing the third parameter that specifies the length of the output buffer!');
      return stringToUTF8Array(str, HEAPU8, outPtr, maxBytesToWrite);
    };
  
  var stackAlloc = (sz) => __emscripten_stack_alloc(sz);
  var stringToUTF8OnStack = (str) => {
      var size = lengthBytesUTF8(str) + 1;
      var ret = stackAlloc(size);
      stringToUTF8(str, ret, size);
      return ret;
    };
  
  
  var _IMG_Load_RW = (rwopsID, freeSrc) => {
      var sp = stackSave();
      try {
        // stb_image integration support
        var cleanup = () => {
          stackRestore(sp);
          if (rwops && freeSrc) _SDL_FreeRW(rwopsID);
        }
        var addCleanup = (func) => {
          var old = cleanup;
          cleanup = () => {
            old();
            func();
          }
        }
        var callStbImage = (func, params) => {
          var x = stackAlloc(4);
          var y = stackAlloc(4);
          var comp = stackAlloc(4);
          var data = Module['_' + func](...params, x, y, comp, 0);
          if (!data) return null;
          addCleanup(() => Module['_stbi_image_free'](data));
          return {
            rawData: true,
            data,
            width: HEAP32[((x)>>2)],
            height: HEAP32[((y)>>2)],
            size: HEAP32[((x)>>2)] * HEAP32[((y)>>2)] * HEAP32[((comp)>>2)],
            bpp: HEAP32[((comp)>>2)]
          };
        };
  
        var rwops = SDL.rwops[rwopsID];
        if (rwops === undefined) {
          return 0;
        }
  
        var raw;
        var filename = rwops.filename;
        if (filename === undefined) {
          warnOnce('Only file names that have been preloaded are supported for IMG_Load_RW. Consider using STB_IMAGE=1 if you want synchronous image decoding (see settings.js), or package files with --use-preload-plugins');
          return 0;
        }
  
        if (!raw) {
          filename = PATH_FS.resolve(filename);
          raw = preloadedImages[filename];
          if (!raw) {
            if (raw === null) err('Trying to reuse preloaded image, but freePreloadedMediaOnUse is set!');
            warnOnce('Cannot find preloaded image ' + filename);
            warnOnce('Cannot find preloaded image ' + filename + '. Consider using STB_IMAGE=1 if you want synchronous image decoding (see settings.js), or package files with --use-preload-plugins');
            return 0;
          } else if (Module['freePreloadedMediaOnUse']) {
            preloadedImages[filename] = null;
          }
        }
  
        var surf = SDL.makeSurface(raw.width, raw.height, 0, false, 'load:' + filename);
        var surfData = SDL.surfaces[surf];
        surfData.ctx.globalCompositeOperation = "copy";
        if (!raw.rawData) {
          surfData.ctx.drawImage(raw, 0, 0, raw.width, raw.height, 0, 0, raw.width, raw.height);
        } else {
          var imageData = surfData.ctx.getImageData(0, 0, surfData.width, surfData.height);
          if (raw.bpp == 4) {
            // rgba
            imageData.data.set(HEAPU8.subarray((raw.data), raw.data+raw.size));
          } else if (raw.bpp == 3) {
            // rgb
            var pixels = raw.size/3;
            var data = imageData.data;
            var sourcePtr = raw.data;
            var destPtr = 0;
            for (var i = 0; i < pixels; i++) {
              data[destPtr++] = HEAPU8[sourcePtr++];
              data[destPtr++] = HEAPU8[sourcePtr++];
              data[destPtr++] = HEAPU8[sourcePtr++];
              data[destPtr++] = 255;
            }
          } else if (raw.bpp == 2) {
            // grayscale + alpha
            var pixels = raw.size;
            var data = imageData.data;
            var sourcePtr = raw.data;
            var destPtr = 0;
            for (var i = 0; i < pixels; i++) {
              var gray = HEAPU8[sourcePtr++];
              var alpha = HEAPU8[sourcePtr++];
              data[destPtr++] = gray;
              data[destPtr++] = gray;
              data[destPtr++] = gray;
              data[destPtr++] = alpha;
            }
          } else if (raw.bpp == 1) {
            // grayscale
            var pixels = raw.size;
            var data = imageData.data;
            var sourcePtr = raw.data;
            var destPtr = 0;
            for (var i = 0; i < pixels; i++) {
              var value = HEAPU8[sourcePtr++];
              data[destPtr++] = value;
              data[destPtr++] = value;
              data[destPtr++] = value;
              data[destPtr++] = 255;
            }
          } else {
            err(`cannot handle bpp ${raw.bpp}`);
            return 0;
          }
          surfData.ctx.putImageData(imageData, 0, 0);
        }
        surfData.ctx.globalCompositeOperation = "source-over";
        // XXX SDL does not specify that loaded images must have available pixel data, in fact
        //     there are cases where you just want to blit them, so you just need the hardware
        //     accelerated version. However, code everywhere seems to assume that the pixels
        //     are in fact available, so we retrieve it here. This does add overhead though.
        _SDL_LockSurface(surf);
        surfData.locked--; // The surface is not actually locked in this hack
        if (SDL.GL) {
          // After getting the pixel data, we can free the canvas and context if we do not need to do 2D canvas blitting
          surfData.canvas = surfData.ctx = null;
        }
        return surf;
      } finally {
        cleanup();
      }
    };
  
  
  /** @param {number} mode */
  var _SDL_RWFromFile = (_name, mode) => {
      var id = SDL.rwops.length; // TODO: recycle ids when they are null
      var filename = UTF8ToString(_name);
      SDL.rwops.push({ filename, mimetype: Browser.getMimetype(filename) });
      return id;
    };
  
  var _IMG_Load = (filename) => {
      var rwops = _SDL_RWFromFile(filename, 0);
      var result = _IMG_Load_RW(rwops, 1);
      return result;
    };

  
  
  var _SDL_PauseAudio = (pauseOn) => {
      if (!SDL.audio) {
        return;
      }
      if (pauseOn) {
        if (SDL.audio.timer !== undefined) {
          clearTimeout(SDL.audio.timer);
          SDL.audio.numAudioTimersPending = 0;
          SDL.audio.timer = undefined;
        }
      } else if (!SDL.audio.timer) {
        // Start the audio playback timer callback loop.
        SDL.audio.numAudioTimersPending = 1;
        SDL.audio.timer = safeSetTimeout(SDL.audio.caller, 1);
      }
      SDL.audio.paused = pauseOn;
    };
  
  /** @suppress {duplicate } */
  var _SDL_CloseAudio = () => {
      if (SDL.audio) {
        if (SDL.audio.callbackRemover) {
          SDL.audio.callbackRemover();
          SDL.audio.callbackRemover = null;
        }
        _SDL_PauseAudio(1);
        _free(SDL.audio.buffer);
        SDL.audio = null;
        SDL.allocateChannels(0);
      }
    };
  var _Mix_CloseAudio = _SDL_CloseAudio;

  var _Mix_FreeChunk = (id) => {
      SDL.audios[id] = null;
    };

  
  var _Mix_FreeMusic = _Mix_FreeChunk;

  var _Mix_HaltMusic = () => {
      var audio = /** @type {HTMLMediaElement} */ (SDL.music.audio);
      if (audio) {
        audio.src = audio.src; // rewind <media> element
        audio.currentPosition = 0; // rewind Web Audio graph playback.
        audio.pause();
      }
      SDL.music.audio = null;
      if (SDL.hookMusicFinished) {
        (() => dynCall_v(SDL.hookMusicFinished))();
      }
      return 0;
    };

  
  
  
  /** @param {number} freesrc */
  var _Mix_LoadWAV_RW = (rwopsID, freesrc) => {
      var rwops = SDL.rwops[rwopsID];
  
      if (rwops === undefined)
        return 0;
  
      var filename = '';
      var audio;
      var webAudio;
      var bytes;
  
      if (rwops.filename !== undefined) {
        filename = PATH_FS.resolve(rwops.filename);
        var raw = preloadedAudios[filename];
        if (!raw) {
          if (raw === null) err('Trying to reuse preloaded audio, but freePreloadedMediaOnUse is set!');
          if (!Module.noAudioDecoding) warnOnce('Cannot find preloaded audio ' + filename);
  
          // see if we can read the file-contents from the in-memory FS
          try {
            bytes = FS.readFile(filename);
          } catch (e) {
            err(`Couldn't find file for: ${filename}`);
            return 0;
          }
        }
        if (Module['freePreloadedMediaOnUse']) {
          preloadedAudios[filename] = null;
        }
        audio = raw;
      }
      else if (rwops.bytes !== undefined) {
        // For Web Audio context buffer decoding, we must make a clone of the audio data, but for <media> element,
        // a view to existing data is sufficient.
        if (SDL.webAudioAvailable()) bytes = HEAPU8.buffer.slice(rwops.bytes, rwops.bytes + rwops.count);
        else bytes = HEAPU8.subarray(rwops.bytes, rwops.bytes + rwops.count);
      }
      else {
        return 0;
      }
  
      var arrayBuffer = bytes ? bytes.buffer || bytes : bytes;
  
      // To allow user code to work around browser bugs with audio playback on <audio> elements an Web Audio, enable
      // the user code to hook in a callback to decide on a file basis whether each file should use Web Audio or <audio> for decoding and playback.
      // In particular, see https://bugzilla.mozilla.org/show_bug.cgi?id=654787 and ?id=1012801 for tradeoffs.
      var canPlayWithWebAudio = Module['SDL_canPlayWithWebAudio'] === undefined || Module['SDL_canPlayWithWebAudio'](filename, arrayBuffer);
  
      if (bytes !== undefined && SDL.webAudioAvailable() && canPlayWithWebAudio) {
        audio = undefined;
        webAudio = {};
        // The audio decoding process is asynchronous, which gives trouble if user code plays the audio data back immediately
        // after loading. Therefore prepare an array of callback handlers to run when this audio decoding is complete, which
        // will then start the playback (with some delay).
        webAudio.onDecodeComplete = []; // While this member array exists, decoding hasn't finished yet.
        var onDecodeComplete = (data) => {
          webAudio.decodedBuffer = data;
          // Call all handlers that were waiting for this decode to finish, and clear the handler list.
          webAudio.onDecodeComplete.forEach((e) => e());
          webAudio.onDecodeComplete = undefined; // Don't allow more callback handlers since audio has finished decoding.
        };
        SDL.audioContext['decodeAudioData'](arrayBuffer, onDecodeComplete);
      } else if (audio === undefined && bytes) {
        // Here, we didn't find a preloaded audio but we either were passed a filepath for
        // which we loaded bytes, or we were passed some bytes
        var blob = new Blob([bytes], {type: rwops.mimetype});
        var url = URL.createObjectURL(blob);
        audio = new Audio();
        audio.src = url;
        audio.mozAudioChannelType = 'content'; // bugzilla 910340
      }
  
      var id = SDL.audios.length;
      // Keep the loaded audio in the audio arrays, ready for playback
      SDL.audios.push({
        source: filename,
        audio, // Points to the <audio> element, if loaded
        webAudio // Points to a Web Audio -specific resource object, if loaded
      });
      return id;
    };
  
  var _Mix_LoadMUS_RW = (filename) => _Mix_LoadWAV_RW(filename, 0);
  
  
  
  var _Mix_LoadMUS = (filename) => {
      var rwops = _SDL_RWFromFile(filename, 0);
      var result = _Mix_LoadMUS_RW(rwops);
      _SDL_FreeRW(rwops);
      return result;
    };

  
  
  
  var _Mix_LoadWAV = (filename) => {
      var rwops = _SDL_RWFromFile(filename, 0);
      var result = _Mix_LoadWAV_RW(rwops, 0);
      _SDL_FreeRW(rwops);
      return result;
    };

  var listenOnce = (object, event, func) => {
      object.addEventListener(event, func, { 'once': true });
    };
  /** @param {Object=} elements */
  var autoResumeAudioContext = (ctx, elements) => {
      if (!elements) {
        elements = [document, document.getElementById('canvas')];
      }
      ['keydown', 'mousedown', 'touchstart'].forEach((event) => {
        elements.forEach((element) => {
          if (element) {
            listenOnce(element, event, () => {
              if (ctx.state === 'suspended') ctx.resume();
            });
          }
        });
      });
    };
  
  var _Mix_OpenAudio = (frequency, format, channels, chunksize) => {
      SDL.openAudioContext();
      autoResumeAudioContext(SDL.audioContext);
      SDL.allocateChannels(32);
      // Just record the values for a later call to Mix_QuickLoad_RAW
      SDL.mixerFrequency = frequency;
      SDL.mixerFormat = format;
      SDL.mixerNumChannels = channels;
      SDL.mixerChunkSize = chunksize;
      return 0;
    };

  var _Mix_PlayChannelTimed = (channel, id, loops, ticks) => {
      // TODO: handle fixed amount of N loops. Currently loops either 0 or infinite times.
      assert(ticks == -1);
  
      // Get the audio element associated with the ID
      var info = SDL.audios[id];
      if (!info) return -1;
      if (!info.audio && !info.webAudio) return -1;
  
      // If the user asks us to allocate a channel automatically, get the first
      // free one.
      if (channel == -1) {
        for (var i = SDL.channelMinimumNumber; i < SDL.numChannels; i++) {
          if (!SDL.channels[i].audio) {
            channel = i;
            break;
          }
        }
        if (channel == -1) {
          err(`All ${SDL.numChannels}  channels in use!`);
          return -1;
        }
      }
      var channelInfo = SDL.channels[channel];
      var audio;
      if (info.webAudio) {
        // Create an instance of the WebAudio object.
        audio = {};
        audio.resource = info; // This new object is an instance that refers to this existing resource.
        audio.paused = false;
        audio.currentPosition = 0;
        // Make our instance look similar to the instance of a <media> to make api simple.
        audio.play = function() { SDL.playWebAudio(this); }
        audio.pause = function() { SDL.pauseWebAudio(this); }
      } else {
        // We clone the audio node to utilize the preloaded audio buffer, since
        // the browser has already preloaded the audio file.
        audio = info.audio.cloneNode(true);
        audio.numChannels = info.audio.numChannels;
        audio.frequency = info.audio.frequency;
      }
      audio['onended'] = function() { // TODO: cache these
        if (channelInfo.audio == this) { channelInfo.audio.paused = true; channelInfo.audio = null; }
        if (SDL.channelFinished)  ((a1) => dynCall_vi(SDL.channelFinished, a1))(channel);
      }
      channelInfo.audio = audio;
      // TODO: handle N loops. Behavior matches Mix_PlayMusic
      audio.loop = loops != 0;
      audio.volume = channelInfo.volume;
      audio.play();
      return channel;
    };

  
  var _Mix_PlayMusic = (id, loops) => {
      // Pause old music if it exists.
      if (SDL.music.audio) {
        if (!SDL.music.audio.paused) err(`Music is already playing. ${SDL.music.source}`);
        SDL.music.audio.pause();
      }
      var info = SDL.audios[id];
      var audio;
      if (info.webAudio) { // Play via Web Audio API
        // Create an instance of the WebAudio object.
        audio = {};
        audio.resource = info; // This new webAudio object is an instance that refers to this existing resource.
        audio.paused = false;
        audio.currentPosition = 0;
        audio.play = function() { SDL.playWebAudio(this); }
        audio.pause = function() { SDL.pauseWebAudio(this); }
      } else if (info.audio) { // Play via the <audio> element
        audio = info.audio;
      }
      audio['onended'] = function() { if (SDL.music.audio == this) _Mix_HaltMusic(); } // will send callback
      audio.loop = loops != 0 && loops != 1; // TODO: handle N loops for finite N
      audio.volume = SDL.music.volume;
      SDL.music.audio = audio;
      audio.play();
      return 0;
    };

  var _Mix_SetPanning = (channel, left, right) => {
      // SDL API uses [0-255], while PannerNode has an (x, y, z) position.
  
      // Normalizing.
      left /= 255;
      right /= 255;
  
      // Set the z coordinate a little forward, otherwise there won't be any
      // smooth transition between left and right.
      SDL.setPannerPosition(SDL.channels[channel], right - left, 0, 0.1);
      return 1;
    };

  var _Mix_Volume = (channel, volume) => {
      if (channel == -1) {
        for (var i = 0; i < SDL.numChannels-1; i++) {
          _Mix_Volume(i, volume);
        }
        return _Mix_Volume(SDL.numChannels-1, volume);
      }
      return SDL.setGetVolume(SDL.channels[channel], volume);
    };

  var _Mix_VolumeMusic = (volume) => {
      return SDL.setGetVolume(SDL.music, volume);
    };

  /** @param {number} format @param {number} flags */
  var _SDL_ConvertSurface = (surf, format, flags) => {
      if  (format) {
        SDL.checkPixelFormat(format);
      }
  
      var oldData = SDL.surfaces[surf];
      var ret = SDL.makeSurface(oldData.width, oldData.height, oldData.flags, false, 'copy:' + oldData.source);
      var newData = SDL.surfaces[ret];
  
      newData.ctx.globalCompositeOperation = "copy";
      newData.ctx.drawImage(oldData.canvas, 0, 0);
      newData.ctx.globalCompositeOperation = oldData.ctx.globalCompositeOperation;
      return ret;
    };

  var _SDL_CreateRGBSurface = (flags, width, height, depth, rmask, gmask, bmask, amask) => SDL.makeSurface(width, height, flags, false, 'CreateRGBSurface', rmask, gmask, bmask, amask);

  var _emscripten_sleep = (ms) => {
      // emscripten_sleep() does not return a value, but we still need a |return|
      // here for stack switching support (ASYNCIFY=2). In that mode this function
      // returns a Promise instead of nothing, and that Promise is what tells the
      // wasm VM to pause the stack.
      return Asyncify.handleSleep((wakeUp) => safeSetTimeout(wakeUp, ms));
    };
  _emscripten_sleep.isAsync = true;
  
  var _SDL_Delay = (delay) => _emscripten_sleep(delay);
  _SDL_Delay.isAsync = true;

  
  var _SDL_DisplayFormatAlpha = (surf) => _SDL_ConvertSurface(surf, 0, 0);

  var _SDL_EnableKeyRepeat = (delay, interval) => {};

  var _SDL_EnableUNICODE = (on) => {
      var ret = SDL.unicode || 0;
      SDL.unicode = on;
      return ret;
    };

  var _SDL_FillRect = (surf, rect, color) => {
      var surfData = SDL.surfaces[surf];
      assert(!surfData.locked); // but we could unlock and re-lock if we must..
  
      if (surfData.isFlagSet(0x00200000 /* SDL_HWPALETTE */)) {
        //in SDL_HWPALETTE color is index (0..255)
        //so we should translate 1 byte value to
        //32 bit canvas
        color = surfData.colors32[color];
      }
  
      var r = rect ? SDL.loadRect(rect) : { x: 0, y: 0, w: surfData.width, h: surfData.height };
  
      if (surfData.clipRect) {
        r = SDL.intersectionOfRects(surfData.clipRect, r);
  
        if (rect) {
          SDL.updateRect(rect, r);
        }
      }
  
      surfData.ctx.save();
      surfData.ctx.fillStyle = SDL.translateColorToCSSRGBA(color);
      surfData.ctx.fillRect(r.x, r.y, r.w, r.h);
      surfData.ctx.restore();
      return 0;
    };

  var _SDL_Flip = (surf) => {
      // We actually do this in Unlock, since the screen surface has as its canvas
      // backing the page canvas element
    };

  var _SDL_FreeSurface = (surf) => {
      if (surf) SDL.freeSurface(surf);
    };

  var _SDL_GetClipRect = (surf, rect) => {
      assert(rect);
  
      var surfData = SDL.surfaces[surf];
      var r = surfData.clipRect || { x: 0, y: 0, w: surfData.width, h: surfData.height };
      SDL.updateRect(rect, r);
    };

  
  
  var stringToNewUTF8 = (str) => {
      var size = lengthBytesUTF8(str) + 1;
      var ret = _malloc(size);
      if (ret) stringToUTF8(str, ret, size);
      return ret;
    };
  
  var _SDL_GetError = () => {
      SDL.errorMessage ||= stringToNewUTF8("unknown SDL-emscripten error");
      return SDL.errorMessage;
    };

  
  var _SDL_GetKeyName = (key) => {
      SDL.keyName ||= stringToNewUTF8('unknown key');
      return SDL.keyName;
    };

  /** @param {number} numKeys */
  var _SDL_GetKeyboardState = (numKeys) => {
      if (numKeys) {
        HEAP32[((numKeys)>>2)] = 65536;
      }
      return SDL.keyboardState;
    };

  var _SDL_GetRGB = (pixel, fmt, r, g, b) => {
      SDL.checkPixelFormat(fmt);
      // We assume the machine is little-endian.
      if (r) {
        HEAP8[r] = pixel&0xff;
      }
      if (g) {
        HEAP8[g] = (pixel>>8)&0xff;
      }
      if (b) {
        HEAP8[b] = (pixel>>16)&0xff;
      }
    };


  var _SDL_GetVideoSurface = () => SDL.screen;

  
  
  /** @param{number} initFlags */
  var _SDL_Init = (initFlags) => {
      SDL.startTime = Date.now();
      SDL.initFlags = initFlags;
  
      // capture all key events. we just keep down and up, but also capture press to prevent default actions
      if (!Module['doNotCaptureKeyboard']) {
        var keyboardListeningElement = Module['keyboardListeningElement'] || document;
        keyboardListeningElement.addEventListener("keydown", SDL.receiveEvent);
        keyboardListeningElement.addEventListener("keyup", SDL.receiveEvent);
        keyboardListeningElement.addEventListener("keypress", SDL.receiveEvent);
        window.addEventListener("focus", SDL.receiveEvent);
        window.addEventListener("blur", SDL.receiveEvent);
        document.addEventListener("visibilitychange", SDL.receiveEvent);
      }
  
      window.addEventListener("unload", SDL.receiveEvent);
      SDL.keyboardState = _malloc(0x10000); // Our SDL needs 512, but 64K is safe for older SDLs
      zeroMemory(SDL.keyboardState, 0x10000);
      // Initialize this structure carefully for closure
      SDL.DOMEventToSDLEvent['keydown']    = 0x300  /* SDL_KEYDOWN */;
      SDL.DOMEventToSDLEvent['keyup']      = 0x301  /* SDL_KEYUP */;
      SDL.DOMEventToSDLEvent['keypress']   = 0x303  /* SDL_TEXTINPUT */;
      SDL.DOMEventToSDLEvent['mousedown']  = 0x401  /* SDL_MOUSEBUTTONDOWN */;
      SDL.DOMEventToSDLEvent['mouseup']    = 0x402  /* SDL_MOUSEBUTTONUP */;
      SDL.DOMEventToSDLEvent['mousemove']  = 0x400  /* SDL_MOUSEMOTION */;
      SDL.DOMEventToSDLEvent['wheel']      = 0x403  /* SDL_MOUSEWHEEL */;
      SDL.DOMEventToSDLEvent['touchstart'] = 0x700  /* SDL_FINGERDOWN */;
      SDL.DOMEventToSDLEvent['touchend']   = 0x701  /* SDL_FINGERUP */;
      SDL.DOMEventToSDLEvent['touchmove']  = 0x702  /* SDL_FINGERMOTION */;
      SDL.DOMEventToSDLEvent['unload']     = 0x100  /* SDL_QUIT */;
      SDL.DOMEventToSDLEvent['resize']     = 0x7001 /* SDL_VIDEORESIZE/SDL_EVENT_COMPAT2 */;
      SDL.DOMEventToSDLEvent['visibilitychange'] = 0x200 /* SDL_WINDOWEVENT */;
      SDL.DOMEventToSDLEvent['focus']      = 0x200 /* SDL_WINDOWEVENT */;
      SDL.DOMEventToSDLEvent['blur']       = 0x200 /* SDL_WINDOWEVENT */;
  
      // These are not technically DOM events; the HTML gamepad API is poll-based.
      // However, we define them here, as the rest of the SDL code assumes that
      // all SDL events originate as DOM events.
      SDL.DOMEventToSDLEvent['joystick_axis_motion'] = 0x600 /* SDL_JOYAXISMOTION */;
      SDL.DOMEventToSDLEvent['joystick_button_down'] = 0x603 /* SDL_JOYBUTTONDOWN */;
      SDL.DOMEventToSDLEvent['joystick_button_up'] = 0x604 /* SDL_JOYBUTTONUP */;
      return 0; // success
    };

  var _SDL_JoystickOpen = (deviceIndex) => {
      var gamepad = SDL.getGamepad(deviceIndex);
      if (gamepad) {
        // Use this as a unique 'pointer' for this joystick.
        var joystick = deviceIndex+1;
        SDL.recordJoystickState(joystick, gamepad);
        return joystick;
      }
      return 0;
    };

  var _SDL_ListModes = (format, flags) => -1;


  var _SDL_MapRGB = (fmt, r, g, b) => {
      SDL.checkPixelFormat(fmt);
      // We assume the machine is little-endian.
      return r&0xff|(g&0xff)<<8|(b&0xff)<<16|0xff000000;
    };

  var _SDL_MapRGBA = (fmt, r, g, b, a) => {
      SDL.checkPixelFormat(fmt);
      // We assume the machine is little-endian.
      return r&0xff|(g&0xff)<<8|(b&0xff)<<16|(a&0xff)<<24;
    };

  var _SDL_PollEvent = (ptr) => SDL.pollEvent(ptr);

  var _SDL_AudioQuit = () => {
      for (var i = 0; i < SDL.numChannels; ++i) {
        var chan = /** @type {{ audio: (HTMLMediaElement|undefined) }} */ (SDL.channels[i]);
        if (chan.audio) {
          chan.audio.pause();
          chan.audio = undefined;
        }
      }
      var audio = /** @type {HTMLMediaElement} */ (SDL.music.audio);
      audio?.pause();
      SDL.music.audio = undefined;
    };
  
  var _SDL_Quit = () => {
      _SDL_AudioQuit();
      out('SDL_Quit called (and ignored)');
    };

  var _SDL_SetAlpha = (surf, flag, alpha) => {
      var surfData = SDL.surfaces[surf];
      surfData.alpha = alpha;
  
      if (!(flag & 0x00010000)) { // !SDL_SRCALPHA
        surfData.alpha = 255;
      }
    };

  var _SDL_SetClipRect = (surf, rect) => {
      var surfData = SDL.surfaces[surf];
  
      if (rect) {
        surfData.clipRect = SDL.intersectionOfRects({ x: 0, y: 0, w: surfData.width, h: surfData.height }, SDL.loadRect(rect));
      } else {
        delete surfData.clipRect;
      }
    };

  var _SDL_SetColorKey = (surf, flag, key) => {
      // SetColorKey assigns one color to be rendered as transparent. I don't
      // think the canvas API allows for anything like this, and iterating through
      // each pixel to replace that color seems prohibitively expensive.
      warnOnce('SDL_SetColorKey is a no-op for performance reasons');
      return 0;
    };

  var _SDL_SetColors = (surf, colors, firstColor, nColors) => {
      var surfData = SDL.surfaces[surf];
  
      // we should create colors array
      // only once cause client code
      // often wants to change portion
      // of palette not all palette.
      if (!surfData.colors) {
        var buffer = new ArrayBuffer(256 * 4); // RGBA, A is unused, but faster this way
        surfData.colors = new Uint8Array(buffer);
        surfData.colors32 = new Uint32Array(buffer);
      }
  
      for (var i = 0; i < nColors; ++i) {
        var index = (firstColor + i) * 4;
        surfData.colors[index] = HEAPU8[(colors)+(i*4)];
        surfData.colors[index + 1] = HEAPU8[(colors)+(i*4 + 1)];
        surfData.colors[index + 2] = HEAPU8[(colors)+(i*4 + 2)];
        surfData.colors[index + 3] = 255; // opaque
      }
  
      return 1;
    };
  
  var _SDL_SetPalette = (surf, flags, colors, firstColor, nColors) =>
      _SDL_SetColors(surf, colors, firstColor, nColors);

  var webgl_enable_ANGLE_instanced_arrays = (ctx) => {
      // Extension available in WebGL 1 from Firefox 26 and Google Chrome 30 onwards. Core feature in WebGL 2.
      var ext = ctx.getExtension('ANGLE_instanced_arrays');
      if (ext) {
        ctx['vertexAttribDivisor'] = (index, divisor) => ext['vertexAttribDivisorANGLE'](index, divisor);
        ctx['drawArraysInstanced'] = (mode, first, count, primcount) => ext['drawArraysInstancedANGLE'](mode, first, count, primcount);
        ctx['drawElementsInstanced'] = (mode, count, type, indices, primcount) => ext['drawElementsInstancedANGLE'](mode, count, type, indices, primcount);
        return 1;
      }
    };
  
  var webgl_enable_OES_vertex_array_object = (ctx) => {
      // Extension available in WebGL 1 from Firefox 25 and WebKit 536.28/desktop Safari 6.0.3 onwards. Core feature in WebGL 2.
      var ext = ctx.getExtension('OES_vertex_array_object');
      if (ext) {
        ctx['createVertexArray'] = () => ext['createVertexArrayOES']();
        ctx['deleteVertexArray'] = (vao) => ext['deleteVertexArrayOES'](vao);
        ctx['bindVertexArray'] = (vao) => ext['bindVertexArrayOES'](vao);
        ctx['isVertexArray'] = (vao) => ext['isVertexArrayOES'](vao);
        return 1;
      }
    };
  
  var webgl_enable_WEBGL_draw_buffers = (ctx) => {
      // Extension available in WebGL 1 from Firefox 28 onwards. Core feature in WebGL 2.
      var ext = ctx.getExtension('WEBGL_draw_buffers');
      if (ext) {
        ctx['drawBuffers'] = (n, bufs) => ext['drawBuffersWEBGL'](n, bufs);
        return 1;
      }
    };
  
  var webgl_enable_WEBGL_multi_draw = (ctx) => {
      // Closure is expected to be allowed to minify the '.multiDrawWebgl' property, so not accessing it quoted.
      return !!(ctx.multiDrawWebgl = ctx.getExtension('WEBGL_multi_draw'));
    };
  
  var getEmscriptenSupportedExtensions = (ctx) => {
      // Restrict the list of advertised extensions to those that we actually
      // support.
      var supportedExtensions = [
        // WebGL 1 extensions
        'ANGLE_instanced_arrays',
        'EXT_blend_minmax',
        'EXT_disjoint_timer_query',
        'EXT_frag_depth',
        'EXT_shader_texture_lod',
        'EXT_sRGB',
        'OES_element_index_uint',
        'OES_fbo_render_mipmap',
        'OES_standard_derivatives',
        'OES_texture_float',
        'OES_texture_half_float',
        'OES_texture_half_float_linear',
        'OES_vertex_array_object',
        'WEBGL_color_buffer_float',
        'WEBGL_depth_texture',
        'WEBGL_draw_buffers',
        // WebGL 1 and WebGL 2 extensions
        'EXT_color_buffer_half_float',
        'EXT_depth_clamp',
        'EXT_float_blend',
        'EXT_texture_compression_bptc',
        'EXT_texture_compression_rgtc',
        'EXT_texture_filter_anisotropic',
        'KHR_parallel_shader_compile',
        'OES_texture_float_linear',
        'WEBGL_blend_func_extended',
        'WEBGL_compressed_texture_astc',
        'WEBGL_compressed_texture_etc',
        'WEBGL_compressed_texture_etc1',
        'WEBGL_compressed_texture_s3tc',
        'WEBGL_compressed_texture_s3tc_srgb',
        'WEBGL_debug_renderer_info',
        'WEBGL_debug_shaders',
        'WEBGL_lose_context',
        'WEBGL_multi_draw',
      ];
      // .getSupportedExtensions() can return null if context is lost, so coerce to empty array.
      return (ctx.getSupportedExtensions() || []).filter(ext => supportedExtensions.includes(ext));
    };
  
  
  var GL = {
  counter:1,
  buffers:[],
  programs:[],
  framebuffers:[],
  renderbuffers:[],
  textures:[],
  shaders:[],
  vaos:[],
  contexts:[],
  offscreenCanvases:{
  },
  queries:[],
  stringCache:{
  },
  unpackAlignment:4,
  unpackRowLength:0,
  recordError:(errorCode) => {
        if (!GL.lastError) {
          GL.lastError = errorCode;
        }
      },
  getNewId:(table) => {
        var ret = GL.counter++;
        for (var i = table.length; i < ret; i++) {
          table[i] = null;
        }
        return ret;
      },
  genObject:(n, buffers, createFunction, objectTable
        ) => {
        for (var i = 0; i < n; i++) {
          var buffer = GLctx[createFunction]();
          var id = buffer && GL.getNewId(objectTable);
          if (buffer) {
            buffer.name = id;
            objectTable[id] = buffer;
          } else {
            GL.recordError(0x502 /* GL_INVALID_OPERATION */);
          }
          HEAP32[(((buffers)+(i*4))>>2)] = id;
        }
      },
  getSource:(shader, count, string, length) => {
        var source = '';
        for (var i = 0; i < count; ++i) {
          var len = length ? HEAPU32[(((length)+(i*4))>>2)] : undefined;
          source += UTF8ToString(HEAPU32[(((string)+(i*4))>>2)], len);
        }
        return source;
      },
  createContext:(/** @type {HTMLCanvasElement} */ canvas, webGLContextAttributes) => {
  
        // BUG: Workaround Safari WebGL issue: After successfully acquiring WebGL
        // context on a canvas, calling .getContext() will always return that
        // context independent of which 'webgl' or 'webgl2'
        // context version was passed. See:
        //   https://bugs.webkit.org/show_bug.cgi?id=222758
        // and:
        //   https://github.com/emscripten-core/emscripten/issues/13295.
        // TODO: Once the bug is fixed and shipped in Safari, adjust the Safari
        // version field in above check.
        if (!canvas.getContextSafariWebGL2Fixed) {
          canvas.getContextSafariWebGL2Fixed = canvas.getContext;
          /** @type {function(this:HTMLCanvasElement, string, (Object|null)=): (Object|null)} */
          function fixedGetContext(ver, attrs) {
            var gl = canvas.getContextSafariWebGL2Fixed(ver, attrs);
            return ((ver == 'webgl') == (gl instanceof WebGLRenderingContext)) ? gl : null;
          }
          canvas.getContext = fixedGetContext;
        }
  
        var ctx =
          (canvas.getContext("webgl", webGLContextAttributes)
            // https://caniuse.com/#feat=webgl
            );
  
        if (!ctx) return 0;
  
        var handle = GL.registerContext(ctx, webGLContextAttributes);
  
        return handle;
      },
  registerContext:(ctx, webGLContextAttributes) => {
        // without pthreads a context is just an integer ID
        var handle = GL.getNewId(GL.contexts);
  
        var context = {
          handle,
          attributes: webGLContextAttributes,
          version: webGLContextAttributes.majorVersion,
          GLctx: ctx
        };
  
        // Store the created context object so that we can access the context
        // given a canvas without having to pass the parameters again.
        if (ctx.canvas) ctx.canvas.GLctxObject = context;
        GL.contexts[handle] = context;
        if (typeof webGLContextAttributes.enableExtensionsByDefault == 'undefined' || webGLContextAttributes.enableExtensionsByDefault) {
          GL.initExtensions(context);
        }
  
        return handle;
      },
  makeContextCurrent:(contextHandle) => {
  
        // Active Emscripten GL layer context object.
        GL.currentContext = GL.contexts[contextHandle];
        // Active WebGL context object.
        Module.ctx = GLctx = GL.currentContext?.GLctx;
        return !(contextHandle && !GLctx);
      },
  getContext:(contextHandle) => {
        return GL.contexts[contextHandle];
      },
  deleteContext:(contextHandle) => {
        if (GL.currentContext === GL.contexts[contextHandle]) {
          GL.currentContext = null;
        }
        if (typeof JSEvents == 'object') {
          // Release all JS event handlers on the DOM element that the GL context is
          // associated with since the context is now deleted.
          JSEvents.removeAllHandlersOnTarget(GL.contexts[contextHandle].GLctx.canvas);
        }
        // Make sure the canvas object no longer refers to the context object so
        // there are no GC surprises.
        if (GL.contexts[contextHandle] && GL.contexts[contextHandle].GLctx.canvas) {
          GL.contexts[contextHandle].GLctx.canvas.GLctxObject = undefined;
        }
        GL.contexts[contextHandle] = null;
      },
  initExtensions:(context) => {
        // If this function is called without a specific context object, init the
        // extensions of the currently active context.
        context ||= GL.currentContext;
  
        if (context.initExtensionsDone) return;
        context.initExtensionsDone = true;
  
        var GLctx = context.GLctx;
  
        // Detect the presence of a few extensions manually, ction GL interop
        // layer itself will need to know if they exist.
  
        // Extensions that are only available in WebGL 1 (the calls will be no-ops
        // if called on a WebGL 2 context active)
        webgl_enable_ANGLE_instanced_arrays(GLctx);
        webgl_enable_OES_vertex_array_object(GLctx);
        webgl_enable_WEBGL_draw_buffers(GLctx);
  
        {
          GLctx.disjointTimerQueryExt = GLctx.getExtension("EXT_disjoint_timer_query");
        }
  
        webgl_enable_WEBGL_multi_draw(GLctx);
  
        getEmscriptenSupportedExtensions(GLctx).forEach((ext) => {
          // WEBGL_lose_context, WEBGL_debug_renderer_info and WEBGL_debug_shaders
          // are not enabled by default.
          if (!ext.includes('lose_context') && !ext.includes('debug')) {
            // Call .getExtension() to enable that extension permanently.
            GLctx.getExtension(ext);
          }
        });
      },
  };
  
  var _SDL_SetVideoMode = (width, height, depth, flags) => {
      ['touchstart', 'touchend', 'touchmove',
       'mousedown', 'mouseup', 'mousemove',
       'mousewheel', 'wheel', 'mouseout',
       'DOMMouseScroll',
      ].forEach((e) => Module['canvas'].addEventListener(e, SDL.receiveEvent, true));
  
      var canvas = Module['canvas'];
  
      // (0,0) means 'use fullscreen' in native; in Emscripten, use the current canvas size.
      if (width == 0 && height == 0) {
        width = canvas.width;
        height = canvas.height;
      }
  
      if (!SDL.addedResizeListener) {
        SDL.addedResizeListener = true;
        Browser.resizeListeners.push((w, h) => {
          if (!SDL.settingVideoMode) {
            SDL.receiveEvent({
              type: 'resize',
              w,
              h
            });
          }
        });
      }
  
      SDL.settingVideoMode = true; // SetVideoMode itself should not trigger resize events
      Browser.setCanvasSize(width, height);
      SDL.settingVideoMode = false;
  
      // Free the old surface first if there is one
      if (SDL.screen) {
        SDL.freeSurface(SDL.screen);
        assert(!SDL.screen);
      }
  
      if (SDL.GL) flags = flags | 0x04000000; // SDL_OPENGL - if we are using GL, then later calls to SetVideoMode may not mention GL, but we do need it. Once in GL mode, we never leave it.
  
      SDL.screen = SDL.makeSurface(width, height, flags, true, 'screen');
  
      return SDL.screen;
    };

  var _SDL_ShowCursor = (toggle) => {
      switch (toggle) {
        case 0: // SDL_DISABLE
          if (Browser.isFullscreen) { // only try to lock the pointer when in full screen mode
            Module['canvas'].requestPointerLock();
            return 0;
          }
          // else return SDL_ENABLE to indicate the failure
          return 1;
        case 1: // SDL_ENABLE
          Module['canvas'].exitPointerLock();
          return 1;
        case -1: // SDL_QUERY
          return !Browser.pointerLock;
        default:
          err(`SDL_ShowCursor called with unknown toggle parameter value: ${toggle}`);
          break;
      }
    };

  var _SDL_UnlockSurface = (surf) => {
      assert(!SDL.GL); // in GL mode we do not keep around 2D canvases and contexts
  
      var surfData = SDL.surfaces[surf];
  
      if (!surfData.locked || --surfData.locked > 0) {
        return;
      }
  
      // Copy pixel data to image
      if (surfData.isFlagSet(0x00200000 /* SDL_HWPALETTE */)) {
        SDL.copyIndexedColorData(surfData);
      } else if (!surfData.colors) {
        var data = surfData.image.data;
        var buffer = surfData.buffer;
        assert(buffer % 4 == 0, 'Invalid buffer offset: ' + buffer);
        var src = ((buffer)>>2);
        var dst = 0;
        var isScreen = surf == SDL.screen;
        var num;
        if (typeof CanvasPixelArray != 'undefined' && data instanceof CanvasPixelArray) {
          // IE10/IE11: ImageData objects are backed by the deprecated CanvasPixelArray,
          // not UInt8ClampedArray. These don't have buffers, so we need to revert
          // to copying a byte at a time. We do the undefined check because modern
          // browsers do not define CanvasPixelArray anymore.
          num = data.length;
          while (dst < num) {
            var val = HEAP32[src]; // This is optimized. Instead, we could do HEAP32[(((buffer)+(dst))>>2)];
            data[dst  ] = val & 0xff;
            data[dst+1] = (val >> 8) & 0xff;
            data[dst+2] = (val >> 16) & 0xff;
            data[dst+3] = isScreen ? 0xff : ((val >> 24) & 0xff);
            src++;
            dst += 4;
          }
        } else {
          var data32 = new Uint32Array(data.buffer);
          if (isScreen && SDL.defaults.opaqueFrontBuffer) {
            num = data32.length;
            // logically we need to do
            //      while (dst < num) {
            //          data32[dst++] = HEAP32[src++] | 0xff000000
            //      }
            // the following code is faster though, because
            // .set() is almost free - easily 10x faster due to
            // native memcpy efficiencies, and the remaining loop
            // just stores, not load + store, so it is faster
            data32.set(HEAP32.subarray(src, src + num));
            var data8 = new Uint8Array(data.buffer);
            var i = 3;
            var j = i + 4*num;
            if (num % 8 == 0) {
              // unrolling gives big speedups
              while (i < j) {
                data8[i] = 0xff;
                i = i + 4 | 0;
                data8[i] = 0xff;
                i = i + 4 | 0;
                data8[i] = 0xff;
                i = i + 4 | 0;
                data8[i] = 0xff;
                i = i + 4 | 0;
                data8[i] = 0xff;
                i = i + 4 | 0;
                data8[i] = 0xff;
                i = i + 4 | 0;
                data8[i] = 0xff;
                i = i + 4 | 0;
                data8[i] = 0xff;
                i = i + 4 | 0;
              }
             } else {
              while (i < j) {
                data8[i] = 0xff;
                i = i + 4 | 0;
              }
            }
          } else {
            data32.set(HEAP32.subarray(src, src + data32.length));
          }
        }
      } else {
        var width = Module['canvas'].width;
        var height = Module['canvas'].height;
        var s = surfData.buffer;
        var data = surfData.image.data;
        var colors = surfData.colors; // TODO: optimize using colors32
        for (var y = 0; y < height; y++) {
          var base = y*width*4;
          for (var x = 0; x < width; x++) {
            // See comment above about signs
            var val = HEAPU8[s++] * 4;
            var start = base + x*4;
            data[start]   = colors[val];
            data[start+1] = colors[val+1];
            data[start+2] = colors[val+2];
          }
          s += width*3;
        }
      }
      // Copy to canvas
      surfData.ctx.putImageData(surfData.image, 0, 0);
      // Note that we save the image, so future writes are fast. But, memory is not yet released
    };

  var _SDL_UpdateRects = (surf, numrects, rects) => {
      // We actually do the whole screen in Unlock...
    };

  var _SDL_UpperBlit = (src, srcrect, dst, dstrect) =>
      SDL.blitSurface(src, srcrect, dst, dstrect, false);

  var _SDL_WM_GrabInput = () => {};

  
  var _emscripten_set_window_title = (title) => document.title = UTF8ToString(title);
  
  
  var _SDL_WM_SetCaption = (title, icon) => {
      if (title) {
        _emscripten_set_window_title(title);
      }
      icon &&= UTF8ToString(icon);
    };

  var _SDL_WM_SetIcon = (icon, mask) => {};

  var ___assert_fail = (condition, filename, line, func) => {
      abort(`Assertion failed: ${UTF8ToString(condition)}, at: ` + [filename ? UTF8ToString(filename) : 'unknown filename', line, func ? UTF8ToString(func) : 'unknown function']);
    };

  var exceptionCaught =  [];
  
  
  var uncaughtExceptionCount = 0;
  var ___cxa_begin_catch = (ptr) => {
      var info = new ExceptionInfo(ptr);
      if (!info.get_caught()) {
        info.set_caught(true);
        uncaughtExceptionCount--;
      }
      info.set_rethrown(false);
      exceptionCaught.push(info);
      ___cxa_increment_exception_refcount(info.excPtr);
      return info.get_exception_ptr();
    };

  var ___cxa_call_unexpected = (exception) => abort('Unexpected exception thrown, this is not properly supported - aborting');

  
  var exceptionLast = 0;
  
  
  var ___cxa_end_catch = () => {
      // Clear state flag.
      _setThrew(0, 0);
      assert(exceptionCaught.length > 0);
      // Call destructor if one is registered then clear it.
      var info = exceptionCaught.pop();
  
      ___cxa_decrement_exception_refcount(info.excPtr);
      exceptionLast = 0; // XXX in decRef?
    };

  
  class ExceptionInfo {
      // excPtr - Thrown object pointer to wrap. Metadata pointer is calculated from it.
      constructor(excPtr) {
        this.excPtr = excPtr;
        this.ptr = excPtr - 24;
      }
  
      set_type(type) {
        HEAPU32[(((this.ptr)+(4))>>2)] = type;
      }
  
      get_type() {
        return HEAPU32[(((this.ptr)+(4))>>2)];
      }
  
      set_destructor(destructor) {
        HEAPU32[(((this.ptr)+(8))>>2)] = destructor;
      }
  
      get_destructor() {
        return HEAPU32[(((this.ptr)+(8))>>2)];
      }
  
      set_caught(caught) {
        caught = caught ? 1 : 0;
        HEAP8[(this.ptr)+(12)] = caught;
      }
  
      get_caught() {
        return HEAP8[(this.ptr)+(12)] != 0;
      }
  
      set_rethrown(rethrown) {
        rethrown = rethrown ? 1 : 0;
        HEAP8[(this.ptr)+(13)] = rethrown;
      }
  
      get_rethrown() {
        return HEAP8[(this.ptr)+(13)] != 0;
      }
  
      // Initialize native structure fields. Should be called once after allocated.
      init(type, destructor) {
        this.set_adjusted_ptr(0);
        this.set_type(type);
        this.set_destructor(destructor);
      }
  
      set_adjusted_ptr(adjustedPtr) {
        HEAPU32[(((this.ptr)+(16))>>2)] = adjustedPtr;
      }
  
      get_adjusted_ptr() {
        return HEAPU32[(((this.ptr)+(16))>>2)];
      }
  
      // Get pointer which is expected to be received by catch clause in C++ code. It may be adjusted
      // when the pointer is casted to some of the exception object base classes (e.g. when virtual
      // inheritance is used). When a pointer is thrown this method should return the thrown pointer
      // itself.
      get_exception_ptr() {
        // Work around a fastcomp bug, this code is still included for some reason in a build without
        // exceptions support.
        var isPointer = ___cxa_is_pointer_type(this.get_type());
        if (isPointer) {
          return HEAPU32[((this.excPtr)>>2)];
        }
        var adjusted = this.get_adjusted_ptr();
        if (adjusted !== 0) return adjusted;
        return this.excPtr;
      }
    }
  
  var ___resumeException = (ptr) => {
      if (!exceptionLast) {
        exceptionLast = new CppException(ptr);
      }
      throw exceptionLast;
    };
  
  
  var setTempRet0 = (val) => __emscripten_tempret_set(val);
  var findMatchingCatch = (args) => {
      var thrown =
        exceptionLast?.excPtr;
      if (!thrown) {
        // just pass through the null ptr
        setTempRet0(0);
        return 0;
      }
      var info = new ExceptionInfo(thrown);
      info.set_adjusted_ptr(thrown);
      var thrownType = info.get_type();
      if (!thrownType) {
        // just pass through the thrown ptr
        setTempRet0(0);
        return thrown;
      }
  
      // can_catch receives a **, add indirection
      // The different catch blocks are denoted by different types.
      // Due to inheritance, those types may not precisely match the
      // type of the thrown object. Find one which matches, and
      // return the type of the catch block which should be called.
      for (var caughtType of args) {
        if (caughtType === 0 || caughtType === thrownType) {
          // Catch all clause matched or exactly the same type is caught
          break;
        }
        var adjusted_ptr_addr = info.ptr + 16;
        if (___cxa_can_catch(caughtType, thrownType, adjusted_ptr_addr)) {
          setTempRet0(caughtType);
          return thrown;
        }
      }
      setTempRet0(thrownType);
      return thrown;
    };
  var ___cxa_find_matching_catch_2 = () => findMatchingCatch([]);

  var ___cxa_find_matching_catch_3 = (arg0) => findMatchingCatch([arg0]);

  var ___cxa_find_matching_catch_5 = (arg0,arg1,arg2) => findMatchingCatch([arg0,arg1,arg2]);

  var ___cxa_get_exception_ptr = (ptr) => {
      var rtn = new ExceptionInfo(ptr).get_exception_ptr();
      return rtn;
    };

  
  
  var ___cxa_rethrow = () => {
      var info = exceptionCaught.pop();
      if (!info) {
        abort('no exception to throw');
      }
      var ptr = info.excPtr;
      if (!info.get_rethrown()) {
        // Only pop if the corresponding push was through rethrow_primary_exception
        exceptionCaught.push(info);
        info.set_rethrown(true);
        info.set_caught(false);
        uncaughtExceptionCount++;
      }
      exceptionLast = new CppException(ptr);
      throw exceptionLast;
    };

  
  
  var ___cxa_throw = (ptr, type, destructor) => {
      var info = new ExceptionInfo(ptr);
      // Initialize ExceptionInfo content after it was allocated in __cxa_allocate_exception.
      info.init(type, destructor);
      exceptionLast = new CppException(ptr);
      uncaughtExceptionCount++;
      throw exceptionLast;
    };

  var ___cxa_uncaught_exceptions = () => uncaughtExceptionCount;


  
  
  var SYSCALLS = {
  DEFAULT_POLLMASK:5,
  calculateAt(dirfd, path, allowEmpty) {
        if (PATH.isAbs(path)) {
          return path;
        }
        // relative path
        var dir;
        if (dirfd === -100) {
          dir = FS.cwd();
        } else {
          var dirstream = SYSCALLS.getStreamFromFD(dirfd);
          dir = dirstream.path;
        }
        if (path.length == 0) {
          if (!allowEmpty) {
            throw new FS.ErrnoError(44);;
          }
          return dir;
        }
        return PATH.join2(dir, path);
      },
  doStat(func, path, buf) {
        var stat = func(path);
        HEAP32[((buf)>>2)] = stat.dev;
        HEAP32[(((buf)+(4))>>2)] = stat.mode;
        HEAPU32[(((buf)+(8))>>2)] = stat.nlink;
        HEAP32[(((buf)+(12))>>2)] = stat.uid;
        HEAP32[(((buf)+(16))>>2)] = stat.gid;
        HEAP32[(((buf)+(20))>>2)] = stat.rdev;
        (tempI64 = [stat.size>>>0,(tempDouble = stat.size,(+(Math.abs(tempDouble))) >= 1.0 ? (tempDouble > 0.0 ? (+(Math.floor((tempDouble)/4294967296.0)))>>>0 : (~~((+(Math.ceil((tempDouble - +(((~~(tempDouble)))>>>0))/4294967296.0)))))>>>0) : 0)], HEAP32[(((buf)+(24))>>2)] = tempI64[0],HEAP32[(((buf)+(28))>>2)] = tempI64[1]);
        HEAP32[(((buf)+(32))>>2)] = 4096;
        HEAP32[(((buf)+(36))>>2)] = stat.blocks;
        var atime = stat.atime.getTime();
        var mtime = stat.mtime.getTime();
        var ctime = stat.ctime.getTime();
        (tempI64 = [Math.floor(atime / 1000)>>>0,(tempDouble = Math.floor(atime / 1000),(+(Math.abs(tempDouble))) >= 1.0 ? (tempDouble > 0.0 ? (+(Math.floor((tempDouble)/4294967296.0)))>>>0 : (~~((+(Math.ceil((tempDouble - +(((~~(tempDouble)))>>>0))/4294967296.0)))))>>>0) : 0)], HEAP32[(((buf)+(40))>>2)] = tempI64[0],HEAP32[(((buf)+(44))>>2)] = tempI64[1]);
        HEAPU32[(((buf)+(48))>>2)] = (atime % 1000) * 1000;
        (tempI64 = [Math.floor(mtime / 1000)>>>0,(tempDouble = Math.floor(mtime / 1000),(+(Math.abs(tempDouble))) >= 1.0 ? (tempDouble > 0.0 ? (+(Math.floor((tempDouble)/4294967296.0)))>>>0 : (~~((+(Math.ceil((tempDouble - +(((~~(tempDouble)))>>>0))/4294967296.0)))))>>>0) : 0)], HEAP32[(((buf)+(56))>>2)] = tempI64[0],HEAP32[(((buf)+(60))>>2)] = tempI64[1]);
        HEAPU32[(((buf)+(64))>>2)] = (mtime % 1000) * 1000;
        (tempI64 = [Math.floor(ctime / 1000)>>>0,(tempDouble = Math.floor(ctime / 1000),(+(Math.abs(tempDouble))) >= 1.0 ? (tempDouble > 0.0 ? (+(Math.floor((tempDouble)/4294967296.0)))>>>0 : (~~((+(Math.ceil((tempDouble - +(((~~(tempDouble)))>>>0))/4294967296.0)))))>>>0) : 0)], HEAP32[(((buf)+(72))>>2)] = tempI64[0],HEAP32[(((buf)+(76))>>2)] = tempI64[1]);
        HEAPU32[(((buf)+(80))>>2)] = (ctime % 1000) * 1000;
        (tempI64 = [stat.ino>>>0,(tempDouble = stat.ino,(+(Math.abs(tempDouble))) >= 1.0 ? (tempDouble > 0.0 ? (+(Math.floor((tempDouble)/4294967296.0)))>>>0 : (~~((+(Math.ceil((tempDouble - +(((~~(tempDouble)))>>>0))/4294967296.0)))))>>>0) : 0)], HEAP32[(((buf)+(88))>>2)] = tempI64[0],HEAP32[(((buf)+(92))>>2)] = tempI64[1]);
        return 0;
      },
  doMsync(addr, stream, len, flags, offset) {
        if (!FS.isFile(stream.node.mode)) {
          throw new FS.ErrnoError(43);
        }
        if (flags & 2) {
          // MAP_PRIVATE calls need not to be synced back to underlying fs
          return 0;
        }
        var buffer = HEAPU8.slice(addr, addr + len);
        FS.msync(stream, buffer, offset, len, flags);
      },
  getStreamFromFD(fd) {
        var stream = FS.getStreamChecked(fd);
        return stream;
      },
  varargs:undefined,
  getStr(ptr) {
        var ret = UTF8ToString(ptr);
        return ret;
      },
  };
  function ___syscall_chmod(path, mode) {
  try {
  
      path = SYSCALLS.getStr(path);
      FS.chmod(path, mode);
      return 0;
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return -e.errno;
  }
  }

  function ___syscall_faccessat(dirfd, path, amode, flags) {
  try {
  
      path = SYSCALLS.getStr(path);
      assert(flags === 0);
      path = SYSCALLS.calculateAt(dirfd, path);
      if (amode & ~7) {
        // need a valid mode
        return -28;
      }
      var lookup = FS.lookupPath(path, { follow: true });
      var node = lookup.node;
      if (!node) {
        return -44;
      }
      var perms = '';
      if (amode & 4) perms += 'r';
      if (amode & 2) perms += 'w';
      if (amode & 1) perms += 'x';
      if (perms /* otherwise, they've just passed F_OK */ && FS.nodePermissions(node, perms)) {
        return -2;
      }
      return 0;
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return -e.errno;
  }
  }

  /** @suppress {duplicate } */
  function syscallGetVarargI() {
      assert(SYSCALLS.varargs != undefined);
      // the `+` prepended here is necessary to convince the JSCompiler that varargs is indeed a number.
      var ret = HEAP32[((+SYSCALLS.varargs)>>2)];
      SYSCALLS.varargs += 4;
      return ret;
    }
  var syscallGetVarargP = syscallGetVarargI;
  
  
  function ___syscall_fcntl64(fd, cmd, varargs) {
  SYSCALLS.varargs = varargs;
  try {
  
      var stream = SYSCALLS.getStreamFromFD(fd);
      switch (cmd) {
        case 0: {
          var arg = syscallGetVarargI();
          if (arg < 0) {
            return -28;
          }
          while (FS.streams[arg]) {
            arg++;
          }
          var newStream;
          newStream = FS.dupStream(stream, arg);
          return newStream.fd;
        }
        case 1:
        case 2:
          return 0;  // FD_CLOEXEC makes no sense for a single process.
        case 3:
          return stream.flags;
        case 4: {
          var arg = syscallGetVarargI();
          stream.flags |= arg;
          return 0;
        }
        case 12: {
          var arg = syscallGetVarargP();
          var offset = 0;
          // We're always unlocked.
          HEAP16[(((arg)+(offset))>>1)] = 2;
          return 0;
        }
        case 13:
        case 14:
          return 0; // Pretend that the locking is successful.
      }
      return -28;
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return -e.errno;
  }
  }

  function ___syscall_fstat64(fd, buf) {
  try {
  
      var stream = SYSCALLS.getStreamFromFD(fd);
      return SYSCALLS.doStat(FS.stat, stream.path, buf);
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return -e.errno;
  }
  }

  
  function ___syscall_getdents64(fd, dirp, count) {
  try {
  
      var stream = SYSCALLS.getStreamFromFD(fd)
      stream.getdents ||= FS.readdir(stream.path);
  
      var struct_size = 280;
      var pos = 0;
      var off = FS.llseek(stream, 0, 1);
  
      var idx = Math.floor(off / struct_size);
  
      while (idx < stream.getdents.length && pos + struct_size <= count) {
        var id;
        var type;
        var name = stream.getdents[idx];
        if (name === '.') {
          id = stream.node.id;
          type = 4; // DT_DIR
        }
        else if (name === '..') {
          var lookup = FS.lookupPath(stream.path, { parent: true });
          id = lookup.node.id;
          type = 4; // DT_DIR
        }
        else {
          var child = FS.lookupNode(stream.node, name);
          id = child.id;
          type = FS.isChrdev(child.mode) ? 2 :  // DT_CHR, character device.
                 FS.isDir(child.mode) ? 4 :     // DT_DIR, directory.
                 FS.isLink(child.mode) ? 10 :   // DT_LNK, symbolic link.
                 8;                             // DT_REG, regular file.
        }
        assert(id);
        (tempI64 = [id>>>0,(tempDouble = id,(+(Math.abs(tempDouble))) >= 1.0 ? (tempDouble > 0.0 ? (+(Math.floor((tempDouble)/4294967296.0)))>>>0 : (~~((+(Math.ceil((tempDouble - +(((~~(tempDouble)))>>>0))/4294967296.0)))))>>>0) : 0)], HEAP32[((dirp + pos)>>2)] = tempI64[0],HEAP32[(((dirp + pos)+(4))>>2)] = tempI64[1]);
        (tempI64 = [(idx + 1) * struct_size>>>0,(tempDouble = (idx + 1) * struct_size,(+(Math.abs(tempDouble))) >= 1.0 ? (tempDouble > 0.0 ? (+(Math.floor((tempDouble)/4294967296.0)))>>>0 : (~~((+(Math.ceil((tempDouble - +(((~~(tempDouble)))>>>0))/4294967296.0)))))>>>0) : 0)], HEAP32[(((dirp + pos)+(8))>>2)] = tempI64[0],HEAP32[(((dirp + pos)+(12))>>2)] = tempI64[1]);
        HEAP16[(((dirp + pos)+(16))>>1)] = 280;
        HEAP8[(dirp + pos)+(18)] = type;
        stringToUTF8(name, dirp + pos + 19, 256);
        pos += struct_size;
        idx += 1;
      }
      FS.llseek(stream, idx * struct_size, 0);
      return pos;
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return -e.errno;
  }
  }

  
  function ___syscall_ioctl(fd, op, varargs) {
  SYSCALLS.varargs = varargs;
  try {
  
      var stream = SYSCALLS.getStreamFromFD(fd);
      switch (op) {
        case 21509: {
          if (!stream.tty) return -59;
          return 0;
        }
        case 21505: {
          if (!stream.tty) return -59;
          if (stream.tty.ops.ioctl_tcgets) {
            var termios = stream.tty.ops.ioctl_tcgets(stream);
            var argp = syscallGetVarargP();
            HEAP32[((argp)>>2)] = termios.c_iflag || 0;
            HEAP32[(((argp)+(4))>>2)] = termios.c_oflag || 0;
            HEAP32[(((argp)+(8))>>2)] = termios.c_cflag || 0;
            HEAP32[(((argp)+(12))>>2)] = termios.c_lflag || 0;
            for (var i = 0; i < 32; i++) {
              HEAP8[(argp + i)+(17)] = termios.c_cc[i] || 0;
            }
            return 0;
          }
          return 0;
        }
        case 21510:
        case 21511:
        case 21512: {
          if (!stream.tty) return -59;
          return 0; // no-op, not actually adjusting terminal settings
        }
        case 21506:
        case 21507:
        case 21508: {
          if (!stream.tty) return -59;
          if (stream.tty.ops.ioctl_tcsets) {
            var argp = syscallGetVarargP();
            var c_iflag = HEAP32[((argp)>>2)];
            var c_oflag = HEAP32[(((argp)+(4))>>2)];
            var c_cflag = HEAP32[(((argp)+(8))>>2)];
            var c_lflag = HEAP32[(((argp)+(12))>>2)];
            var c_cc = []
            for (var i = 0; i < 32; i++) {
              c_cc.push(HEAP8[(argp + i)+(17)]);
            }
            return stream.tty.ops.ioctl_tcsets(stream.tty, op, { c_iflag, c_oflag, c_cflag, c_lflag, c_cc });
          }
          return 0; // no-op, not actually adjusting terminal settings
        }
        case 21519: {
          if (!stream.tty) return -59;
          var argp = syscallGetVarargP();
          HEAP32[((argp)>>2)] = 0;
          return 0;
        }
        case 21520: {
          if (!stream.tty) return -59;
          return -28; // not supported
        }
        case 21531: {
          var argp = syscallGetVarargP();
          return FS.ioctl(stream, op, argp);
        }
        case 21523: {
          // TODO: in theory we should write to the winsize struct that gets
          // passed in, but for now musl doesn't read anything on it
          if (!stream.tty) return -59;
          if (stream.tty.ops.ioctl_tiocgwinsz) {
            var winsize = stream.tty.ops.ioctl_tiocgwinsz(stream.tty);
            var argp = syscallGetVarargP();
            HEAP16[((argp)>>1)] = winsize[0];
            HEAP16[(((argp)+(2))>>1)] = winsize[1];
          }
          return 0;
        }
        case 21524: {
          // TODO: technically, this ioctl call should change the window size.
          // but, since emscripten doesn't have any concept of a terminal window
          // yet, we'll just silently throw it away as we do TIOCGWINSZ
          if (!stream.tty) return -59;
          return 0;
        }
        case 21515: {
          if (!stream.tty) return -59;
          return 0;
        }
        default: return -28; // not supported
      }
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return -e.errno;
  }
  }

  function ___syscall_lstat64(path, buf) {
  try {
  
      path = SYSCALLS.getStr(path);
      return SYSCALLS.doStat(FS.lstat, path, buf);
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return -e.errno;
  }
  }

  function ___syscall_mkdirat(dirfd, path, mode) {
  try {
  
      path = SYSCALLS.getStr(path);
      path = SYSCALLS.calculateAt(dirfd, path);
      // remove a trailing slash, if one - /a/b/ has basename of '', but
      // we want to create b in the context of this function
      path = PATH.normalize(path);
      if (path[path.length-1] === '/') path = path.substr(0, path.length-1);
      FS.mkdir(path, mode, 0);
      return 0;
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return -e.errno;
  }
  }

  function ___syscall_newfstatat(dirfd, path, buf, flags) {
  try {
  
      path = SYSCALLS.getStr(path);
      var nofollow = flags & 256;
      var allowEmpty = flags & 4096;
      flags = flags & (~6400);
      assert(!flags, `unknown flags in __syscall_newfstatat: ${flags}`);
      path = SYSCALLS.calculateAt(dirfd, path, allowEmpty);
      return SYSCALLS.doStat(nofollow ? FS.lstat : FS.stat, path, buf);
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return -e.errno;
  }
  }

  
  function ___syscall_openat(dirfd, path, flags, varargs) {
  SYSCALLS.varargs = varargs;
  try {
  
      path = SYSCALLS.getStr(path);
      path = SYSCALLS.calculateAt(dirfd, path);
      var mode = varargs ? syscallGetVarargI() : 0;
      return FS.open(path, flags, mode).fd;
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return -e.errno;
  }
  }

  function ___syscall_renameat(olddirfd, oldpath, newdirfd, newpath) {
  try {
  
      oldpath = SYSCALLS.getStr(oldpath);
      newpath = SYSCALLS.getStr(newpath);
      oldpath = SYSCALLS.calculateAt(olddirfd, oldpath);
      newpath = SYSCALLS.calculateAt(newdirfd, newpath);
      FS.rename(oldpath, newpath);
      return 0;
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return -e.errno;
  }
  }

  function ___syscall_stat64(path, buf) {
  try {
  
      path = SYSCALLS.getStr(path);
      return SYSCALLS.doStat(FS.stat, path, buf);
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return -e.errno;
  }
  }

  var __abort_js = () => {
      abort('native code called abort()');
    };

  var nowIsMonotonic = 1;
  var __emscripten_get_now_is_monotonic = () => nowIsMonotonic;

  var __emscripten_memcpy_js = (dest, src, num) => HEAPU8.copyWithin(dest, src, src + num);

  var __emscripten_throw_longjmp = () => {
      throw new EmscriptenSjLj;
    };

  var isLeapYear = (year) => year%4 === 0 && (year%100 !== 0 || year%400 === 0);
  
  var MONTH_DAYS_LEAP_CUMULATIVE = [0,31,60,91,121,152,182,213,244,274,305,335];
  
  var MONTH_DAYS_REGULAR_CUMULATIVE = [0,31,59,90,120,151,181,212,243,273,304,334];
  var ydayFromDate = (date) => {
      var leap = isLeapYear(date.getFullYear());
      var monthDaysCumulative = (leap ? MONTH_DAYS_LEAP_CUMULATIVE : MONTH_DAYS_REGULAR_CUMULATIVE);
      var yday = monthDaysCumulative[date.getMonth()] + date.getDate() - 1; // -1 since it's days since Jan 1
  
      return yday;
    };
  
  var convertI32PairToI53Checked = (lo, hi) => {
      assert(lo == (lo >>> 0) || lo == (lo|0)); // lo should either be a i32 or a u32
      assert(hi === (hi|0));                    // hi should be a i32
      return ((hi + 0x200000) >>> 0 < 0x400001 - !!lo) ? (lo >>> 0) + hi * 4294967296 : NaN;
    };
  function __localtime_js(time_low, time_high,tmPtr) {
    var time = convertI32PairToI53Checked(time_low, time_high);
  
    
      var date = new Date(time*1000);
      HEAP32[((tmPtr)>>2)] = date.getSeconds();
      HEAP32[(((tmPtr)+(4))>>2)] = date.getMinutes();
      HEAP32[(((tmPtr)+(8))>>2)] = date.getHours();
      HEAP32[(((tmPtr)+(12))>>2)] = date.getDate();
      HEAP32[(((tmPtr)+(16))>>2)] = date.getMonth();
      HEAP32[(((tmPtr)+(20))>>2)] = date.getFullYear()-1900;
      HEAP32[(((tmPtr)+(24))>>2)] = date.getDay();
  
      var yday = ydayFromDate(date)|0;
      HEAP32[(((tmPtr)+(28))>>2)] = yday;
      HEAP32[(((tmPtr)+(36))>>2)] = -(date.getTimezoneOffset() * 60);
  
      // Attention: DST is in December in South, and some regions don't have DST at all.
      var start = new Date(date.getFullYear(), 0, 1);
      var summerOffset = new Date(date.getFullYear(), 6, 1).getTimezoneOffset();
      var winterOffset = start.getTimezoneOffset();
      var dst = (summerOffset != winterOffset && date.getTimezoneOffset() == Math.min(winterOffset, summerOffset))|0;
      HEAP32[(((tmPtr)+(32))>>2)] = dst;
    ;
  }

  
  var __tzset_js = (timezone, daylight, std_name, dst_name) => {
      // TODO: Use (malleable) environment variables instead of system settings.
      var currentYear = new Date().getFullYear();
      var winter = new Date(currentYear, 0, 1);
      var summer = new Date(currentYear, 6, 1);
      var winterOffset = winter.getTimezoneOffset();
      var summerOffset = summer.getTimezoneOffset();
  
      // Local standard timezone offset. Local standard time is not adjusted for
      // daylight savings.  This code uses the fact that getTimezoneOffset returns
      // a greater value during Standard Time versus Daylight Saving Time (DST).
      // Thus it determines the expected output during Standard Time, and it
      // compares whether the output of the given date the same (Standard) or less
      // (DST).
      var stdTimezoneOffset = Math.max(winterOffset, summerOffset);
  
      // timezone is specified as seconds west of UTC ("The external variable
      // `timezone` shall be set to the difference, in seconds, between
      // Coordinated Universal Time (UTC) and local standard time."), the same
      // as returned by stdTimezoneOffset.
      // See http://pubs.opengroup.org/onlinepubs/009695399/functions/tzset.html
      HEAPU32[((timezone)>>2)] = stdTimezoneOffset * 60;
  
      HEAP32[((daylight)>>2)] = Number(winterOffset != summerOffset);
  
      var extractZone = (timezoneOffset) => {
        // Why inverse sign?
        // Read here https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date/getTimezoneOffset
        var sign = timezoneOffset >= 0 ? "-" : "+";
  
        var absOffset = Math.abs(timezoneOffset)
        var hours = String(Math.floor(absOffset / 60)).padStart(2, "0");
        var minutes = String(absOffset % 60).padStart(2, "0");
  
        return `UTC${sign}${hours}${minutes}`;
      }
  
      var winterName = extractZone(winterOffset);
      var summerName = extractZone(summerOffset);
      assert(winterName);
      assert(summerName);
      assert(lengthBytesUTF8(winterName) <= 16, `timezone name truncated to fit in TZNAME_MAX (${winterName})`);
      assert(lengthBytesUTF8(summerName) <= 16, `timezone name truncated to fit in TZNAME_MAX (${summerName})`);
      if (summerOffset < winterOffset) {
        // Northern hemisphere
        stringToUTF8(winterName, std_name, 17);
        stringToUTF8(summerName, dst_name, 17);
      } else {
        stringToUTF8(winterName, dst_name, 17);
        stringToUTF8(summerName, std_name, 17);
      }
    };

  var readEmAsmArgsArray = [];
  var readEmAsmArgs = (sigPtr, buf) => {
      // Nobody should have mutated _readEmAsmArgsArray underneath us to be something else than an array.
      assert(Array.isArray(readEmAsmArgsArray));
      // The input buffer is allocated on the stack, so it must be stack-aligned.
      assert(buf % 16 == 0);
      readEmAsmArgsArray.length = 0;
      var ch;
      // Most arguments are i32s, so shift the buffer pointer so it is a plain
      // index into HEAP32.
      while (ch = HEAPU8[sigPtr++]) {
        var chr = String.fromCharCode(ch);
        var validChars = ['d', 'f', 'i', 'p'];
        assert(validChars.includes(chr), `Invalid character ${ch}("${chr}") in readEmAsmArgs! Use only [${validChars}], and do not specify "v" for void return argument.`);
        // Floats are always passed as doubles, so all types except for 'i'
        // are 8 bytes and require alignment.
        var wide = (ch != 105);
        wide &= (ch != 112);
        buf += wide && (buf % 8) ? 4 : 0;
        readEmAsmArgsArray.push(
          // Special case for pointers under wasm64 or CAN_ADDRESS_2GB mode.
          ch == 112 ? HEAPU32[((buf)>>2)] :
          ch == 105 ?
            HEAP32[((buf)>>2)] :
            HEAPF64[((buf)>>3)]
        );
        buf += wide ? 8 : 4;
      }
      return readEmAsmArgsArray;
    };
  var runEmAsmFunction = (code, sigPtr, argbuf) => {
      var args = readEmAsmArgs(sigPtr, argbuf);
      assert(ASM_CONSTS.hasOwnProperty(code), `No EM_ASM constant found at address ${code}.  The loaded WebAssembly file is likely out of sync with the generated JavaScript.`);
      return ASM_CONSTS[code](...args);
    };
  var _emscripten_asm_const_int = (code, sigPtr, argbuf) => {
      return runEmAsmFunction(code, sigPtr, argbuf);
    };

  var _emscripten_date_now = () => Date.now();


  var getHeapMax = () =>
      // Stay one Wasm page short of 4GB: while e.g. Chrome is able to allocate
      // full 4GB Wasm memories, the size will wrap back to 0 bytes in Wasm side
      // for any code that deals with heap sizes, which would require special
      // casing all heap size related code to treat 0 specially.
      1073741824;
  
  var growMemory = (size) => {
      var b = wasmMemory.buffer;
      var pages = (size - b.byteLength + 65535) / 65536;
      try {
        // round size grow request up to wasm page size (fixed 64KB per spec)
        wasmMemory.grow(pages); // .grow() takes a delta compared to the previous size
        updateMemoryViews();
        return 1 /*success*/;
      } catch(e) {
        err(`growMemory: Attempted to grow heap from ${b.byteLength} bytes to ${size} bytes, but got error: ${e}`);
      }
      // implicit 0 return to save code size (caller will cast "undefined" into 0
      // anyhow)
    };
  var _emscripten_resize_heap = (requestedSize) => {
      var oldSize = HEAPU8.length;
      // With CAN_ADDRESS_2GB or MEMORY64, pointers are already unsigned.
      requestedSize >>>= 0;
      // With multithreaded builds, races can happen (another thread might increase the size
      // in between), so return a failure, and let the caller retry.
      assert(requestedSize > oldSize);
  
      // Memory resize rules:
      // 1.  Always increase heap size to at least the requested size, rounded up
      //     to next page multiple.
      // 2a. If MEMORY_GROWTH_LINEAR_STEP == -1, excessively resize the heap
      //     geometrically: increase the heap size according to
      //     MEMORY_GROWTH_GEOMETRIC_STEP factor (default +20%), At most
      //     overreserve by MEMORY_GROWTH_GEOMETRIC_CAP bytes (default 96MB).
      // 2b. If MEMORY_GROWTH_LINEAR_STEP != -1, excessively resize the heap
      //     linearly: increase the heap size by at least
      //     MEMORY_GROWTH_LINEAR_STEP bytes.
      // 3.  Max size for the heap is capped at 2048MB-WASM_PAGE_SIZE, or by
      //     MAXIMUM_MEMORY, or by ASAN limit, depending on which is smallest
      // 4.  If we were unable to allocate as much memory, it may be due to
      //     over-eager decision to excessively reserve due to (3) above.
      //     Hence if an allocation fails, cut down on the amount of excess
      //     growth, in an attempt to succeed to perform a smaller allocation.
  
      // A limit is set for how much we can grow. We should not exceed that
      // (the wasm binary specifies it, so if we tried, we'd fail anyhow).
      var maxHeapSize = getHeapMax();
      if (requestedSize > maxHeapSize) {
        err(`Cannot enlarge memory, requested ${requestedSize} bytes, but the limit is ${maxHeapSize} bytes!`);
        return false;
      }
  
      var alignUp = (x, multiple) => x + (multiple - x % multiple) % multiple;
  
      // Loop through potential heap size increases. If we attempt a too eager
      // reservation that fails, cut down on the attempted size and reserve a
      // smaller bump instead. (max 3 times, chosen somewhat arbitrarily)
      for (var cutDown = 1; cutDown <= 4; cutDown *= 2) {
        var overGrownHeapSize = oldSize * (1 + 0.2 / cutDown); // ensure geometric growth
        // but limit overreserving (default to capping at +96MB overgrowth at most)
        overGrownHeapSize = Math.min(overGrownHeapSize, requestedSize + 100663296 );
  
        var newSize = Math.min(maxHeapSize, alignUp(Math.max(requestedSize, overGrownHeapSize), 65536));
  
        var replacement = growMemory(newSize);
        if (replacement) {
  
          return true;
        }
      }
      err(`Failed to grow the heap from ${oldSize} bytes to ${newSize} bytes, not enough memory!`);
      return false;
    };


  var ENV = {
  };
  
  var getExecutableName = () => {
      return thisProgram || './this.program';
    };
  var getEnvStrings = () => {
      if (!getEnvStrings.strings) {
        // Default values.
        // Browser language detection #8751
        var lang = ((typeof navigator == 'object' && navigator.languages && navigator.languages[0]) || 'C').replace('-', '_') + '.UTF-8';
        var env = {
          'USER': 'web_user',
          'LOGNAME': 'web_user',
          'PATH': '/',
          'PWD': '/',
          'HOME': '/home/web_user',
          'LANG': lang,
          '_': getExecutableName()
        };
        // Apply the user-provided values, if any.
        for (var x in ENV) {
          // x is a key in ENV; if ENV[x] is undefined, that means it was
          // explicitly set to be so. We allow user code to do that to
          // force variables with default values to remain unset.
          if (ENV[x] === undefined) delete env[x];
          else env[x] = ENV[x];
        }
        var strings = [];
        for (var x in env) {
          strings.push(`${x}=${env[x]}`);
        }
        getEnvStrings.strings = strings;
      }
      return getEnvStrings.strings;
    };
  
  var stringToAscii = (str, buffer) => {
      for (var i = 0; i < str.length; ++i) {
        assert(str.charCodeAt(i) === (str.charCodeAt(i) & 0xff));
        HEAP8[buffer++] = str.charCodeAt(i);
      }
      // Null-terminate the string
      HEAP8[buffer] = 0;
    };
  var _environ_get = (__environ, environ_buf) => {
      var bufSize = 0;
      getEnvStrings().forEach((string, i) => {
        var ptr = environ_buf + bufSize;
        HEAPU32[(((__environ)+(i*4))>>2)] = ptr;
        stringToAscii(string, ptr);
        bufSize += string.length + 1;
      });
      return 0;
    };

  var _environ_sizes_get = (penviron_count, penviron_buf_size) => {
      var strings = getEnvStrings();
      HEAPU32[((penviron_count)>>2)] = strings.length;
      var bufSize = 0;
      strings.forEach((string) => bufSize += string.length + 1);
      HEAPU32[((penviron_buf_size)>>2)] = bufSize;
      return 0;
    };


  function _fd_close(fd) {
  try {
  
      var stream = SYSCALLS.getStreamFromFD(fd);
      FS.close(stream);
      return 0;
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return e.errno;
  }
  }

  /** @param {number=} offset */
  var doReadv = (stream, iov, iovcnt, offset) => {
      var ret = 0;
      for (var i = 0; i < iovcnt; i++) {
        var ptr = HEAPU32[((iov)>>2)];
        var len = HEAPU32[(((iov)+(4))>>2)];
        iov += 8;
        var curr = FS.read(stream, HEAP8, ptr, len, offset);
        if (curr < 0) return -1;
        ret += curr;
        if (curr < len) break; // nothing more to read
        if (typeof offset != 'undefined') {
          offset += curr;
        }
      }
      return ret;
    };
  
  function _fd_read(fd, iov, iovcnt, pnum) {
  try {
  
      var stream = SYSCALLS.getStreamFromFD(fd);
      var num = doReadv(stream, iov, iovcnt);
      HEAPU32[((pnum)>>2)] = num;
      return 0;
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return e.errno;
  }
  }

  
  function _fd_seek(fd,offset_low, offset_high,whence,newOffset) {
    var offset = convertI32PairToI53Checked(offset_low, offset_high);
  
    
  try {
  
      if (isNaN(offset)) return 61;
      var stream = SYSCALLS.getStreamFromFD(fd);
      FS.llseek(stream, offset, whence);
      (tempI64 = [stream.position>>>0,(tempDouble = stream.position,(+(Math.abs(tempDouble))) >= 1.0 ? (tempDouble > 0.0 ? (+(Math.floor((tempDouble)/4294967296.0)))>>>0 : (~~((+(Math.ceil((tempDouble - +(((~~(tempDouble)))>>>0))/4294967296.0)))))>>>0) : 0)], HEAP32[((newOffset)>>2)] = tempI64[0],HEAP32[(((newOffset)+(4))>>2)] = tempI64[1]);
      if (stream.getdents && offset === 0 && whence === 0) stream.getdents = null; // reset readdir state
      return 0;
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return e.errno;
  }
  ;
  }

  /** @param {number=} offset */
  var doWritev = (stream, iov, iovcnt, offset) => {
      var ret = 0;
      for (var i = 0; i < iovcnt; i++) {
        var ptr = HEAPU32[((iov)>>2)];
        var len = HEAPU32[(((iov)+(4))>>2)];
        iov += 8;
        var curr = FS.write(stream, HEAP8, ptr, len, offset);
        if (curr < 0) return -1;
        ret += curr;
        if (typeof offset != 'undefined') {
          offset += curr;
        }
      }
      return ret;
    };
  
  function _fd_write(fd, iov, iovcnt, pnum) {
  try {
  
      var stream = SYSCALLS.getStreamFromFD(fd);
      var num = doWritev(stream, iov, iovcnt);
      HEAPU32[((pnum)>>2)] = num;
      return 0;
    } catch (e) {
    if (typeof FS == 'undefined' || !(e.name === 'ErrnoError')) throw e;
    return e.errno;
  }
  }

  var _llvm_eh_typeid_for = (type) => type;




  var wasmTableMirror = [];
  
  /** @type {WebAssembly.Table} */
  var wasmTable;
  var getWasmTableEntry = (funcPtr) => {
      var func = wasmTableMirror[funcPtr];
      if (!func) {
        if (funcPtr >= wasmTableMirror.length) wasmTableMirror.length = funcPtr + 1;
        wasmTableMirror[funcPtr] = func = wasmTable.get(funcPtr);
      }
      assert(wasmTable.get(funcPtr) == func, 'JavaScript-side Wasm function table mirror is out of date!');
      return func;
    };


  var runAndAbortIfError = (func) => {
      try {
        return func();
      } catch (e) {
        abort(e);
      }
    };
  
  
  var sigToWasmTypes = (sig) => {
      assert(!sig.includes('j'), 'i64 not permitted in function signatures when WASM_BIGINT is disabled');
      var typeNames = {
        'i': 'i32',
        'j': 'i64',
        'f': 'f32',
        'd': 'f64',
        'e': 'externref',
        'p': 'i32',
      };
      var type = {
        parameters: [],
        results: sig[0] == 'v' ? [] : [typeNames[sig[0]]]
      };
      for (var i = 1; i < sig.length; ++i) {
        assert(sig[i] in typeNames, 'invalid signature char: ' + sig[i]);
        type.parameters.push(typeNames[sig[i]]);
      }
      return type;
    };
  
  var runtimeKeepalivePush = () => {
      runtimeKeepaliveCounter += 1;
    };
  
  var runtimeKeepalivePop = () => {
      assert(runtimeKeepaliveCounter > 0);
      runtimeKeepaliveCounter -= 1;
    };
  
  
  var Asyncify = {
  instrumentWasmImports(imports) {
        var importPattern = /^(invoke_.*|__asyncjs__.*)$/;
  
        for (let [x, original] of Object.entries(imports)) {
          if (typeof original == 'function') {
            let isAsyncifyImport = original.isAsync || importPattern.test(x);
            imports[x] = (...args) => {
              var originalAsyncifyState = Asyncify.state;
              try {
                return original(...args);
              } finally {
                // Only asyncify-declared imports are allowed to change the
                // state.
                // Changing the state from normal to disabled is allowed (in any
                // function) as that is what shutdown does (and we don't have an
                // explicit list of shutdown imports).
                var changedToDisabled =
                      originalAsyncifyState === Asyncify.State.Normal &&
                      Asyncify.state        === Asyncify.State.Disabled;
                // invoke_* functions are allowed to change the state if we do
                // not ignore indirect calls.
                var ignoredInvoke = x.startsWith('invoke_') &&
                                    true;
                if (Asyncify.state !== originalAsyncifyState &&
                    !isAsyncifyImport &&
                    !changedToDisabled &&
                    !ignoredInvoke) {
                  throw new Error(`import ${x} was not in ASYNCIFY_IMPORTS, but changed the state`);
                }
              }
            };
          }
        }
      },
  instrumentWasmExports(exports) {
        var ret = {};
        for (let [x, original] of Object.entries(exports)) {
          if (typeof original == 'function') {
            ret[x] = (...args) => {
              Asyncify.exportCallStack.push(x);
              try {
                return original(...args);
              } finally {
                if (!ABORT) {
                  var y = Asyncify.exportCallStack.pop();
                  assert(y === x);
                  Asyncify.maybeStopUnwind();
                }
              }
            };
          } else {
            ret[x] = original;
          }
        }
        return ret;
      },
  State:{
  Normal:0,
  Unwinding:1,
  Rewinding:2,
  Disabled:3,
  },
  state:0,
  StackSize:65536,
  currData:null,
  handleSleepReturnValue:0,
  exportCallStack:[],
  callStackNameToId:{
  },
  callStackIdToName:{
  },
  callStackId:0,
  asyncPromiseHandlers:null,
  sleepCallbacks:[],
  getCallStackId(funcName) {
        var id = Asyncify.callStackNameToId[funcName];
        if (id === undefined) {
          id = Asyncify.callStackId++;
          Asyncify.callStackNameToId[funcName] = id;
          Asyncify.callStackIdToName[id] = funcName;
        }
        return id;
      },
  maybeStopUnwind() {
        if (Asyncify.currData &&
            Asyncify.state === Asyncify.State.Unwinding &&
            Asyncify.exportCallStack.length === 0) {
          // We just finished unwinding.
          // Be sure to set the state before calling any other functions to avoid
          // possible infinite recursion here (For example in debug pthread builds
          // the dbg() function itself can call back into WebAssembly to get the
          // current pthread_self() pointer).
          Asyncify.state = Asyncify.State.Normal;
          
          // Keep the runtime alive so that a re-wind can be done later.
          runAndAbortIfError(_asyncify_stop_unwind);
          if (typeof Fibers != 'undefined') {
            Fibers.trampoline();
          }
        }
      },
  whenDone() {
        assert(Asyncify.currData, 'Tried to wait for an async operation when none is in progress.');
        assert(!Asyncify.asyncPromiseHandlers, 'Cannot have multiple async operations in flight at once');
        return new Promise((resolve, reject) => {
          Asyncify.asyncPromiseHandlers = { resolve, reject };
        });
      },
  allocateData() {
        // An asyncify data structure has three fields:
        //  0  current stack pos
        //  4  max stack pos
        //  8  id of function at bottom of the call stack (callStackIdToName[id] == name of js function)
        //
        // The Asyncify ABI only interprets the first two fields, the rest is for the runtime.
        // We also embed a stack in the same memory region here, right next to the structure.
        // This struct is also defined as asyncify_data_t in emscripten/fiber.h
        var ptr = _malloc(12 + Asyncify.StackSize);
        Asyncify.setDataHeader(ptr, ptr + 12, Asyncify.StackSize);
        Asyncify.setDataRewindFunc(ptr);
        return ptr;
      },
  setDataHeader(ptr, stack, stackSize) {
        HEAPU32[((ptr)>>2)] = stack;
        HEAPU32[(((ptr)+(4))>>2)] = stack + stackSize;
      },
  setDataRewindFunc(ptr) {
        var bottomOfCallStack = Asyncify.exportCallStack[0];
        var rewindId = Asyncify.getCallStackId(bottomOfCallStack);
        HEAP32[(((ptr)+(8))>>2)] = rewindId;
      },
  getDataRewindFuncName(ptr) {
        var id = HEAP32[(((ptr)+(8))>>2)];
        var name = Asyncify.callStackIdToName[id];
        return name;
      },
  getDataRewindFunc(name) {
        var func = wasmExports[name];
        return func;
      },
  doRewind(ptr) {
        var name = Asyncify.getDataRewindFuncName(ptr);
        var func = Asyncify.getDataRewindFunc(name);
        // Once we have rewound and the stack we no longer need to artificially
        // keep the runtime alive.
        
        return func();
      },
  handleSleep(startAsync) {
        assert(Asyncify.state !== Asyncify.State.Disabled, 'Asyncify cannot be done during or after the runtime exits');
        if (ABORT) return;
        if (Asyncify.state === Asyncify.State.Normal) {
          // Prepare to sleep. Call startAsync, and see what happens:
          // if the code decided to call our callback synchronously,
          // then no async operation was in fact begun, and we don't
          // need to do anything.
          var reachedCallback = false;
          var reachedAfterCallback = false;
          startAsync((handleSleepReturnValue = 0) => {
            assert(!handleSleepReturnValue || typeof handleSleepReturnValue == 'number' || typeof handleSleepReturnValue == 'boolean'); // old emterpretify API supported other stuff
            if (ABORT) return;
            Asyncify.handleSleepReturnValue = handleSleepReturnValue;
            reachedCallback = true;
            if (!reachedAfterCallback) {
              // We are happening synchronously, so no need for async.
              return;
            }
            // This async operation did not happen synchronously, so we did
            // unwind. In that case there can be no compiled code on the stack,
            // as it might break later operations (we can rewind ok now, but if
            // we unwind again, we would unwind through the extra compiled code
            // too).
            assert(!Asyncify.exportCallStack.length, 'Waking up (starting to rewind) must be done from JS, without compiled code on the stack.');
            Asyncify.state = Asyncify.State.Rewinding;
            runAndAbortIfError(() => _asyncify_start_rewind(Asyncify.currData));
            if (typeof Browser != 'undefined' && Browser.mainLoop.func) {
              Browser.mainLoop.resume();
            }
            var asyncWasmReturnValue, isError = false;
            try {
              asyncWasmReturnValue = Asyncify.doRewind(Asyncify.currData);
            } catch (err) {
              asyncWasmReturnValue = err;
              isError = true;
            }
            // Track whether the return value was handled by any promise handlers.
            var handled = false;
            if (!Asyncify.currData) {
              // All asynchronous execution has finished.
              // `asyncWasmReturnValue` now contains the final
              // return value of the exported async WASM function.
              //
              // Note: `asyncWasmReturnValue` is distinct from
              // `Asyncify.handleSleepReturnValue`.
              // `Asyncify.handleSleepReturnValue` contains the return
              // value of the last C function to have executed
              // `Asyncify.handleSleep()`, where as `asyncWasmReturnValue`
              // contains the return value of the exported WASM function
              // that may have called C functions that
              // call `Asyncify.handleSleep()`.
              var asyncPromiseHandlers = Asyncify.asyncPromiseHandlers;
              if (asyncPromiseHandlers) {
                Asyncify.asyncPromiseHandlers = null;
                (isError ? asyncPromiseHandlers.reject : asyncPromiseHandlers.resolve)(asyncWasmReturnValue);
                handled = true;
              }
            }
            if (isError && !handled) {
              // If there was an error and it was not handled by now, we have no choice but to
              // rethrow that error into the global scope where it can be caught only by
              // `onerror` or `onunhandledpromiserejection`.
              throw asyncWasmReturnValue;
            }
          });
          reachedAfterCallback = true;
          if (!reachedCallback) {
            // A true async operation was begun; start a sleep.
            Asyncify.state = Asyncify.State.Unwinding;
            // TODO: reuse, don't alloc/free every sleep
            Asyncify.currData = Asyncify.allocateData();
            if (typeof Browser != 'undefined' && Browser.mainLoop.func) {
              Browser.mainLoop.pause();
            }
            runAndAbortIfError(() => _asyncify_start_unwind(Asyncify.currData));
          }
        } else if (Asyncify.state === Asyncify.State.Rewinding) {
          // Stop a resume.
          Asyncify.state = Asyncify.State.Normal;
          runAndAbortIfError(_asyncify_stop_rewind);
          _free(Asyncify.currData);
          Asyncify.currData = null;
          // Call all sleep callbacks now that the sleep-resume is all done.
          Asyncify.sleepCallbacks.forEach(callUserCallback);
        } else {
          abort(`invalid state: ${Asyncify.state}`);
        }
        return Asyncify.handleSleepReturnValue;
      },
  handleAsync(startAsync) {
        return Asyncify.handleSleep((wakeUp) => {
          // TODO: add error handling as a second param when handleSleep implements it.
          startAsync().then(wakeUp);
        });
      },
  };

  var FS_createPath = FS.createPath;



  var FS_unlink = (path) => FS.unlink(path);

  var FS_createLazyFile = FS.createLazyFile;

  var FS_createDevice = FS.createDevice;

  var incrementExceptionRefcount = (ptr) => ___cxa_increment_exception_refcount(ptr);
  Module['incrementExceptionRefcount'] = incrementExceptionRefcount;

  var decrementExceptionRefcount = (ptr) => ___cxa_decrement_exception_refcount(ptr);
  Module['decrementExceptionRefcount'] = decrementExceptionRefcount;

  
  
  
  
  
  var getExceptionMessageCommon = (ptr) => {
      var sp = stackSave();
      var type_addr_addr = stackAlloc(4);
      var message_addr_addr = stackAlloc(4);
      ___get_exception_message(ptr, type_addr_addr, message_addr_addr);
      var type_addr = HEAPU32[((type_addr_addr)>>2)];
      var message_addr = HEAPU32[((message_addr_addr)>>2)];
      var type = UTF8ToString(type_addr);
      _free(type_addr);
      var message;
      if (message_addr) {
        message = UTF8ToString(message_addr);
        _free(message_addr);
      }
      stackRestore(sp);
      return [type, message];
    };
  var getExceptionMessage = (ptr) => getExceptionMessageCommon(ptr);
  Module['getExceptionMessage'] = getExceptionMessage;

      // exports
      Module["requestFullscreen"] = Browser.requestFullscreen;
      Module["requestFullScreen"] = Browser.requestFullScreen;
      Module["requestAnimationFrame"] = Browser.requestAnimationFrame;
      Module["setCanvasSize"] = Browser.setCanvasSize;
      Module["pauseMainLoop"] = Browser.mainLoop.pause;
      Module["resumeMainLoop"] = Browser.mainLoop.resume;
      Module["getUserMedia"] = Browser.getUserMedia;
      Module["createContext"] = Browser.createContext;
      var preloadedImages = {};
      var preloadedAudios = {};;

  FS.createPreloadedFile = FS_createPreloadedFile;
  FS.staticInit();Module["FS_createPath"] = FS.createPath;Module["FS_createDataFile"] = FS.createDataFile;Module["FS_createPreloadedFile"] = FS.createPreloadedFile;Module["FS_unlink"] = FS.unlink;Module["FS_createLazyFile"] = FS.createLazyFile;Module["FS_createDevice"] = FS.createDevice;;
var GLctx;;
function checkIncomingModuleAPI() {
  ignoredModuleProp('fetchSettings');
}
var wasmImports = {
  /** @export */
  IMG_Load: _IMG_Load,
  /** @export */
  Mix_CloseAudio: _Mix_CloseAudio,
  /** @export */
  Mix_FreeChunk: _Mix_FreeChunk,
  /** @export */
  Mix_FreeMusic: _Mix_FreeMusic,
  /** @export */
  Mix_HaltMusic: _Mix_HaltMusic,
  /** @export */
  Mix_LoadMUS: _Mix_LoadMUS,
  /** @export */
  Mix_LoadWAV: _Mix_LoadWAV,
  /** @export */
  Mix_OpenAudio: _Mix_OpenAudio,
  /** @export */
  Mix_PlayChannelTimed: _Mix_PlayChannelTimed,
  /** @export */
  Mix_PlayMusic: _Mix_PlayMusic,
  /** @export */
  Mix_SetPanning: _Mix_SetPanning,
  /** @export */
  Mix_Volume: _Mix_Volume,
  /** @export */
  Mix_VolumeMusic: _Mix_VolumeMusic,
  /** @export */
  SDL_ConvertSurface: _SDL_ConvertSurface,
  /** @export */
  SDL_CreateRGBSurface: _SDL_CreateRGBSurface,
  /** @export */
  SDL_Delay: _SDL_Delay,
  /** @export */
  SDL_DisplayFormatAlpha: _SDL_DisplayFormatAlpha,
  /** @export */
  SDL_EnableKeyRepeat: _SDL_EnableKeyRepeat,
  /** @export */
  SDL_EnableUNICODE: _SDL_EnableUNICODE,
  /** @export */
  SDL_FillRect: _SDL_FillRect,
  /** @export */
  SDL_Flip: _SDL_Flip,
  /** @export */
  SDL_FreeSurface: _SDL_FreeSurface,
  /** @export */
  SDL_GetClipRect: _SDL_GetClipRect,
  /** @export */
  SDL_GetError: _SDL_GetError,
  /** @export */
  SDL_GetKeyName: _SDL_GetKeyName,
  /** @export */
  SDL_GetKeyboardState: _SDL_GetKeyboardState,
  /** @export */
  SDL_GetRGB: _SDL_GetRGB,
  /** @export */
  SDL_GetTicks: _SDL_GetTicks,
  /** @export */
  SDL_GetVideoSurface: _SDL_GetVideoSurface,
  /** @export */
  SDL_Init: _SDL_Init,
  /** @export */
  SDL_JoystickOpen: _SDL_JoystickOpen,
  /** @export */
  SDL_ListModes: _SDL_ListModes,
  /** @export */
  SDL_LockSurface: _SDL_LockSurface,
  /** @export */
  SDL_MapRGB: _SDL_MapRGB,
  /** @export */
  SDL_MapRGBA: _SDL_MapRGBA,
  /** @export */
  SDL_PollEvent: _SDL_PollEvent,
  /** @export */
  SDL_Quit: _SDL_Quit,
  /** @export */
  SDL_SetAlpha: _SDL_SetAlpha,
  /** @export */
  SDL_SetClipRect: _SDL_SetClipRect,
  /** @export */
  SDL_SetColorKey: _SDL_SetColorKey,
  /** @export */
  SDL_SetPalette: _SDL_SetPalette,
  /** @export */
  SDL_SetVideoMode: _SDL_SetVideoMode,
  /** @export */
  SDL_ShowCursor: _SDL_ShowCursor,
  /** @export */
  SDL_UnlockSurface: _SDL_UnlockSurface,
  /** @export */
  SDL_UpdateRects: _SDL_UpdateRects,
  /** @export */
  SDL_UpperBlit: _SDL_UpperBlit,
  /** @export */
  SDL_WM_GrabInput: _SDL_WM_GrabInput,
  /** @export */
  SDL_WM_SetCaption: _SDL_WM_SetCaption,
  /** @export */
  SDL_WM_SetIcon: _SDL_WM_SetIcon,
  /** @export */
  __assert_fail: ___assert_fail,
  /** @export */
  __cxa_begin_catch: ___cxa_begin_catch,
  /** @export */
  __cxa_call_unexpected: ___cxa_call_unexpected,
  /** @export */
  __cxa_end_catch: ___cxa_end_catch,
  /** @export */
  __cxa_find_matching_catch_2: ___cxa_find_matching_catch_2,
  /** @export */
  __cxa_find_matching_catch_3: ___cxa_find_matching_catch_3,
  /** @export */
  __cxa_find_matching_catch_5: ___cxa_find_matching_catch_5,
  /** @export */
  __cxa_get_exception_ptr: ___cxa_get_exception_ptr,
  /** @export */
  __cxa_rethrow: ___cxa_rethrow,
  /** @export */
  __cxa_throw: ___cxa_throw,
  /** @export */
  __cxa_uncaught_exceptions: ___cxa_uncaught_exceptions,
  /** @export */
  __resumeException: ___resumeException,
  /** @export */
  __syscall_chmod: ___syscall_chmod,
  /** @export */
  __syscall_faccessat: ___syscall_faccessat,
  /** @export */
  __syscall_fcntl64: ___syscall_fcntl64,
  /** @export */
  __syscall_fstat64: ___syscall_fstat64,
  /** @export */
  __syscall_getdents64: ___syscall_getdents64,
  /** @export */
  __syscall_ioctl: ___syscall_ioctl,
  /** @export */
  __syscall_lstat64: ___syscall_lstat64,
  /** @export */
  __syscall_mkdirat: ___syscall_mkdirat,
  /** @export */
  __syscall_newfstatat: ___syscall_newfstatat,
  /** @export */
  __syscall_openat: ___syscall_openat,
  /** @export */
  __syscall_renameat: ___syscall_renameat,
  /** @export */
  __syscall_stat64: ___syscall_stat64,
  /** @export */
  _abort_js: __abort_js,
  /** @export */
  _emscripten_get_now_is_monotonic: __emscripten_get_now_is_monotonic,
  /** @export */
  _emscripten_memcpy_js: __emscripten_memcpy_js,
  /** @export */
  _emscripten_throw_longjmp: __emscripten_throw_longjmp,
  /** @export */
  _localtime_js: __localtime_js,
  /** @export */
  _tzset_js: __tzset_js,
  /** @export */
  emscripten_asm_const_int: _emscripten_asm_const_int,
  /** @export */
  emscripten_date_now: _emscripten_date_now,
  /** @export */
  emscripten_get_now: _emscripten_get_now,
  /** @export */
  emscripten_resize_heap: _emscripten_resize_heap,
  /** @export */
  emscripten_sleep: _emscripten_sleep,
  /** @export */
  environ_get: _environ_get,
  /** @export */
  environ_sizes_get: _environ_sizes_get,
  /** @export */
  exit: _exit,
  /** @export */
  fd_close: _fd_close,
  /** @export */
  fd_read: _fd_read,
  /** @export */
  fd_seek: _fd_seek,
  /** @export */
  fd_write: _fd_write,
  /** @export */
  invoke_diii,
  /** @export */
  invoke_ff,
  /** @export */
  invoke_fi,
  /** @export */
  invoke_fii,
  /** @export */
  invoke_fiii,
  /** @export */
  invoke_i,
  /** @export */
  invoke_ii,
  /** @export */
  invoke_iif,
  /** @export */
  invoke_iii,
  /** @export */
  invoke_iiii,
  /** @export */
  invoke_iiiif,
  /** @export */
  invoke_iiiii,
  /** @export */
  invoke_iiiiid,
  /** @export */
  invoke_iiiiif,
  /** @export */
  invoke_iiiiii,
  /** @export */
  invoke_iiiiiif,
  /** @export */
  invoke_iiiiiii,
  /** @export */
  invoke_iiiiiiii,
  /** @export */
  invoke_iiiiiiiii,
  /** @export */
  invoke_iiiiiiiiiii,
  /** @export */
  invoke_iiiiiiiiiiii,
  /** @export */
  invoke_iiiiiiiiiiiii,
  /** @export */
  invoke_ji,
  /** @export */
  invoke_jiiii,
  /** @export */
  invoke_v,
  /** @export */
  invoke_vi,
  /** @export */
  invoke_vif,
  /** @export */
  invoke_viff,
  /** @export */
  invoke_vifi,
  /** @export */
  invoke_vii,
  /** @export */
  invoke_viiffff,
  /** @export */
  invoke_viifi,
  /** @export */
  invoke_viii,
  /** @export */
  invoke_viiif,
  /** @export */
  invoke_viiii,
  /** @export */
  invoke_viiiif,
  /** @export */
  invoke_viiiii,
  /** @export */
  invoke_viiiiii,
  /** @export */
  invoke_viiiiiii,
  /** @export */
  invoke_viiiiiiii,
  /** @export */
  invoke_viiiiiiiii,
  /** @export */
  invoke_viiiiiiiiii,
  /** @export */
  invoke_viiiiiiiiiiiiiii,
  /** @export */
  llvm_eh_typeid_for: _llvm_eh_typeid_for
};
var wasmExports = createWasm();
var ___wasm_call_ctors = createExportWrapper('__wasm_call_ctors', 0);
var ___cxa_free_exception = createExportWrapper('__cxa_free_exception', 1);
var _strerror = createExportWrapper('strerror', 1);
var _memcpy = createExportWrapper('memcpy', 3);
var _main = Module['_main'] = createExportWrapper('__main_argc_argv', 2);
var _free = createExportWrapper('free', 1);
var _malloc = createExportWrapper('malloc', 1);
var _fflush = createExportWrapper('fflush', 1);
var _fileno = createExportWrapper('fileno', 1);
var _setThrew = createExportWrapper('setThrew', 2);
var __emscripten_tempret_set = createExportWrapper('_emscripten_tempret_set', 1);
var _emscripten_stack_init = () => (_emscripten_stack_init = wasmExports['emscripten_stack_init'])();
var _emscripten_stack_get_free = () => (_emscripten_stack_get_free = wasmExports['emscripten_stack_get_free'])();
var _emscripten_stack_get_base = () => (_emscripten_stack_get_base = wasmExports['emscripten_stack_get_base'])();
var _emscripten_stack_get_end = () => (_emscripten_stack_get_end = wasmExports['emscripten_stack_get_end'])();
var __emscripten_stack_restore = (a0) => (__emscripten_stack_restore = wasmExports['_emscripten_stack_restore'])(a0);
var __emscripten_stack_alloc = (a0) => (__emscripten_stack_alloc = wasmExports['_emscripten_stack_alloc'])(a0);
var _emscripten_stack_get_current = () => (_emscripten_stack_get_current = wasmExports['emscripten_stack_get_current'])();
var ___cxa_decrement_exception_refcount = createExportWrapper('__cxa_decrement_exception_refcount', 1);
var ___cxa_increment_exception_refcount = createExportWrapper('__cxa_increment_exception_refcount', 1);
var ___get_exception_message = createExportWrapper('__get_exception_message', 3);
var ___cxa_can_catch = createExportWrapper('__cxa_can_catch', 3);
var ___cxa_is_pointer_type = createExportWrapper('__cxa_is_pointer_type', 1);
var dynCall_viii = Module['dynCall_viii'] = createExportWrapper('dynCall_viii', 4);
var dynCall_iii = Module['dynCall_iii'] = createExportWrapper('dynCall_iii', 3);
var dynCall_vii = Module['dynCall_vii'] = createExportWrapper('dynCall_vii', 3);
var dynCall_iiiiiii = Module['dynCall_iiiiiii'] = createExportWrapper('dynCall_iiiiiii', 7);
var dynCall_vi = Module['dynCall_vi'] = createExportWrapper('dynCall_vi', 2);
var dynCall_v = Module['dynCall_v'] = createExportWrapper('dynCall_v', 1);
var dynCall_ii = Module['dynCall_ii'] = createExportWrapper('dynCall_ii', 2);
var dynCall_iiii = Module['dynCall_iiii'] = createExportWrapper('dynCall_iiii', 4);
var dynCall_iiiiii = Module['dynCall_iiiiii'] = createExportWrapper('dynCall_iiiiii', 6);
var dynCall_viiii = Module['dynCall_viiii'] = createExportWrapper('dynCall_viiii', 5);
var dynCall_viiiiii = Module['dynCall_viiiiii'] = createExportWrapper('dynCall_viiiiii', 7);
var dynCall_iiiii = Module['dynCall_iiiii'] = createExportWrapper('dynCall_iiiii', 5);
var dynCall_viiiii = Module['dynCall_viiiii'] = createExportWrapper('dynCall_viiiii', 6);
var dynCall_i = Module['dynCall_i'] = createExportWrapper('dynCall_i', 1);
var dynCall_iiiiiif = Module['dynCall_iiiiiif'] = createExportWrapper('dynCall_iiiiiif', 7);
var dynCall_fi = Module['dynCall_fi'] = createExportWrapper('dynCall_fi', 2);
var dynCall_viiiiiiiii = Module['dynCall_viiiiiiiii'] = createExportWrapper('dynCall_viiiiiiiii', 10);
var dynCall_iiiiiiiii = Module['dynCall_iiiiiiiii'] = createExportWrapper('dynCall_iiiiiiiii', 9);
var dynCall_viiiiiiii = Module['dynCall_viiiiiiii'] = createExportWrapper('dynCall_viiiiiiii', 9);
var dynCall_viijii = Module['dynCall_viijii'] = createExportWrapper('dynCall_viijii', 7);
var dynCall_vif = Module['dynCall_vif'] = createExportWrapper('dynCall_vif', 3);
var dynCall_viff = Module['dynCall_viff'] = createExportWrapper('dynCall_viff', 4);
var dynCall_iif = Module['dynCall_iif'] = createExportWrapper('dynCall_iif', 3);
var dynCall_vifi = Module['dynCall_vifi'] = createExportWrapper('dynCall_vifi', 4);
var dynCall_viifi = Module['dynCall_viifi'] = createExportWrapper('dynCall_viifi', 5);
var dynCall_viiff = Module['dynCall_viiff'] = createExportWrapper('dynCall_viiff', 5);
var dynCall_viiif = Module['dynCall_viiif'] = createExportWrapper('dynCall_viiif', 5);
var dynCall_ff = Module['dynCall_ff'] = createExportWrapper('dynCall_ff', 2);
var dynCall_viiiif = Module['dynCall_viiiif'] = createExportWrapper('dynCall_viiiif', 6);
var dynCall_iiiif = Module['dynCall_iiiif'] = createExportWrapper('dynCall_iiiif', 5);
var dynCall_viiiiiii = Module['dynCall_viiiiiii'] = createExportWrapper('dynCall_viiiiiii', 8);
var dynCall_fii = Module['dynCall_fii'] = createExportWrapper('dynCall_fii', 3);
var dynCall_ji = Module['dynCall_ji'] = createExportWrapper('dynCall_ji', 2);
var dynCall_viiffff = Module['dynCall_viiffff'] = createExportWrapper('dynCall_viiffff', 7);
var dynCall_iiiiif = Module['dynCall_iiiiif'] = createExportWrapper('dynCall_iiiiif', 6);
var dynCall_viif = Module['dynCall_viif'] = createExportWrapper('dynCall_viif', 4);
var dynCall_jiji = Module['dynCall_jiji'] = createExportWrapper('dynCall_jiji', 5);
var dynCall_iidiiii = Module['dynCall_iidiiii'] = createExportWrapper('dynCall_iidiiii', 7);
var dynCall_iiiiid = Module['dynCall_iiiiid'] = createExportWrapper('dynCall_iiiiid', 6);
var dynCall_iiiiiiii = Module['dynCall_iiiiiiii'] = createExportWrapper('dynCall_iiiiiiii', 8);
var dynCall_iiiiiiiiiii = Module['dynCall_iiiiiiiiiii'] = createExportWrapper('dynCall_iiiiiiiiiii', 11);
var dynCall_jiiii = Module['dynCall_jiiii'] = createExportWrapper('dynCall_jiiii', 5);
var dynCall_iiiiiiiiiiiii = Module['dynCall_iiiiiiiiiiiii'] = createExportWrapper('dynCall_iiiiiiiiiiiii', 13);
var dynCall_fiii = Module['dynCall_fiii'] = createExportWrapper('dynCall_fiii', 4);
var dynCall_diii = Module['dynCall_diii'] = createExportWrapper('dynCall_diii', 4);
var dynCall_iiiiiiiiiiii = Module['dynCall_iiiiiiiiiiii'] = createExportWrapper('dynCall_iiiiiiiiiiii', 12);
var dynCall_viiiiiiiiii = Module['dynCall_viiiiiiiiii'] = createExportWrapper('dynCall_viiiiiiiiii', 11);
var dynCall_viiiiiiiiiiiiiii = Module['dynCall_viiiiiiiiiiiiiii'] = createExportWrapper('dynCall_viiiiiiiiiiiiiii', 16);
var dynCall_iiiiij = Module['dynCall_iiiiij'] = createExportWrapper('dynCall_iiiiij', 7);
var dynCall_iiiiijj = Module['dynCall_iiiiijj'] = createExportWrapper('dynCall_iiiiijj', 9);
var dynCall_iiiiiijj = Module['dynCall_iiiiiijj'] = createExportWrapper('dynCall_iiiiiijj', 10);
var _asyncify_start_unwind = createExportWrapper('asyncify_start_unwind', 1);
var _asyncify_stop_unwind = createExportWrapper('asyncify_stop_unwind', 0);
var _asyncify_start_rewind = createExportWrapper('asyncify_start_rewind', 1);
var _asyncify_stop_rewind = createExportWrapper('asyncify_stop_rewind', 0);

function invoke_viii(index,a1,a2,a3) {
  var sp = stackSave();
  try {
    dynCall_viii(index,a1,a2,a3);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_ii(index,a1) {
  var sp = stackSave();
  try {
    return dynCall_ii(index,a1);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_iiii(index,a1,a2,a3) {
  var sp = stackSave();
  try {
    return dynCall_iiii(index,a1,a2,a3);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_vii(index,a1,a2) {
  var sp = stackSave();
  try {
    dynCall_vii(index,a1,a2);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_iii(index,a1,a2) {
  var sp = stackSave();
  try {
    return dynCall_iii(index,a1,a2);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_iiiiiii(index,a1,a2,a3,a4,a5,a6) {
  var sp = stackSave();
  try {
    return dynCall_iiiiiii(index,a1,a2,a3,a4,a5,a6);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_vi(index,a1) {
  var sp = stackSave();
  try {
    dynCall_vi(index,a1);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_v(index) {
  var sp = stackSave();
  try {
    dynCall_v(index);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_iiiiii(index,a1,a2,a3,a4,a5) {
  var sp = stackSave();
  try {
    return dynCall_iiiiii(index,a1,a2,a3,a4,a5);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_viiii(index,a1,a2,a3,a4) {
  var sp = stackSave();
  try {
    dynCall_viiii(index,a1,a2,a3,a4);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_viiiiii(index,a1,a2,a3,a4,a5,a6) {
  var sp = stackSave();
  try {
    dynCall_viiiiii(index,a1,a2,a3,a4,a5,a6);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_iiiii(index,a1,a2,a3,a4) {
  var sp = stackSave();
  try {
    return dynCall_iiiii(index,a1,a2,a3,a4);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_viiiii(index,a1,a2,a3,a4,a5) {
  var sp = stackSave();
  try {
    dynCall_viiiii(index,a1,a2,a3,a4,a5);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_i(index) {
  var sp = stackSave();
  try {
    return dynCall_i(index);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_iiiiiif(index,a1,a2,a3,a4,a5,a6) {
  var sp = stackSave();
  try {
    return dynCall_iiiiiif(index,a1,a2,a3,a4,a5,a6);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_viiiiiiiii(index,a1,a2,a3,a4,a5,a6,a7,a8,a9) {
  var sp = stackSave();
  try {
    dynCall_viiiiiiiii(index,a1,a2,a3,a4,a5,a6,a7,a8,a9);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_iiiiiiiii(index,a1,a2,a3,a4,a5,a6,a7,a8) {
  var sp = stackSave();
  try {
    return dynCall_iiiiiiiii(index,a1,a2,a3,a4,a5,a6,a7,a8);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_viiiiiiii(index,a1,a2,a3,a4,a5,a6,a7,a8) {
  var sp = stackSave();
  try {
    dynCall_viiiiiiii(index,a1,a2,a3,a4,a5,a6,a7,a8);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_iif(index,a1,a2) {
  var sp = stackSave();
  try {
    return dynCall_iif(index,a1,a2);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_vif(index,a1,a2) {
  var sp = stackSave();
  try {
    dynCall_vif(index,a1,a2);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_vifi(index,a1,a2,a3) {
  var sp = stackSave();
  try {
    dynCall_vifi(index,a1,a2,a3);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_viifi(index,a1,a2,a3,a4) {
  var sp = stackSave();
  try {
    dynCall_viifi(index,a1,a2,a3,a4);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_viff(index,a1,a2,a3) {
  var sp = stackSave();
  try {
    dynCall_viff(index,a1,a2,a3);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_viiif(index,a1,a2,a3,a4) {
  var sp = stackSave();
  try {
    dynCall_viiif(index,a1,a2,a3,a4);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_ff(index,a1) {
  var sp = stackSave();
  try {
    return dynCall_ff(index,a1);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_viiiif(index,a1,a2,a3,a4,a5) {
  var sp = stackSave();
  try {
    dynCall_viiiif(index,a1,a2,a3,a4,a5);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_iiiif(index,a1,a2,a3,a4) {
  var sp = stackSave();
  try {
    return dynCall_iiiif(index,a1,a2,a3,a4);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_viiiiiii(index,a1,a2,a3,a4,a5,a6,a7) {
  var sp = stackSave();
  try {
    dynCall_viiiiiii(index,a1,a2,a3,a4,a5,a6,a7);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_fii(index,a1,a2) {
  var sp = stackSave();
  try {
    return dynCall_fii(index,a1,a2);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_viiffff(index,a1,a2,a3,a4,a5,a6) {
  var sp = stackSave();
  try {
    dynCall_viiffff(index,a1,a2,a3,a4,a5,a6);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_fi(index,a1) {
  var sp = stackSave();
  try {
    return dynCall_fi(index,a1);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_iiiiif(index,a1,a2,a3,a4,a5) {
  var sp = stackSave();
  try {
    return dynCall_iiiiif(index,a1,a2,a3,a4,a5);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_iiiiid(index,a1,a2,a3,a4,a5) {
  var sp = stackSave();
  try {
    return dynCall_iiiiid(index,a1,a2,a3,a4,a5);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_iiiiiiii(index,a1,a2,a3,a4,a5,a6,a7) {
  var sp = stackSave();
  try {
    return dynCall_iiiiiiii(index,a1,a2,a3,a4,a5,a6,a7);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_iiiiiiiiiii(index,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10) {
  var sp = stackSave();
  try {
    return dynCall_iiiiiiiiiii(index,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_iiiiiiiiiiiii(index,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12) {
  var sp = stackSave();
  try {
    return dynCall_iiiiiiiiiiiii(index,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_fiii(index,a1,a2,a3) {
  var sp = stackSave();
  try {
    return dynCall_fiii(index,a1,a2,a3);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_diii(index,a1,a2,a3) {
  var sp = stackSave();
  try {
    return dynCall_diii(index,a1,a2,a3);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_iiiiiiiiiiii(index,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11) {
  var sp = stackSave();
  try {
    return dynCall_iiiiiiiiiiii(index,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_viiiiiiiiii(index,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10) {
  var sp = stackSave();
  try {
    dynCall_viiiiiiiiii(index,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_viiiiiiiiiiiiiii(index,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15) {
  var sp = stackSave();
  try {
    dynCall_viiiiiiiiiiiiiii(index,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_ji(index,a1) {
  var sp = stackSave();
  try {
    return dynCall_ji(index,a1);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}

function invoke_jiiii(index,a1,a2,a3,a4) {
  var sp = stackSave();
  try {
    return dynCall_jiiii(index,a1,a2,a3,a4);
  } catch(e) {
    stackRestore(sp);
    if (!(e instanceof EmscriptenEH)) throw e;
    _setThrew(1, 0);
  }
}


// include: postamble.js
// === Auto-generated postamble setup entry stuff ===

Module['addRunDependency'] = addRunDependency;
Module['removeRunDependency'] = removeRunDependency;
Module['FS_createPreloadedFile'] = FS_createPreloadedFile;
Module['FS_unlink'] = FS_unlink;
Module['FS_createPath'] = FS_createPath;
Module['FS_createDevice'] = FS_createDevice;
Module['FS_createDataFile'] = FS_createDataFile;
Module['FS_createLazyFile'] = FS_createLazyFile;
var missingLibrarySymbols = [
  'writeI53ToI64',
  'writeI53ToI64Clamped',
  'writeI53ToI64Signaling',
  'writeI53ToU64Clamped',
  'writeI53ToU64Signaling',
  'readI53FromI64',
  'readI53FromU64',
  'convertI32PairToI53',
  'convertU32PairToI53',
  'getTempRet0',
  'arraySum',
  'addDays',
  'inetPton4',
  'inetNtop4',
  'inetPton6',
  'inetNtop6',
  'readSockaddr',
  'writeSockaddr',
  'emscriptenLog',
  'runMainThreadEmAsm',
  'jstoi_q',
  'dynCallLegacy',
  'getDynCaller',
  'dynCall',
  'asmjsMangle',
  'HandleAllocator',
  'getNativeTypeSize',
  'STACK_SIZE',
  'STACK_ALIGN',
  'POINTER_SIZE',
  'ASSERTIONS',
  'getCFunc',
  'ccall',
  'cwrap',
  'uleb128Encode',
  'generateFuncType',
  'convertJsFunctionToWasm',
  'getEmptyTableSlot',
  'updateTableMap',
  'getFunctionAddress',
  'addFunction',
  'removeFunction',
  'reallyNegative',
  'unSign',
  'strLen',
  'reSign',
  'formatString',
  'intArrayToString',
  'AsciiToString',
  'UTF16ToString',
  'stringToUTF16',
  'lengthBytesUTF16',
  'UTF32ToString',
  'stringToUTF32',
  'lengthBytesUTF32',
  'writeArrayToMemory',
  'registerKeyEventCallback',
  'maybeCStringToJsString',
  'findEventTarget',
  'getBoundingClientRect',
  'fillMouseEventData',
  'registerMouseEventCallback',
  'registerWheelEventCallback',
  'registerUiEventCallback',
  'registerFocusEventCallback',
  'fillDeviceOrientationEventData',
  'registerDeviceOrientationEventCallback',
  'fillDeviceMotionEventData',
  'registerDeviceMotionEventCallback',
  'screenOrientation',
  'fillOrientationChangeEventData',
  'registerOrientationChangeEventCallback',
  'fillFullscreenChangeEventData',
  'registerFullscreenChangeEventCallback',
  'JSEvents_requestFullscreen',
  'JSEvents_resizeCanvasForFullscreen',
  'registerRestoreOldStyle',
  'hideEverythingExceptGivenElement',
  'restoreHiddenElements',
  'setLetterbox',
  'softFullscreenResizeWebGLRenderTarget',
  'doRequestFullscreen',
  'fillPointerlockChangeEventData',
  'registerPointerlockChangeEventCallback',
  'registerPointerlockErrorEventCallback',
  'requestPointerLock',
  'fillVisibilityChangeEventData',
  'registerVisibilityChangeEventCallback',
  'registerTouchEventCallback',
  'fillGamepadEventData',
  'registerGamepadEventCallback',
  'registerBeforeUnloadEventCallback',
  'fillBatteryEventData',
  'battery',
  'registerBatteryEventCallback',
  'setCanvasElementSize',
  'getCanvasElementSize',
  'jsStackTrace',
  'getCallstack',
  'convertPCtoSourceLocation',
  'checkWasiClock',
  'wasiRightsToMuslOFlags',
  'wasiOFlagsToMuslOFlags',
  'createDyncallWrapper',
  'setImmediateWrapped',
  'clearImmediateWrapped',
  'polyfillSetImmediate',
  'getPromise',
  'makePromise',
  'idsToPromises',
  'makePromiseCallback',
  'Browser_asyncPrepareDataCounter',
  'getSocketFromFD',
  'getSocketAddress',
  'FS_mkdirTree',
  '_setNetworkCallback',
  'heapObjectForWebGLType',
  'toTypedArrayIndex',
  'emscriptenWebGLGet',
  'computeUnpackAlignedImageSize',
  'colorChannelsInGlTextureFormat',
  'emscriptenWebGLGetTexPixelData',
  'emscriptenWebGLGetUniform',
  'webglGetUniformLocation',
  'webglPrepareUniformLocationsBeforeFirstUse',
  'webglGetLeftBracePos',
  'emscriptenWebGLGetVertexAttrib',
  '__glGetActiveAttribOrUniform',
  'writeGLArray',
  'registerWebGlEventCallback',
  'ALLOC_NORMAL',
  'ALLOC_STACK',
  'allocate',
  'writeStringToMemory',
  'writeAsciiToMemory',
  'setErrNo',
  'demangle',
  'stackTrace',
];
missingLibrarySymbols.forEach(missingLibrarySymbol)

var unexportedSymbols = [
  'run',
  'addOnPreRun',
  'addOnInit',
  'addOnPreMain',
  'addOnExit',
  'addOnPostRun',
  'out',
  'err',
  'callMain',
  'abort',
  'wasmMemory',
  'wasmExports',
  'writeStackCookie',
  'checkStackCookie',
  'convertI32PairToI53Checked',
  'stackSave',
  'stackRestore',
  'stackAlloc',
  'setTempRet0',
  'ptrToString',
  'zeroMemory',
  'exitJS',
  'getHeapMax',
  'growMemory',
  'ENV',
  'MONTH_DAYS_REGULAR',
  'MONTH_DAYS_LEAP',
  'MONTH_DAYS_REGULAR_CUMULATIVE',
  'MONTH_DAYS_LEAP_CUMULATIVE',
  'isLeapYear',
  'ydayFromDate',
  'ERRNO_CODES',
  'strError',
  'DNS',
  'Protocols',
  'Sockets',
  'initRandomFill',
  'randomFill',
  'timers',
  'warnOnce',
  'readEmAsmArgsArray',
  'readEmAsmArgs',
  'runEmAsmFunction',
  'jstoi_s',
  'getExecutableName',
  'listenOnce',
  'autoResumeAudioContext',
  'handleException',
  'keepRuntimeAlive',
  'runtimeKeepalivePush',
  'runtimeKeepalivePop',
  'callUserCallback',
  'maybeExit',
  'asyncLoad',
  'alignMemory',
  'mmapAlloc',
  'wasmTable',
  'noExitRuntime',
  'sigToWasmTypes',
  'freeTableIndexes',
  'functionsInTableMap',
  'setValue',
  'getValue',
  'PATH',
  'PATH_FS',
  'UTF8Decoder',
  'UTF8ArrayToString',
  'UTF8ToString',
  'stringToUTF8Array',
  'stringToUTF8',
  'lengthBytesUTF8',
  'intArrayFromString',
  'stringToAscii',
  'UTF16Decoder',
  'stringToNewUTF8',
  'stringToUTF8OnStack',
  'JSEvents',
  'specialHTMLTargets',
  'findCanvasEventTarget',
  'currentFullscreenStrategy',
  'restoreOldWindowedStyle',
  'UNWIND_CACHE',
  'ExitStatus',
  'getEnvStrings',
  'doReadv',
  'doWritev',
  'safeSetTimeout',
  'promiseMap',
  'uncaughtExceptionCount',
  'exceptionLast',
  'exceptionCaught',
  'ExceptionInfo',
  'findMatchingCatch',
  'getExceptionMessageCommon',
  'incrementExceptionRefcount',
  'decrementExceptionRefcount',
  'getExceptionMessage',
  'Browser',
  'setMainLoop',
  'getPreloadedImageData__data',
  'wget',
  'SYSCALLS',
  'preloadPlugins',
  'FS_modeStringToFlags',
  'FS_getMode',
  'FS_stdin_getChar_buffer',
  'FS_stdin_getChar',
  'FS_readFile',
  'FS',
  'MEMFS',
  'TTY',
  'PIPEFS',
  'SOCKFS',
  'tempFixedLengthArray',
  'miniTempWebGLFloatBuffers',
  'miniTempWebGLIntBuffers',
  'webgl_enable_ANGLE_instanced_arrays',
  'webgl_enable_OES_vertex_array_object',
  'webgl_enable_WEBGL_draw_buffers',
  'webgl_enable_WEBGL_multi_draw',
  'GL',
  'AL',
  'GLUT',
  'EGL',
  'GLEW',
  'IDBStore',
  'runAndAbortIfError',
  'Asyncify',
  'Fibers',
  'SDL',
  'SDL_gfx',
  'allocateUTF8',
  'allocateUTF8OnStack',
  'print',
  'printErr',
  'IDBFS',
];
unexportedSymbols.forEach(unexportedRuntimeSymbol);



var calledRun;

dependenciesFulfilled = function runCaller() {
  // If run has never been called, and we should call run (INVOKE_RUN is true, and Module.noInitialRun is not false)
  if (!calledRun) run();
  if (!calledRun) dependenciesFulfilled = runCaller; // try this again later, after new deps are fulfilled
};

function callMain(args = []) {
  assert(runDependencies == 0, 'cannot call main when async dependencies remain! (listen on Module["onRuntimeInitialized"])');
  assert(__ATPRERUN__.length == 0, 'cannot call main when preRun functions remain to be called');

  var entryFunction = _main;

  args.unshift(thisProgram);

  var argc = args.length;
  var argv = stackAlloc((argc + 1) * 4);
  var argv_ptr = argv;
  args.forEach((arg) => {
    HEAPU32[((argv_ptr)>>2)] = stringToUTF8OnStack(arg);
    argv_ptr += 4;
  });
  HEAPU32[((argv_ptr)>>2)] = 0;

  try {

    var ret = entryFunction(argc, argv);

    // if we're not running an evented main loop, it's time to exit
    exitJS(ret, /* implicit = */ true);
    return ret;
  }
  catch (e) {
    return handleException(e);
  }
}

function stackCheckInit() {
  // This is normally called automatically during __wasm_call_ctors but need to
  // get these values before even running any of the ctors so we call it redundantly
  // here.
  _emscripten_stack_init();
  // TODO(sbc): Move writeStackCookie to native to to avoid this.
  writeStackCookie();
}

function run(args = arguments_) {

  if (runDependencies > 0) {
    return;
  }

    stackCheckInit();

  preRun();

  // a preRun added a dependency, run will be called later
  if (runDependencies > 0) {
    return;
  }

  function doRun() {
    // run may have just been called through dependencies being fulfilled just in this very frame,
    // or while the async setStatus time below was happening
    if (calledRun) return;
    calledRun = true;
    Module['calledRun'] = true;

    if (ABORT) return;

    initRuntime();

    preMain();

    Module['onRuntimeInitialized']?.();

    if (shouldRunNow) callMain(args);

    postRun();
  }

  if (Module['setStatus']) {
    Module['setStatus']('Running...');
    setTimeout(function() {
      setTimeout(function() {
        Module['setStatus']('');
      }, 1);
      doRun();
    }, 1);
  } else
  {
    doRun();
  }
  checkStackCookie();
}

function checkUnflushedContent() {
  // Compiler settings do not allow exiting the runtime, so flushing
  // the streams is not possible. but in ASSERTIONS mode we check
  // if there was something to flush, and if so tell the user they
  // should request that the runtime be exitable.
  // Normally we would not even include flush() at all, but in ASSERTIONS
  // builds we do so just for this check, and here we see if there is any
  // content to flush, that is, we check if there would have been
  // something a non-ASSERTIONS build would have not seen.
  // How we flush the streams depends on whether we are in SYSCALLS_REQUIRE_FILESYSTEM=0
  // mode (which has its own special function for this; otherwise, all
  // the code is inside libc)
  var oldOut = out;
  var oldErr = err;
  var has = false;
  out = err = (x) => {
    has = true;
  }
  try { // it doesn't matter if it fails
    _fflush(0);
    // also flush in the JS FS layer
    ['stdout', 'stderr'].forEach(function(name) {
      var info = FS.analyzePath('/dev/' + name);
      if (!info) return;
      var stream = info.object;
      var rdev = stream.rdev;
      var tty = TTY.ttys[rdev];
      if (tty?.output?.length) {
        has = true;
      }
    });
  } catch(e) {}
  out = oldOut;
  err = oldErr;
  if (has) {
    warnOnce('stdio streams had content in them that was not flushed. you should set EXIT_RUNTIME to 1 (see the Emscripten FAQ), or make sure to emit a newline when you printf etc.');
  }
}

if (Module['preInit']) {
  if (typeof Module['preInit'] == 'function') Module['preInit'] = [Module['preInit']];
  while (Module['preInit'].length > 0) {
    Module['preInit'].pop()();
  }
}

// shouldRunNow refers to calling main(), not run().
var shouldRunNow = true;

if (Module['noInitialRun']) shouldRunNow = false;

run();

// end include: postamble.js

