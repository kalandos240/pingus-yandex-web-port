Pingus 0.7.6 WebAssembly port for Yandex Games.
index.html is the entry point. WebAssembly and game data are embedded in pingus.js,
so the game does not fetch separate .wasm or .data payloads at runtime.
