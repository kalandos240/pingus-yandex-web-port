Pingus 0.7.6 WebAssembly port for Yandex Games.
Extract the archive and serve its root over HTTP(S); index.html is the entry point.
