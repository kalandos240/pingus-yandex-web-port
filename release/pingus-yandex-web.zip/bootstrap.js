(() => {
      const nativeCanvasGetContext = HTMLCanvasElement.prototype.getContext;
      HTMLCanvasElement.prototype.getContext = function(type, options) {
        if (type === '2d') {
          const readbackOptions = options && typeof options === 'object'
            ? { ...options, willReadFrequently: true }
            : { willReadFrequently: true };
          return nativeCanvasGetContext.call(this, type, readbackOptions);
        }
        return nativeCanvasGetContext.apply(this, arguments);
      };

      const loading = document.getElementById('loading');
      const status = document.getElementById('loading-status');
      const progress = document.getElementById('progress');
      const canvas = document.getElementById('canvas');
      canvas.addEventListener('contextmenu', (event) => event.preventDefault());
      const gameShell = document.getElementById('game-shell');
      gameShell.addEventListener('contextmenu', (event) => event.preventDefault());
      gameShell.addEventListener('dragstart', (event) => event.preventDefault());
      let gameReadySent = false;
      let saveInProgress = false;
      let saveRequestedAgain = false;
      let autosaveTimer = 0;
      const INTERSTITIAL_MIN_INTERVAL_MS = 120000;
      let interstitialInProgress = false;
      let lastInterstitialAt = performance.now();
      let platformPaused = false;

      // Before the first rendered frame we must not gate startup on focus: an
      // embedded Yandex iframe may not own focus yet. Yandex game_api_pause is
      // different: it explicitly means an ad/purchase/platform overlay requires
      // gameplay and audio to stop, including during startup.
      window.pingusPagePaused = () =>
        platformPaused || document.hidden;
      window.pingusSetPlatformPaused = (paused) => {
        platformPaused = Boolean(paused);
        if (typeof window.pingusSyncPagePause === 'function')
          window.pingusSyncPagePause();
      };

      // CI launches the real packaged page with ?pingus-smoke=1. In that mode
      // report the first rendered frame (or a startup failure) back to its
      // local HTTP server. Normal Yandex launches never perform these requests.
      const pingusSmokeMode = new URLSearchParams(location.search).get('pingus-smoke') === '1';
      const pingusSmokeSignal = (kind, detail = '') => {
        if (!pingusSmokeMode) return;
        const suffix = detail ? `?detail=${encodeURIComponent(String(detail).slice(0, 300))}` : '';
        fetch(`/__pingus_${kind}__${suffix}`, { cache: 'no-store' }).catch(() => {});
      };

      const text = {
        en: { loading: 'Loading…', failed: 'The game could not be started.' },
        ru: { loading: 'Загрузка…', failed: 'Не удалось запустить игру.' }
      };
      let uiLanguage = 'en';

      const normalizeLanguage = (value) => {
        const code = String(value || '').toLowerCase().split(/[-_]/)[0];
        return code === 'ru' ? 'ru' : 'en';
      };

      const applyEnvironmentLocale = () => {
        if (typeof ENV === 'undefined') return false;
        const locale = uiLanguage === 'ru' ? 'ru_RU.UTF-8' : 'en_US.UTF-8';
        ENV.LANG = locale;
        ENV.LC_ALL = locale;
        return true;
      };

      const applyLanguage = (value) => {
        uiLanguage = normalizeLanguage(value);
        document.documentElement.lang = uiLanguage;
        if (!gameReadySent) status.textContent = text[uiLanguage].loading;
        // This succeeds if Emscripten is already initialized. If the SDK wins
        // the startup race, preRun below repeats it at the guaranteed-safe time.
        applyEnvironmentLocale();
      };
      window.pingusApplyEnvironmentLocale = applyEnvironmentLocale;

      const setLoadingError = (message) => {
        const errorText = message || text[uiLanguage].failed;
        document.documentElement.dataset.pingusError = errorText;
        pingusSmokeSignal('error', errorText);
        loading.hidden = false;
        status.textContent = errorText;
        progress.removeAttribute('value');
      };



      // Called synchronously from a ResultScreen user action. Return true only
      // when an interstitial has actually been started and native navigation
      // must wait for its callback. No automatic/timer-based ad path exists.
      window.pingusShowInterstitialFromUserAction = (screenPtr, retry) => {
        if (interstitialInProgress) return true;

        const ysdk = window.ysdk;
        if (typeof ysdk?.adv?.showFullscreenAdv !== 'function') return false;

        const now = performance.now();
        if (now - lastInterstitialAt < INTERSTITIAL_MIN_INTERVAL_MS) return false;

        const continueNative = () => {
          const fn = window.Module?._pingus_result_continue_after_ad;
          if (typeof fn !== 'function') {
            console.error('Pingus result-screen ad continuation is unavailable');
            return;
          }
          // Avoid re-entering native GUI code from inside the SDK callback.
          window.setTimeout(() => fn(screenPtr, retry ? 1 : 0), 0);
        };

        let settled = false;
        const finish = () => {
          if (settled) return;
          settled = true;
          interstitialInProgress = false;
          window.pingusSetPlatformPaused?.(false);
          continueNative();
        };

        try {
          interstitialInProgress = true;
          lastInterstitialAt = now;
          ysdk.adv.showFullscreenAdv({
            callbacks: {
              onOpen: () => {
                window.pingusSetPlatformPaused?.(true);
                window.pingusSaveNow?.();
              },
              onClose: finish,
              onError: (error) => {
                console.warn('Yandex fullscreen ad failed:', error);
                finish();
              }
            }
          });
          return true;
        } catch (error) {
          console.warn('Yandex fullscreen ad request failed:', error);
          interstitialInProgress = false;
          window.pingusSetPlatformPaused?.(false);
          return false;
        }
      };

      let gameplayDesiredActive = false;
      let gameplayStateInitialized = false;
      let gameplaySyncVersion = 0;

      window.pingusSetGameplayActive = (active) => {
        const desired = Boolean(active);
        if (gameplayStateInitialized && gameplayDesiredActive === desired) return;

        gameplayStateInitialized = true;
        gameplayDesiredActive = desired;
        const version = ++gameplaySyncVersion;

        (async () => {
          const ysdk = await window.yandexSDKPromise;
          if (version !== gameplaySyncVersion) return;

          const gameplay = ysdk?.features?.GameplayAPI;
          if (!gameplay) return;

          try {
            if (gameplayDesiredActive) gameplay.start();
            else gameplay.stop();
          } catch (error) {
            console.warn('Yandex GameplayAPI state update failed:', error);
          }
        })().catch((error) => {
          console.warn('Yandex GameplayAPI synchronization failed:', error);
        });
      };

      window.yandexSDKPromise = (async () => {
        try {
          if (typeof YaGames === 'undefined') return null;
          const ysdk = await YaGames.init();
          window.ysdk = ysdk;

          // Yandex uses these events for startup/fullscreen/rewarded ads,
          // purchase dialogs, tab switches and similar platform interruptions.
          // Keep them separate from the game's own pause button: clearing a
          // platform pause must never change Pingus' internal pause state.
          try {
            ysdk?.on?.('game_api_pause', () => window.pingusSetPlatformPaused(true));
            ysdk?.on?.('game_api_resume', () => window.pingusSetPlatformPaused(false));
          } catch (error) {
            console.warn('Yandex pause/resume subscription failed:', error);
          }

          applyLanguage(ysdk?.environment?.i18n?.lang);
          return ysdk;
        } catch (error) {
          console.warn('Yandex Games SDK initialization failed:', error);
          return null;
        }
      })();

      const PINGUS_CLOUD_KEY = 'pingusCloudSaveV1';
      const PINGUS_CLOUD_VERSION = 1;
      const PINGUS_SAVE_PATH = '/home/web_user/.pingus/savegames/savegames.scm';
      const PINGUS_STATS_PATH = '/home/web_user/.pingus/savegames/variables.scm';
      const PINGUS_CLOUD_MAX_CHARS = 180000;
      let pingusPlayerPromise = null;
      let pingusCloudRestoreFinished = false;
      let pingusCloudSaveInProgress = false;
      let pingusCloudSaveRequestedAgain = false;
      let pingusLastCloudFingerprint = '';

      const cloudTimeout = (promise, timeoutMs) => Promise.race([
        promise,
        new Promise((_, reject) => window.setTimeout(
          () => reject(new Error('Yandex cloud operation timed out')),
          timeoutMs
        ))
      ]);

      const ensureFsDir = (path) => {
        try { FS.mkdir(path); } catch (_) {}
      };

      const readTextFile = (path) => {
        try { return FS.readFile(path, { encoding: 'utf8' }); } catch (_) { return ''; }
      };

      const fileModifiedAt = (path) => {
        try {
          const value = FS.stat(path)?.mtime;
          if (value instanceof Date) return value.getTime();
          const number = Number(value || 0);
          return Number.isFinite(number) ? number : 0;
        } catch (_) {
          return 0;
        }
      };

      const hashText = (value) => {
        // FNV-1a is sufficient here: this is only a change detector, not security.
        let hash = 0x811c9dc5;
        const textValue = String(value || '');
        for (let i = 0; i < textValue.length; ++i) {
          hash ^= textValue.charCodeAt(i);
          hash = Math.imul(hash, 0x01000193);
        }
        return (hash >>> 0).toString(16).padStart(8, '0');
      };

      const snapshotFingerprint = (snapshot) =>
        `${hashText(snapshot?.savegames)}:${hashText(snapshot?.stats)}`;

      const validSavegames = (value) =>
        typeof value === 'string' && value.length <= PINGUS_CLOUD_MAX_CHARS &&
        value.includes('(pingus-savegame');

      const validStats = (value) =>
        typeof value === 'string' && value.length <= PINGUS_CLOUD_MAX_CHARS &&
        value.includes('(pingus-stats');

      const readLocalProgress = () => {
        const savegames = readTextFile(PINGUS_SAVE_PATH);
        const stats = readTextFile(PINGUS_STATS_PATH);
        return {
          version: PINGUS_CLOUD_VERSION,
          updatedAt: Math.max(fileModifiedAt(PINGUS_SAVE_PATH), fileModifiedAt(PINGUS_STATS_PATH)),
          savegames: validSavegames(savegames) ? savegames : '',
          stats: validStats(stats) ? stats : ''
        };
      };

      const normalizeCloudProgress = (value) => {
        if (!value || typeof value !== 'object' || value.version !== PINGUS_CLOUD_VERSION)
          return null;
        const savegames = validSavegames(value.savegames) ? value.savegames : '';
        const stats = validStats(value.stats) ? value.stats : '';
        if (!savegames && !stats) return null;
        const updatedAt = Number(value.updatedAt || 0);
        return {
          version: PINGUS_CLOUD_VERSION,
          updatedAt: Number.isFinite(updatedAt) ? updatedAt : 0,
          savegames,
          stats
        };
      };

      const extractLevelBlocks = (source) => {
        const blocks = [];
        let cursor = 0;
        while (cursor < source.length) {
          const start = source.indexOf('(level', cursor);
          if (start < 0) break;
          const boundary = source[start + 6];
          if (boundary && !/\s|\)/.test(boundary)) {
            cursor = start + 6;
            continue;
          }

          let depth = 0;
          let inString = false;
          let escaped = false;
          let end = -1;
          for (let i = start; i < source.length; ++i) {
            const ch = source[i];
            if (inString) {
              if (escaped) escaped = false;
              else if (ch === '\\') escaped = true;
              else if (ch === '"') inString = false;
              continue;
            }
            if (ch === '"') inString = true;
            else if (ch === '(') ++depth;
            else if (ch === ')') {
              --depth;
              if (depth === 0) {
                end = i + 1;
                break;
              }
            }
          }
          if (end < 0) return null;
          blocks.push(source.slice(start, end));
          cursor = end;
        }
        return blocks;
      };

      const parseLevelBlock = (block, sourceName, sourceUpdatedAt) => {
        const filename = /\(filename\s+"((?:\\.|[^"\\])*)"\)/.exec(block)?.[1];
        const status = /\(status\s+([^\s\)]+)\)/.exec(block)?.[1]?.toLowerCase();
        if (!filename || !status) return null;
        const time = Number(/\(time\s+(-?\d+)\)/.exec(block)?.[1] || 0);
        const saved = Number(/\(saved-pingus\s+(-?\d+)\)/.exec(block)?.[1] || 0);
        return { block, filename, status, time, saved, sourceName, sourceUpdatedAt };
      };

      const levelRank = (level) => {
        if (level.status === 'finished') return 2;
        if (level.status === 'accessible') return 1;
        return 0;
      };

      const chooseLevelProgress = (left, right) => {
        const leftRank = levelRank(left);
        const rightRank = levelRank(right);
        if (leftRank !== rightRank) return leftRank > rightRank ? left : right;
        if (leftRank === 2) {
          if (left.saved !== right.saved) return left.saved > right.saved ? left : right;
          const leftTime = left.time > 0 ? left.time : Number.MAX_SAFE_INTEGER;
          const rightTime = right.time > 0 ? right.time : Number.MAX_SAFE_INTEGER;
          if (leftTime !== rightTime) return leftTime < rightTime ? left : right;
        }
        return left.sourceUpdatedAt >= right.sourceUpdatedAt ? left : right;
      };

      const mergeSavegames = (localText, cloudText, localUpdatedAt, cloudUpdatedAt) => {
        if (!validSavegames(localText)) return validSavegames(cloudText) ? cloudText : '';
        if (!validSavegames(cloudText)) return localText;

        const localBlocks = extractLevelBlocks(localText);
        const cloudBlocks = extractLevelBlocks(cloudText);
        if (!localBlocks || !cloudBlocks)
          return cloudUpdatedAt > localUpdatedAt ? cloudText : localText;

        const merged = new Map();
        const addBlocks = (blocks, sourceName, updatedAt) => {
          for (const block of blocks) {
            const parsed = parseLevelBlock(block, sourceName, updatedAt);
            if (!parsed) return false;
            const existing = merged.get(parsed.filename);
            merged.set(parsed.filename, existing ? chooseLevelProgress(existing, parsed) : parsed);
          }
          return true;
        };
        if (!addBlocks(localBlocks, 'local', localUpdatedAt) ||
            !addBlocks(cloudBlocks, 'cloud', cloudUpdatedAt))
          return cloudUpdatedAt > localUpdatedAt ? cloudText : localText;

        if (!merged.size)
          return cloudUpdatedAt > localUpdatedAt ? cloudText : localText;

        return '(pingus-savegame \n' +
          Array.from(merged.values(), (entry) => '  ' + entry.block).join('\n') +
          '\n)';
      };

      const mergeProgress = (local, cloud) => {
        if (!cloud) return local;
        const savegames = mergeSavegames(
          local.savegames,
          cloud.savegames,
          local.updatedAt,
          cloud.updatedAt
        );
        let stats = local.stats;
        if (!stats || (cloud.stats && cloud.updatedAt > local.updatedAt)) stats = cloud.stats;
        return {
          version: PINGUS_CLOUD_VERSION,
          updatedAt: Math.max(local.updatedAt || 0, cloud.updatedAt || 0),
          savegames,
          stats
        };
      };

      const writeLocalProgress = (snapshot) => {
        ensureFsDir('/home/web_user/.pingus');
        ensureFsDir('/home/web_user/.pingus/savegames');
        if (validSavegames(snapshot?.savegames) && readTextFile(PINGUS_SAVE_PATH) !== snapshot.savegames)
          FS.writeFile(PINGUS_SAVE_PATH, snapshot.savegames, { encoding: 'utf8' });
        if (validStats(snapshot?.stats) && readTextFile(PINGUS_STATS_PATH) !== snapshot.stats)
          FS.writeFile(PINGUS_STATS_PATH, snapshot.stats, { encoding: 'utf8' });
      };

      const getYandexPlayer = () => {
        if (pingusPlayerPromise) return pingusPlayerPromise;
        pingusPlayerPromise = (async () => {
          const ysdk = await window.yandexSDKPromise;
          if (typeof ysdk?.getPlayer !== 'function') return null;
          try {
            return await ysdk.getPlayer();
          } catch (error) {
            console.warn('Yandex Player initialization failed:', error);
            return null;
          }
        })();
        return pingusPlayerPromise;
      };

      const setCloudProgress = async (player, snapshot) => {
        if (!player || typeof player.setData !== 'function') return false;
        const payload = {
          version: PINGUS_CLOUD_VERSION,
          updatedAt: Date.now(),
          savegames: validSavegames(snapshot.savegames) ? snapshot.savegames : '',
          stats: validStats(snapshot.stats) ? snapshot.stats : ''
        };
        if (!payload.savegames && !payload.stats) return false;
        if (JSON.stringify(payload).length > PINGUS_CLOUD_MAX_CHARS) {
          console.warn('Pingus cloud save skipped: payload is too large');
          return false;
        }
        await player.setData({ [PINGUS_CLOUD_KEY]: payload }, true);
        pingusLastCloudFingerprint = snapshotFingerprint(payload);
        return true;
      };

      window.pingusRestoreCloudSave = async () => {
        if (pingusCloudRestoreFinished) return;
        try {
          const player = await cloudTimeout(getYandexPlayer(), 6000);
          if (!player || typeof player.getData !== 'function') return;

          const data = await cloudTimeout(player.getData([PINGUS_CLOUD_KEY]), 6000);
          const cloud = normalizeCloudProgress(data?.[PINGUS_CLOUD_KEY]);
          const local = readLocalProgress();
          const merged = mergeProgress(local, cloud);
          writeLocalProgress(merged);

          const mergedFingerprint = snapshotFingerprint(merged);
          pingusLastCloudFingerprint = cloud ? snapshotFingerprint(cloud) : '';
          if (mergedFingerprint !== pingusLastCloudFingerprint)
            await cloudTimeout(setCloudProgress(player, merged), 6000);

          document.documentElement.dataset.pingusCloud = 'ready';
        } catch (error) {
          // Cloud is an enhancement; local IDBFS remains authoritative offline.
          console.warn('Yandex cloud save restore failed; using local progress:', error);
          document.documentElement.dataset.pingusCloud = 'local';
        } finally {
          pingusCloudRestoreFinished = true;
        }
      };

      window.pingusCloudSave = async () => {
        if (!pingusCloudRestoreFinished) return;
        if (pingusCloudSaveInProgress) {
          pingusCloudSaveRequestedAgain = true;
          return;
        }

        const snapshot = readLocalProgress();
        const fingerprint = snapshotFingerprint(snapshot);
        if ((!snapshot.savegames && !snapshot.stats) || fingerprint === pingusLastCloudFingerprint)
          return;

        pingusCloudSaveInProgress = true;
        try {
          const player = await cloudTimeout(getYandexPlayer(), 6000);
          if (player) await cloudTimeout(setCloudProgress(player, snapshot), 6000);
        } catch (error) {
          console.warn('Yandex cloud save failed; local progress is safe:', error);
        } finally {
          pingusCloudSaveInProgress = false;
          if (pingusCloudSaveRequestedAgain) {
            pingusCloudSaveRequestedAgain = false;
            window.pingusCloudSave();
          }
        }
      };

      const fitCanvas = () => {
        const logicalWidth = Math.max(1, canvas.width || 800);
        const logicalHeight = Math.max(1, canvas.height || 600);
        const scale = Math.min(window.innerWidth / logicalWidth, window.innerHeight / logicalHeight);
        canvas.style.width = `${Math.max(1, Math.floor(logicalWidth * scale))}px`;
        canvas.style.height = `${Math.max(1, Math.floor(logicalHeight * scale))}px`;
      };
      window.addEventListener('resize', fitCanvas, { passive: true });
      new MutationObserver(fitCanvas).observe(canvas, { attributes: true, attributeFilter: ['width', 'height'] });
      fitCanvas();

      const installTouchControls = () => {
        if (canvas.__pingusTouchControls) return;
        canvas.__pingusTouchControls = true;

        const touch = {
          active: false,
          dragging: false,
          startX: 0,
          startY: 0,
          lastX: 0,
          lastY: 0
        };
        const dragThreshold = 10; // CSS pixels; avoids accidental pans on taps.

        const emitMouse = (type, x, y, button, buttons) => {
          canvas.dispatchEvent(new MouseEvent(type, {
            bubbles: true,
            cancelable: true,
            clientX: x,
            clientY: y,
            button,
            buttons
          }));
        };

        const blockNativeTouch = (event) => {
          event.preventDefault();
          event.stopImmediatePropagation();
        };

        canvas.addEventListener('touchstart', (event) => {
          blockNativeTouch(event);
          if (event.touches.length !== 1) {
            touch.active = false;
            touch.dragging = false;
            return;
          }

          const point = event.touches[0];
          canvas.focus({ preventScroll: true });
          touch.active = true;
          touch.dragging = false;
          touch.startX = touch.lastX = point.clientX;
          touch.startY = touch.lastY = point.clientY;

          // Keep the original hover/capture rectangle in sync without clicking.
          emitMouse('mousemove', point.clientX, point.clientY, 0, 0);
        }, { capture: true, passive: false });

        canvas.addEventListener('touchmove', (event) => {
          blockNativeTouch(event);
          if (!touch.active || event.touches.length !== 1) return;

          const point = event.touches[0];
          if (!touch.dragging &&
              Math.hypot(point.clientX - touch.startX, point.clientY - touch.startY) >= dragThreshold) {
            touch.dragging = true;
            // Pingus already implements camera panning perfectly as a secondary
            // button drag, so reuse that exact path instead of moving the camera
            // from JavaScript.
            emitMouse('mousemove', touch.startX, touch.startY, 0, 0);
            emitMouse('mousedown', touch.startX, touch.startY, 2, 2);
          }

          if (touch.dragging)
            emitMouse('mousemove', point.clientX, point.clientY, 0, 2);

          touch.lastX = point.clientX;
          touch.lastY = point.clientY;
        }, { capture: true, passive: false });

        const finishTouch = (event) => {
          blockNativeTouch(event);
          if (!touch.active) return;

          const point = event.changedTouches?.[0];
          const x = point?.clientX ?? touch.lastX;
          const y = point?.clientY ?? touch.lastY;

          if (touch.dragging) {
            emitMouse('mousemove', x, y, 0, 2);
            emitMouse('mouseup', x, y, 2, 0);
          } else {
            // Deliver a complete click only after we know the gesture was a tap.
            // This prevents a camera swipe that starts over a pingu from assigning
            // the currently selected skill before the drag threshold is crossed.
            emitMouse('mousemove', x, y, 0, 0);
            emitMouse('mousedown', x, y, 0, 1);
            emitMouse('mouseup', x, y, 0, 0);
          }

          touch.active = false;
          touch.dragging = false;
        };

        canvas.addEventListener('touchend', finishTouch, { capture: true, passive: false });
        canvas.addEventListener('touchcancel', finishTouch, { capture: true, passive: false });
      };
      installTouchControls();

      const getAudioContext = () =>
        window.SDL?.audioContext || window.SDL2?.audioContext || window.AL?.currentContext?.audioCtx || null;

      const setAudioPaused = (paused) => {
        const audioContext = getAudioContext();
        if (audioContext) {
          const action = paused ? audioContext.suspend?.() : audioContext.resume?.();
          action?.catch?.(() => {});
        }

        // SDL1_mixer in Emscripten may play OGG music/channels through regular
        // HTMLAudioElement objects, not through the AudioContext above. Pause
        // only media that was actually playing, then resume exactly those.
        const media = [];
        const music = window.SDL?.music?.audio;
        if (music) media.push(music);
        const channels = window.SDL?.channels;
        if (Array.isArray(channels)) {
          for (const channel of channels) {
            if (channel?.audio) media.push(channel.audio);
          }
        }
        for (const audio of new Set(media)) {
          if (paused) {
            if (!audio.paused) {
              audio.__pingusResumeAfterPause = true;
              audio.pause();
            }
          } else if (audio.__pingusResumeAfterPause) {
            audio.__pingusResumeAfterPause = false;
            const play = audio.play?.();
            play?.catch?.(() => {});
          }
        }
      };
      window.pingusRefreshPausedAudio = () =>
        setAudioPaused(window.pingusPagePaused());

      window.pingusSaveNow = () => {
        if (typeof FS === 'undefined' || typeof FS.syncfs !== 'function') return;
        if (saveInProgress) {
          saveRequestedAgain = true;
          return;
        }
        saveInProgress = true;
        FS.syncfs(false, (error) => {
          saveInProgress = false;
          if (error) console.warn('Pingus save synchronization failed:', error);
          else window.pingusCloudSave?.();
          if (saveRequestedAgain) {
            saveRequestedAgain = false;
            window.pingusSaveNow();
          }
        });
      };

      window.pingusMarkReady = async () => {
        if (gameReadySent) return;
        gameReadySent = true;
        document.documentElement.dataset.pingusReady = '1';
        pingusSmokeSignal('ready');
        fitCanvas();
        loading.hidden = true;
        canvas.focus({ preventScroll: true });
        if (!autosaveTimer) autosaveTimer = window.setInterval(window.pingusSaveNow, 15000);
        const ysdk = await window.yandexSDKPromise;
        try { ysdk?.features?.LoadingAPI?.ready(); } catch (error) { console.warn(error); }
      };

      const syncPagePause = () => {
        const paused = window.pingusPagePaused();
        setAudioPaused(paused);
        if (paused) window.pingusSaveNow();
      };
      window.pingusSyncPagePause = syncPagePause;
      document.addEventListener('visibilitychange', syncPagePause);
      window.addEventListener('blur', () => setAudioPaused(true));
      window.addEventListener('focus', () => setAudioPaused(window.pingusPagePaused()));
      window.addEventListener('pagehide', window.pingusSaveNow);
      window.addEventListener('beforeunload', window.pingusSaveNow);
      window.addEventListener('error', (event) => {
        if (!gameReadySent) setLoadingError(event.message);
      });
      window.addEventListener('unhandledrejection', (event) => {
        if (!gameReadySent) setLoadingError(String(event.reason || text[uiLanguage].failed));
      });

      const unlockAudio = () => setAudioPaused(window.pingusPagePaused());
      window.addEventListener('pointerdown', unlockAudio, { once: true, passive: true });
      window.addEventListener('keydown', unlockAudio, { once: true });
      document.addEventListener('keydown', (event) => {
        if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(event.code)) {
          event.preventDefault();
        }
      }, { passive: false });

      applyLanguage(navigator.language);

      window.Module = {
        canvas,
        noAudioDecoding: true,
        preRun: [() => {
          // Guard legacy Pingus saves against Emscripten chmod(..., 0).
          if (!FS.__pingusChmodPatched) {
            const nativeChmod = FS.chmod.bind(FS);
            FS.chmod = (path, mode) => {
              const name = String(path || '');
              if (name.startsWith('/home/web_user/') && (mode & 0o777) === 0) mode = 0o600;
              return nativeChmod(path, mode);
            };
            FS.__pingusChmodPatched = true;
          }
          try { FS.mkdir('/home'); } catch (_) {}
          try { FS.mkdir('/home/web_user'); } catch (_) {}
          try { ENV.HOME = '/home/web_user'; } catch (_) {}

          addRunDependency('pingus-locale');
          Promise.race([
            window.yandexSDKPromise,
            new Promise((resolve) => window.setTimeout(() => resolve(null), 4000))
          ]).finally(() => {
            // ENV exists in preRun and main() has not started yet. Re-apply the
            // language selected by Yandex (or navigator fallback) so tinygettext
            // sees the correct locale on its first initialization.
            window.pingusApplyEnvironmentLocale();
            removeRunDependency('pingus-locale');
          });

          addRunDependency('pingus-idbfs');
          try {
            FS.mount(IDBFS, {}, '/home/web_user');
            FS.syncfs(true, (error) => {
              if (error) console.warn('Pingus save restore failed:', error);
              (async () => {
                await window.pingusRestoreCloudSave?.();
                await new Promise((resolve) => {
                  FS.syncfs(false, (syncError) => {
                    if (syncError) console.warn('Pingus cloud restore local flush failed:', syncError);
                    resolve();
                  });
                });
              })().catch((cloudError) => {
                console.warn('Pingus cloud startup synchronization failed:', cloudError);
              }).finally(() => removeRunDependency('pingus-idbfs'));
            });
          } catch (error) {
            console.warn('IDBFS unavailable:', error);
            // The game can still run without browser persistence. Cloud restore
            // is skipped because there is no safe local filesystem mount.
            pingusCloudRestoreFinished = true;
            removeRunDependency('pingus-idbfs');
          }
        }],
        print: (message) => console.log(message),
        printErr: (message) => console.error(message),
        onAbort: (reason) => setLoadingError(`Pingus stopped: ${reason || 'unknown error'}`),
        setStatus: (message) => {
          if (!message) return;
          status.textContent = message;
          const match = /\((\d+)\/(\d+)\)/.exec(message);
          if (match) {
            progress.max = Number(match[2]);
            progress.value = Number(match[1]);
          }
        },
        monitorRunDependencies: (left) => {
          if (!left) progress.value = progress.max;
        }
      };
    })();
